# UberBond Full-Automation Independent Acceptance Review

Reviewer note: this review was performed by re-opening the actual `automation/full-commercial-loop`
branch source (not the prior summary) with an adversarial checklist, in the same session that
built it. That is a real conflict of interest to disclose up front — this is not a fully
independent third party. To compensate, the review below privileges concrete, falsifiable findings
(bugs found and either fixed or explicitly left open) over reassurance, and one real bug was found
and fixed during this pass (see AUTO-07 below).

## Traceability matrix (selected — full stage-by-stage detail in the branch's own docs)

| Requirement | File | Test | Verdict |
|---|---|---|---|
| Zero-lite proof | `lite/` | `git diff --exit-code` | ACCEPT — reverified this session, exit 0 |
| Shadow/approval/autonomous modes | `src/automation/mode.mjs` | `automation-mode.test.mjs` (8) | ACCEPT |
| Signed/versioned/expiring campaign policy | `src/automation/campaign-policy.mjs` | `automation-campaign-policy.test.mjs` (7) | ACCEPT WITH CONDITIONS — see AUTO-02 |
| Fake outbound provider, idempotent | `src/automation/outbound-adapter.mjs` | `automation-outbound-adapter.test.mjs` (8) | ACCEPT WITH CONDITIONS — see AUTO-01 |
| Apify import, no real network | `src/automation/apify-import.mjs` | `automation-apify-import.test.mjs` (6) | ACCEPT |
| Fulfillment lanes/SLA/QA | `src/automation/fulfillment.mjs` | `automation-fulfillment.test.mjs` (11) | ACCEPT — AUTO-07 found and fixed in this review |
| Monitoring consent/cancel/failure | `src/automation/monitoring.mjs` | `automation-monitoring.test.mjs` (6) | ACCEPT |
| Owner exception queue | `src/automation/exceptions.mjs` | `automation-exceptions.test.mjs` (7) | ACCEPT WITH CONDITIONS — see AUTO-04 |
| Full state machine | `src/automation/state-machine.mjs` | `automation-state-machine.test.mjs` (9) | ACCEPT |
| Digests, dead-letter surfacing | `src/automation/digest.mjs`, `job-handlers.mjs` | `automation-digest.test.mjs` (4), `automation-hostile.test.mjs` (11) | ACCEPT WITH CONDITIONS — see AUTO-05 |
| Scheduler registration | — | — | NOT IMPLEMENTED (disclosed by the branch's own readiness doc) |
| Owner HTTP/UI routes | — | — | NOT IMPLEMENTED (disclosed by the branch's own readiness doc) |
| Real provider integration | `src/gmail.mjs`, `src/payments.mjs` | pre-existing | DEFERRED EXTERNAL — needs real credentials |

## Findings from this pass's hostile review

**AUTO-01 (documentation gap, not a defect) — fake-adapter concurrency proof is weaker than it looks.**
`tests/automation-hostile.test.mjs`'s "duplicate outbound sends are impossible even under repeated
reserve/send races" test passes because `createFakeOutboundProvider#reserve` has no internal
`await` between its read and its write, so calls invoked via `Promise.all` in this JS runtime
execute to completion synchronously per call rather than truly interleaving. That correctly proves
the *idempotency-key contract* the adapter interface requires, but it does not by itself prove
safety under real I/O-interleaved concurrency — that guarantee comes from the pre-existing,
separately tested `store.reserveOutboundSend` (Postgres `FOR UPDATE SKIP LOCKED`, exercised against
real embedded Postgres with genuine crash/race tests in PR #5). Recommend the automation
architecture doc state this distinction explicitly rather than let the fake-provider test imply
more than it proves. Severity: low (no incorrect behavior, only an imprecise claim).

**AUTO-02 (real, should-fix) — campaign-policy signing key is not separated from the token-encryption key.**
`src/automation/campaign-policy.mjs` signs with `cfg.automation.policySecret`, which defaults to
`cfg.encryptionKey` (`TOKEN_ENCRYPTION_KEY`) if unset. That key is also used to encrypt Gmail OAuth
tokens (`src/gmail.mjs#sealTokens`). Reusing one secret for two different cryptographic purposes
(symmetric encryption vs. HMAC signing) is a key-separation violation — low practical severity
today (both are server-side secrets with equivalent blast radius, and the HMAC construction here
does not create a known cross-purpose attack against AES-GCM token sealing), but it is exactly the
kind of shortcut a real security review would flag before production. Fix: require a dedicated
`CAMPAIGN_POLICY_SECRET` in production (`validateStartupConfig` currently only requires it be at
least 16 characters if used; it does not yet forbid falling back to `TOKEN_ENCRYPTION_KEY` in
production). Not fixed in this session — flagged as a pre-launch task in the owner activation card.

**AUTO-03 (real, should-fix) — no crash-recovery test for fulfillment-task creation specifically.**
`fulfillment.process`'s create-then-persist sequence is crash-safe *by construction* (a crash before
`store.add` simply leaves the delivery unclaimed for the next run, deduplicated by `deliveryId`),
but no test in this session's suite explicitly simulates "crash between compute and persist, then
verify exactly one task exists after the next run." The pre-existing P2.2 cycle has this exact class
of test (CRASH-03/CRASH-05); the new fulfillment/monitoring/digest handlers do not yet have their
own equivalents. Not fixed in this session (would require a real subprocess-kill harness matching
the existing `p2-2-postgres-race.test.mjs` pattern); flagged as a concrete next task.

**AUTO-04 (real, should-fix) — expired campaign policies are silent, not an owner exception.**
`isCampaignPolicyActive` correctly blocks automation once a policy expires, but nothing adds an
"expiring soon" or "expired" row to `buildExceptionQueue`. An owner relying solely on the exception
queue could have automation silently stop (safe) without being told why (not ideal) until they
separately check policy state. Recommend adding a `policy_expiring`/`policy_expired` category.
Not fixed in this session; the underlying safety property (automation stops) is intact — this is
an observability gap, not a safety gap.

**AUTO-05 (real, should-fix) — new job handlers don't write their own structured log entries.**
`src/automation/job-handlers.mjs`'s six handlers rely entirely on `queue.mjs`'s generic
`queue_job_completed`/`queue_job_retry_scheduled`/`queue_job_dead_lettered` logs. Most pre-existing
handlers (e.g. `pipeline.mjs`) additionally emit domain-specific `store.log(...)` entries
(`ai_audit_failed`, `outbound_send_uncertain`, etc.) for operational visibility beyond generic
job-lifecycle events. The new handlers should do the same before relying on them in production.

**AUTO-06 (real, useful finding, not a defect) — Gmail has no native bounce/complaint webhook.**
Unlike SES/Postmark/SendGrid, Gmail's API has no feedback-loop/webhook for bounces or spam
complaints reachable by an arbitrary sender. This codebase's bounce/complaint detection
(`src/inbound-classify.mjs`) is entirely inbox-polling-based — it depends on a bounce or complaint
*landing back in the inbox as a message* and being correctly classified. This is a real, structural
ceiling on how fast and how reliably this system can detect deliverability problems if the outbound
provider decision (see `05_outbound_deliverability/`) stays with Gmail past the pilot stage. Not a
defect in this session's code — a decision input for the provider choice.

**AUTO-07 (real bug, found and fixed in this session) — fulfillment lane selection used the wrong signal.**
`selectFulfillmentLane` matched a regex against `delivery.selectedIssue.service` (a free-text
audit-finding label, e.g. "Website strategy") to decide whether a delivery needs client-authorized
site access, rather than the delivery's actual structural type. A diagnostic-only delivery whose
finding happened to mention "website" would have been misrouted to the `client_provider` lane, and
an implementation-sprint delivery whose finding was labeled something else would have been
misrouted to `mohamed`. **Fixed** in commit `49ae1ad`: detection now checks for the
`implement-scope` checklist item / `access-provisioned`/`written-authorization` input items that
`src/delivery.mjs`'s `implementation-sprint` template actually generates — the same structural
signal the delivery record's own site-change-authorization gate depends on. Regression tests added.
This is disclosed here specifically because "trust but verify, don't just restate the summary" is
what this phase asked for, and this is the concrete proof that happened.

## Overall Phase 1 verdict

**ACCEPT WITH CONDITIONS.** The automation core's safety properties (no real sends, no real
charges, no automatic site modification, `lite/` untouched, fake-provider-proven loop) hold up
under this adversarial pass, and one real bug was found and fixed. The conditions are the same two
already disclosed by the branch's own readiness doc (scheduler registration, owner UI) plus the
five findings above (AUTO-01 through AUTO-06), none of which are safety-breaking — all either
improve precision of a claim, close an observability gap, or harden a secret-management practice.
