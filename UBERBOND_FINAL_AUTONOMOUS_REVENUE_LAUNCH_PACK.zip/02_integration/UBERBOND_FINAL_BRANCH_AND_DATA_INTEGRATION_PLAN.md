# UberBond Final Branch and Data Integration Plan (condensed)

No merge performed or recommended in this session. This is a plan for a human-supervised merge.

## Source of truth per entity

| Entity | Source of truth | Why |
|---|---|---|
| Prospect identity/dedup | `src/prospect-import.mjs` (existing) | Already handles domain/campaign/source-key uniqueness; `src/automation/apify-import.mjs` routes through it rather than duplicating |
| Inbound message classification | `src/autonomy-cycle.mjs` + `inboundWorkItems` (PR #5) | Privacy-hardened, keep as-is |
| Outreach reply classification | `src/replies.mjs` + `replies` collection (existing) | Separate from inbound-only cycle by design; do not merge these two reply paths — they serve different scopes (outreach replies vs. read-only inbox monitoring) |
| Campaign/policy | `campaigns` collection (existing) + new `policyId`/`policyExpiresAt`/signature fields (this session) | Additive only |
| Fulfillment | new `fulfillmentTasks` collection (this session), keyed to existing `deliveries` | Additive only |
| Monitoring | existing `subscriptions` collection, new consent/cancel/failure functions (this session) | Additive only |

## Branch/merge order (recommended, not executed)

1. Merge `p2/stale-recovery-ci` → `main` (PR #2) first — oldest, smallest, already CI-gated.
2. Merge `p2.1/autonomous-reply-sync` → `main` (PR #3).
3. Resolve PR #4 vs. PR #5 — PR #5 explicitly supersedes PR #4 ("replaces the earlier rejected PR #4
   attempt"); close PR #4 without merging, merge PR #5 (`claude/uberbond-pr4-max-score-2vmv60`) →
   `main`.
4. Rebase `automation/full-commercial-loop` onto the resulting `main`, re-run the full 404-test
   suite, re-verify zero `lite/` diff, then open its own PR.
5. Only after step 4 lands: apply the revenue-pilot pack's `src/revenue-pilot/*` files (from the
   `UBERBOND_OWNER_LIGHT_FIRST_PAYMENT_SYSTEM.zip` upload) as a new PR, resolving the one real naming
   overlap — its own `state-machine.mjs` and `policy.mjs` should be treated as a second,
   revenue-pilot-specific vocabulary and either renamed (e.g. `src/revenue-pilot/state-machine.mjs`
   keeps its own name, does not collide with `src/automation/state-machine.mjs`) or retired in favor
   of the newer unified one — a real decision an owner or engineer should make deliberately, not
   something this session should decide unilaterally by deleting someone else's accepted work.

## Compatibility tests before any real merge

Run `npm run check:full` after each step above, plus a fresh `git diff --exit-code <previous-step's
tip> -- lite/` before proceeding to the next step. Keep a rollback checkpoint (`git tag` or bundle,
matching the pattern PR #5's own CI pack already uses) after each successful step.
