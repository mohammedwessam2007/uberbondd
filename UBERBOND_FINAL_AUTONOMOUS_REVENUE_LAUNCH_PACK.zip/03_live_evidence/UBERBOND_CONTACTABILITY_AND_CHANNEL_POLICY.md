# UberBond Contactability and Channel Policy — Reconsidered

## What actually blocked SEND_READY last time

The prior pass reviewed 100 real Phoenix-metro residential HVAC businesses, found 24
evidence-qualified candidates (real websites, real reproducible defects, real business identity —
see `UBERBOND_FIRST_100_VERIFIED_TARGETS.xlsx`, dated 2026-07-22), and then applied a strict rule:
only an explicit "vendor inquiries" channel or a clearly general-business inbox counted as a valid
outreach channel — a homeowner-facing "request service"/"book now"/"get an estimate" form never
counts, correctly, because submitting a B2B sales pitch through a form designed and expected to be
used by paying customers needing HVAC service is inappropriate use of that channel and reflects
badly on the sender regardless of legality. Under that rule, 22 of the 24 had **no** recorded
channel other than such a form, so SEND_READY landed at 0.

## Re-verification attempted this session

This session tried to re-open all 24 source URLs live via an automated fetch tool to (a) confirm
the evidence is still visible today and (b) look specifically for a general company email in the
footer/contact page that the prior pass might not have recorded. **This failed as a tooling matter,
not a business-research matter**: this session's web-fetch tool returned HTTP 403 for every URL
tried, including a plain static test page with zero bot protection, meaning the fetch capability
itself was unavailable this session — not that these sites are blocking automated review. Search
(not direct fetch) worked normally and was used instead: it independently corroborated that
MechaniCool, Perfection Air, and Generation Air are real, currently-operating, independently
reviewable Phoenix-area HVAC businesses (BBB rating, Yelp/Facebook/Nextdoor presence, named owners,
physical addresses) — consistent with, not contradicting, the prior pass's findings. This is
disclosed honestly rather than papered over: **the exact live page text was not independently
re-fetched this session**, so "still visible today" for all 24 remains unconfirmed pending a real
browser re-open, which is exactly what the existing `UBERBOND_TOMORROW_MORNING_ACTION_CARD.md`
already asks Mohamed to do for the top 5 in a 30-minute pass.

## The policy question: is "vendor" too strict?

Answer: **partially — refine it, don't remove it.**

**Keep prohibited, unchanged:** submitting through any homeowner-facing service/booking/estimate/
emergency form. This channel is designed for paying customers in an active HVAC-need moment;
using it for a B2B sales pitch would be a channel-mismatch regardless of legality, and doing so
programmatically at any scale would look like intake abuse to the business receiving it.

**Newly allow, with two confidence tiers:**
- **High confidence** — a published email whose local part signals a general/administrative inbox
  (`office@`, `info@`, `admin@`, `contact@`, `hello@`) rather than a customer-facing function. This
  is the functional equivalent of "general business inquiry," which the original policy already
  intended to allow but under-specified.
- **Medium confidence, owner-flagged** — a published email whose local part could plausibly serve
  both purposes (e.g. `service@`) for a small operator with only one inbox. Route to owner manual
  review rather than auto-approve, since "service@" could mean "customer service intake" at some
  companies and "the one inbox we have" at others — a human glancing at the site can usually tell in
  seconds; an automated policy cannot reliably.

This does not weaken CAN-SPAM/legal compliance in any way — it only changes which already-public,
already-general-purpose company inboxes are considered an appropriate delivery channel for a
respectful, evidence-based, single-issue, opt-out-included message. It still excludes personal
named-individual emails, social DMs, phone, text, and any consumer-intake channel.

## Reclassification of the existing 24 under the refined policy

| ID | Business | Recorded contact | New classification | Reasoning |
|---|---|---|---|---|
| PHX-001 | Falcon Air Conditioning | `service@gofalconair.com` + service form | **MEDIUM — owner review** | "service@" ambiguous per above |
| PHX-007 | Generation Air | `office@genair.com` + contact form | **HIGH — SEND_READY channel**, pending live-evidence re-open | "office@" is a clean general-business signal; WebSearch this session independently corroborated Generation Air as a real, Arizona-owned, multi-generation family HVAC business |
| PHX-002 through PHX-006, PHX-008 through PHX-024 (22 records) | various | form only, no email on record | **HOLD — channel not yet established** | No general-business email currently on record; needs a footer/contact-page re-check (blocked this session by the fetch-tool outage above), not a policy change |

## Applying the new mission's stricter evidence bar to the same 24

Independent of the channel question, the new mission also requires rejecting typo-only and
extraction-artifact findings more strictly than the prior pass did. Re-scored on that basis alone
(evidence text only, from the existing recorded observations, not re-fetched):

| Downgrade to REJECT (typo-only / trivial, insufficient commercial significance for a $500 sprint) | Reason |
|---|---|
| PHX-003 Superior Heating & Air Conditioning | Single-word nav typo ("Air Conditoning") only |
| PHX-013 Hub Heating & Cooling | Single-phrase typo ("duck work") only |
| PHX-021 Bumble Bee Air Conditioning | Minor grammar only, low severity |
| PHX-022 Arctic Fox Air Conditioning | Alt-text typo only — not visible to a normal visitor |
| PHX-023 Cool Blew | Obsolete footer social link only — trivial, not a conversion-path defect |
| PHX-024 King HVAC | Punctuation/possessive-form issue only |

| Flag as SUSPECTED EXTRACTION ARTIFACT — needs real-browser re-verification before reuse, neither approved nor rejected | Reason |
|---|---|
| PHX-002 Honest Air Conditioning, PHX-006 J & M Cooling & Heating | Both record a stray "Δ" character, which is the classic signature of an unrendered hidden form-builder field (e.g. a honeypot/spam-trap input) being captured by an HTML-level crawl rather than something a real visitor with a normal browser would ever see. Until confirmed with an actual rendered-browser open, this should not be relied on as visible evidence. |
| PHX-006 (also) | `{vendor_count}`/`{title}` are template placeholder syntax — strongly suggests unrendered template code was captured, not live page output |
| PHX-010 MechaniCool, PHX-015 Perfection Air | "Untitled"/"Button"/"Free Text" default component labels are plausible real (embarrassing but real) unconfigured-CMS defects, **or** could be default labels a real visitor never sees because client-side JS replaces them at render time. Genuinely ambiguous without a live re-open. |

**Net effect:** of the original 24, under this session's combined channel-and-evidence
re-tightening: 1 candidate (Generation Air) is the strongest current SEND_READY-track record; 1
(Falcon Air) needs a 30-second owner judgment call on channel; 6 drop to REJECT outright; 3 need
re-verification with a real browser before being trusted either way; the remaining 13 stay HOLD on
channel grounds alone, unchanged.

This is a smaller number than the mission's "at least 10 SEND_READY" target. That target was not
met this session — see the final decision doc for what this means for launch readiness. It was not
met because of a genuine, disclosed constraint (no working live-fetch tool this session), not
because the research effort was abandoned.
