# UberBond First-1,000 Prospect Supply Operations Pack (condensed)

## Source comparison

| Source | Method | Volume | Cost | Contactability | Verdict |
|---|---|---|---|---|---|
| OpenStreetMap/Overpass | `src/discovery.mjs` (existing, already implemented) | Depends on OSM coverage density; Phoenix metro is well-mapped | Free | Requires a follow-up site visit per record for a contact channel — OSM itself rarely has email | **Primary** — already built, already tested, zero new cost |
| Arizona Registrar of Contractors public lookup | Manual/bounded scripted lookup against a public license-verification page | Bounded by manual review pace | Free | Confirms legitimacy, not contact channel | **Verification layer**, not a volume source |
| Apify (business-directory actors) | `src/automation/apify-import.mjs` (this session), gated off by default | Actor-dependent, typically hundreds/run | Apify usage-based pricing, roughly $0.01–0.05 per business-listing item depending on actor, plus a monthly platform minimum on paid plans | Often includes a business phone/category, rarely a general email directly | **Backup/volume source**, bounded by `APIFY_ENABLED=false` default and per-run caps |
| Chamber of Commerce / trade-association public listings | Manual review | Small, high-quality | Free | Sometimes includes a general contact | Secondary, low volume |

## Exact Overpass query pattern (already what `src/discovery.mjs` builds)

```
[out:json][timeout:30];
area["name"="Phoenix"]["admin_level"="8"]->.searchArea;
(
  node["shop"="hvac"](area.searchArea);
  node["craft"="hvac"](area.searchArea);
  node["office"="company"]["industry"="hvac"](area.searchArea);
);
out center;
```
(`src/discovery.mjs#normalizeCategories`/`parseBbox` already implement the equivalent programmatically with configurable categories and bounding boxes — this is illustrative, not a new capability.)

## Apify production setup (not activated — `APIFY_ENABLED=false` remains the default)

- Actor: a business-directory/Maps-style actor (exact actor selection is an owner decision — several
  reputable ones exist; do not activate without reviewing that specific actor's own terms of use for
  compliance with this project's no-personal-data, no-behind-login-scraping rules).
- Input JSON shape expected by `mapApifyItem` (see `src/automation/apify-import.mjs`): `title`,
  `website`, `categoryName`, `city`, `countryCode`, `placeId`, `ownerName` (optional), `description`
  (optional), `scrapedAt`.
- Budget cap: start at 100 items/run, `APIFY_POLL_MINUTES>=60`, hard stop if a run's cost exceeds a
  small fixed dollar ceiling (e.g. $5/run) — enforce this as an owner-configured actor-level limit,
  since nothing in this codebase enforces a dollar cap on a third-party platform.
- Retention: dataset items are only ever imported through `importProspects`, which already dedupes;
  do not separately retain raw Apify JSON beyond what's needed for one import pass.
- This session ran zero real Apify calls — `defaultApifyFetcher` exists but was never invoked; all
  Apify-path tests use an injected fake fetcher.

## Batch plan

100 → 500 → 1,000, each batch gated by: dedup rate below 20%, at least the same evidence-qualify
rate as the first-100 pass (24%) or better, and a fresh channel-policy check per the reconsidered
policy in `03_live_evidence/`. Stop early if the qualify rate drops sharply — that is itself a
signal the market/niche needs re-evaluating, not a reason to lower the evidence bar.
