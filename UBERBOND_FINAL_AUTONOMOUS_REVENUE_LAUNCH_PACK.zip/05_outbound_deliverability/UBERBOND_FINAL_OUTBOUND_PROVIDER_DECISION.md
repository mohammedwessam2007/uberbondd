# UberBond Final Outbound Provider Decision

Sources retrieved 2026-07-23 via web search (see citations). This reverifies, and materially
qualifies, the prior session's Gmail API recommendation rather than accepting it blindly.

## What changed from the prior recommendation

The prior recommendation ("Google Workspace Gmail API, outbound initially off, five-message pilot
ceiling") is **reaffirmed for the pilot stage specifically**, but this session's research surfaces a
real ceiling that should be disclosed rather than assumed away: real-world safe cold-outreach volume
on Gmail is far below its published quota. Google Workspace's daily API quota is 2,000/day, but
practitioner sources consistently report Gmail can flag or suspend accounts for cold-outreach-like
behavior at volumes as low as ~15–150 messages/day depending on account age/reputation, independent
of the quota ceiling — Gmail's abuse detection is behavioral, not purely quota-based [Unipile,
Prospeo — Gmail rate limits 2026]. This matches, and further justifies, this codebase's existing
conservative defaults (`OUTBOUND_HOURLY_CAP_A/B` default 5, `OUTBOUND_MIN_GAP_SECONDS` default 90).

**Structural limitation carried forward from the acceptance review (AUTO-06):** Gmail has no
bounce/complaint webhook reachable by an arbitrary sender — this system's bounce/complaint detection
is entirely inbox-polling-based. This is acceptable at pilot volume (a handful of messages/day, an
owner or the reply-poll cycle can catch a bounce within its poll interval) but becomes a real
deliverability-risk blind spot if volume scales past a few dozen/day without adding a provider with
native delivery-event webhooks.

## Decision

- **Phase 1 (pilot, ≤10/day):** Gmail API via Google Workspace, exactly as already built in
  `src/gmail.mjs`. Real Google Workspace domain payment history requirement noted: new Workspace
  accounts face additional sending restrictions until the domain has accumulated $100 in paid
  Workspace fees and 60 days have passed since — plan the pilot timeline around this, it is a real
  gating fact, not a formality [Nylas/Nylas CLI — Gmail API quotas 2026].
- **Phase 2 trigger (>50/day sustained, or the first real complaint/bounce spike):** move to a
  provider with native delivery-event webhooks — Postmark, Amazon SES, or Resend are the most
  commonly cited fits for transactional-adjacent low-volume B2B sending; this session did not do a
  full head-to-head cost/feature comparison of those three (out of this session's remaining time
  budget) and flags that as the next research task rather than guessing.
- **Backup/no-change:** keep `OUTBOUND_PROVIDER=test` as the code default; this decision only
  concerns what real credentials get configured when the owner is ready, and does not change any
  code default.

## Sources
- [Gmail API Limits in 2026 — Unipile](https://www.unipile.com/gmail-api-limits/)
- [Gmail API Quotas in 2026 — Nylas](https://developer.nylas.com/docs/cookbook/email/gmail-api-quotas/)
- [Gmail Rate Limits 2026 — Prospeo](https://prospeo.io/s/gmail-rate-limits)
