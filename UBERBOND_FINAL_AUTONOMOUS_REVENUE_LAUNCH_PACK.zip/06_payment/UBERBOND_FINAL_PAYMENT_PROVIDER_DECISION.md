# UberBond Final Payment Provider Decision

Sources retrieved 2026-07-23. This session's research materially challenges the prior
recommendation rather than accepting it — the prior "PayPal Egypt Business, primary" pick does not
hold up well under closer reading.

## What the research found

**PayPal:** Egypt has partial PayPal access, but real structural friction exists: there is no
locally registered PayPal entity in Egypt holding the necessary financial licenses, Egypt's central
bank maintains strict oversight of foreign-currency transactions that conflicts with PayPal's
USD-holding cross-border model, and Egypt's AML documentation requirements are not fully
accommodated by PayPal's standard onboarding for receiving accounts [doola — PayPal country
availability 2026]. This session did **not** find a source confirming full USD-invoicing/receiving
support for an Egypt-based business account. **Downgrade from "primary" to "requires a real-account
test before any reliance," same posture the prior session already correctly required but this
session found stronger reason to insist on.**

**Payoneer:** Confirmed available in Egypt with real, quantified costs: ~1% receive fee, ~3%
withdrawal fee, and up to 4.5% for EGP conversion — a total of roughly **8.5% ($85 on a $1,000
receipt)** when converting to EGP [Vaultleap — Payoneer fees 2026]. This is a real, material cost
against a $500 sprint price (~$42.50 lost to fees on a single sale) that must be priced into the
offer or margin, not glossed over. Since March 2025 Payoneer restructured withdrawal fees: $1.50
flat for same-currency withdrawals under $50,000, $4 flat for transfers under $400.

**Wise Business:** Confirmed to support receiving USD (ACH free, USD wire ~$4.14 fixed), with a
one-time ~$31 setup fee — meaningfully cheaper per-transaction than Payoneer if EGP conversion isn't
immediately needed (e.g. holding USD in a Wise multi-currency balance). **This session's search did
not find explicit confirmation that individuals/businesses based in Egypt can currently open a Wise
Business account** — this is the single most important unresolved question for the payment decision
and should be Mohamed's first real-account test, ahead of PayPal.

## Decision

- **Primary to test first, in this order:** (1) Wise Business — cheapest if account-opening from
  Egypt is confirmed; (2) Payoneer — confirmed available, cost is known and acceptable at pilot
  volume (~$42.50/sale is tolerable against a $500 price when only a handful of sales are expected in
  the pilot); (3) PayPal Egypt Business — keep as a third option, not primary, given the
  no-local-entity/AML friction found above.
- **None of the three is "verified" until Mohamed performs the real-account test** in
  `UBERBOND_REAL_ACCOUNT_PAYMENT_TEST_CARD.md` (unchanged requirement from the prior session,
  reaffirmed here).
- **Manual/invoice-first fallback:** this codebase's existing `provider=manual` payment path
  (`src/payments.mjs`, `confirmManualPayment`) already supports an owner manually confirming a
  payment received by any means (bank transfer, in-person, etc.) — this is a real, already-built,
  zero-additional-integration fallback if all three above prove unworkable, and should not be
  dismissed as a lesser option; it is fully idempotent and audited exactly like the automated
  providers.

## Sources
- [Which Countries Can Fully Use PayPal in 2026 — doola](https://www.doola.com/blog/which-countries-can-fully-use-paypal/)
- [Payoneer Fees in 2026 — Vaultleap](https://vaultleap.com/blog/payoneer-fees-explained-2026)
- [Wise Business receive fees](https://wise.com/us/pricing/business/receive)
