# UberBond Egypt Legal, Tax, and Banking Decision Pack (informational research, not legal/tax advice)

Sources retrieved 2026-07-23. Mohamed should have this reviewed by a qualified Egyptian accountant/
tax lawyer before any real revenue — this is planning input, not professional advice, per this
mission's own explicit instruction.

## Verified facts (with source)

- Under Egyptian Resolution No. 281 of 2025, the mandatory VAT/e-invoicing registration revenue
  threshold was cut from EGP 500,000 to **EGP 250,000/year**; anyone whose 2025 revenue exceeded
  this figure has until **March 31, 2026** to register, with a fine of EGP 20,000 plus EGP 1,000/day
  compounding for late registration [DataValue Solutions — Egypt e-invoicing 2026].
- Separately, **freelancers earning above EGP 60,000/year must register with the Egyptian Tax
  Authority** — a much lower threshold than the VAT one above, and one that a handful of $500 sales
  would likely cross (EGP 60,000 ≈ USD 1,225 at a typical 2026 EGP/USD rate — i.e. **as few as 3
  sales** could cross this threshold).
- Exported services (a plausible characterization of UberBond's website-repair work sold to a US
  customer) may qualify for a 0% VAT rate — this session found this stated as a general possibility,
  not confirmed as automatically applicable to UberBond's specific structure; needs a professional
  opinion, not an assumption.

## Open questions for a professional (not answered by this research)

1. Should Mohamed operate as an individual freelancer or register a company, given the low EGP
   60,000 mandatory-registration threshold that a handful of pilot sales would likely cross?
2. Does UberBond's website-repair service qualify for the 0% export-of-services VAT treatment, and
   what documentation does that require?
3. What is the correct e-invoicing mechanism for a USD-denominated foreign sale under the ETA's
   platform, and does it apply below the EGP 250,000 VAT-registration threshold even though the
   lower EGP 60,000 freelancer-registration threshold applies?
4. What banking/reporting obligations apply to receiving recurring foreign-currency income (the
   $149/month monitoring upsell) versus one-time sales, under Egyptian central bank rules?
5. Does Central Bank of Egypt foreign-currency oversight (the same friction that complicates PayPal,
   per the payment decision doc) create any additional obligation when funds arrive via Payoneer or
   Wise rather than a direct bank wire?

## Recommendation

Do not proceed past the pilot's first real payment without at least one paid consultation with an
Egyptian accountant experienced in freelance/export-of-services income. The EGP 60,000 threshold is
low enough that this is a near-term, not distant, requirement — plan for it before the third real
sale, not after a full year of revenue.

## Sources
- [Egypt E-Invoicing 2026: ETA Compliance Guide for SMEs — DataValue Solutions](https://datavalue.solutions/egypt-e-invoicing-eta-2026-sme-guide/)
- [Egypt Freelancers Registration Guide 2026 — Jobbers](https://www.jobbers.io/egypt-freelancers-cairo-tech-hub-complete-registration-guide-2026/)
