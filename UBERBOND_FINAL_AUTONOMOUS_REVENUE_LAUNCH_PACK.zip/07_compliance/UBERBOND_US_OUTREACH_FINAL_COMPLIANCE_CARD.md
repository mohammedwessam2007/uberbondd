# UberBond US Outreach Compliance Card (informational research, not legal advice)

Source: FTC-adjacent secondary summaries retrieved 2026-07-23 [Termly, Tomba — CAN-SPAM 2026 guides].
Mohamed should have this reviewed by a qualified US-outreach-familiar attorney before any real send
at volume; this card is operational planning only.

## The seven core CAN-SPAM rules, as they apply to this system

1. **Honest headers** — From/To/routing must accurately identify the real sender. This codebase's
   `src/gmail.mjs` sends from the connected, real Gmail account; no header spoofing exists in this
   codebase.
2. **Honest subject lines** — the subject must reflect the content. `src/copy.mjs`'s
   evidence-bound subject generation already ties the subject to the specific finding.
3. **Ad disclosure** — the message must be identifiable as commercial. Not yet explicit in the
   existing message templates; recommend a one-line addition, e.g. a footer stating this is a
   business outreach message.
4. **Physical postal address** — required in every message. **This system has no configured
   `BUSINESS_ADDRESS` yet** (`src/config.mjs`'s `sender.address` defaults to empty, and
   `validateStartupConfig` already correctly refuses to allow live outbound without it being set).
   This is a real, already-enforced blocker, not a new finding — but it means Mohamed needs a
   lawful, publishable postal address before any live send, which is its own open decision (see
   `UBERBOND_POSTAL_ADDRESS_DECISION_CARD` note below).
5. **Working opt-out** — already implemented (`src/unsubscribe.mjs`, one-click List-Unsubscribe
   header support in `pipeline.mjs`).
6. **Prompt opt-out processing** — CAN-SPAM requires honoring within 10 business days; this
   system's suppression list is applied immediately (same processing cycle), which exceeds the
   requirement.
7. **Monitor anyone hired to send on your behalf** — not applicable at solo-founder pilot scale.

## Penalty exposure (informational)

FTC's 2026 inflation-adjusted penalty is up to **$53,088 per individual non-compliant email** — each
message is a separate violation. This is a strong argument for keeping the pilot volume low and the
compliance checklist enforced in code (as `validateStartupConfig` already partially does) rather
than trusting manual diligence alone.

## Postal address decision (unresolved this session)

CAN-SPAM requires a "valid physical postal address," which can be a street address, a registered PO
box, or a commercial mail-receiving agency address meeting USPS standards — this session did not
independently verify which of those Mohamed can lawfully use from Egypt as a US-facing sender; this
is exactly the kind of question that needs either US-mail-forwarding-service research (a virtual US
mailbox service) or attorney input, not an assumption. Flagged as an open owner decision, not
resolved here.

## Suppression/recordkeeping

Already implemented: `store.suppressOutbound`, the `suppressions` collection, and the reply
classification pipeline's automatic suppression on bounce/complaint/unsubscribe. No new system is
needed — the existing implementation already satisfies "recordkeeping" in the sense of retaining
suppression decisions indefinitely (no TTL on the `suppressions` collection).
