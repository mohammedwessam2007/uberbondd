# UberBond Final Production Provider Decision

Sources retrieved 2026-07-23. Reaffirms the prior Railway + Neon recommendation with updated 2026
pricing detail rather than accepting the old cost figure unchanged.

## Runtime: Railway

Hobby plan: $5/month base credit; actual usage (vCPU/RAM billed per second, plus egress and volume
storage) is additional on top of that credit — the $5 is a minimum spend, not a flat fee
[srvrlss.io — Railway pricing 2026]. A single lightweight persistent Node worker plus a small web
process for this codebase's scale (a handful of scheduled jobs, no heavy compute) should stay in the
**$10–20/month** range including the base credit, materially in line with the prior estimate. Confirm
with a real trial before committing.

## Database: Neon

Launch plan: **no monthly minimum any more** — pricing dropped to $0.106/CU-hour compute + $0.35/GB-
month storage, both meaningfully cheaper than the pricing the prior session's estimate was likely
built on [comparedge.com — Neon pricing 2026]. At this codebase's low-volume pilot scale (a handful
of prospects/day, occasional worker ticks), Neon compute should be a few dollars/month with
scale-to-zero between ticks.

## Storage: Cloudflare R2 (unchanged recommendation)

Not independently re-priced this session (out of time budget) — the prior estimate's inclusion of
private R2 for evidence/screenshot storage remains reasonable and low-cost at this scale; re-verify
before committing real spend.

## Updated Phase-1 monthly cost estimate

| Component | Prior estimate | This session's reverified estimate |
|---|---:|---:|
| Railway | ~$10 | $10–20 (confirm with real trial) |
| Neon | ~$10 | likely lower given 2026 pricing drop — estimate $5–10 at pilot volume |
| Cloudflare R2 | ~$5 | not re-verified, carry forward ~$5 |
| Domain | ~$1.50/mo amortized | unchanged |
| **Core total** | **~$28.50** | **~$21.50–40.50**, most likely near the low end given Neon's price drop |

This is a range, not a point estimate, because actual Railway/Neon usage depends on real traffic
this session cannot observe. Recommend Mohamed start a real trial on both before committing to a
paid tier, and treat $40/month as the conservative planning ceiling rather than $28.50 as a promise.

## Sources
- [Railway Pricing 2026 — srvrlss.io](https://www.srvrlss.io/provider/railway/)
- [Neon Pricing 2026 — comparedge.com](https://comparedge.com/tools/neon-db/pricing)
