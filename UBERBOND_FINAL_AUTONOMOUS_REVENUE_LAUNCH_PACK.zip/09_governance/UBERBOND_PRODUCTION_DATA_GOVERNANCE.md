# UberBond Production Data Governance (condensed)

## Already implemented (pre-existing, verified by this session's full test-suite re-run)

- Suppression permanence: `suppressions` collection has no TTL/deletion path — permanent by default.
- Evidence/screenshot retention: `ARTIFACT_RETENTION_DAYS` (default 90) + `deleteExpiredArtifacts`.
- Inbound work-item retention: `INBOUND_WORK_ITEM_RETENTION_MS` (default 30 days), privacy-hardened
  (keyed hashes only, no raw content) per PR #5.
- Encrypted OAuth token storage (`src/crypto.mjs`, AES-GCM via `TOKEN_ENCRYPTION_KEY`).
- Structured audit log (`auditLog` collection, `store.log`) across most (not yet all — see AUTO-05
  in the acceptance review) code paths.

## New this session, not yet implemented

- Migration order for `fulfillmentTasks`/`automationDigests` is defined (`migrations/
  012_automation_layer.sql`, additive, already applied in every test run this session via PGlite).
- No dedicated retention policy yet exists for `automationDigests` (daily/weekly snapshots) — these
  will grow unbounded over time; recommend a simple TTL (e.g. 400 days) before relying on this in
  production for more than a year.
- No backup/PITR restore test has been performed this session (would require a real Postgres
  instance, out of scope for an in-memory/PGlite test run) — flagged as a pre-launch task.

## Recommendation before real launch

Perform one real backup-and-restore test against a real (not embedded) Postgres instance once
`DATABASE_URL` is configured, before the first real customer payment is processed. This is standard
practice this session cannot substitute for with a synthetic test.
