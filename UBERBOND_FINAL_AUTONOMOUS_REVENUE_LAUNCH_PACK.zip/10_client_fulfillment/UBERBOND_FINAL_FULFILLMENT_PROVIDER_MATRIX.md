# UberBond Fulfillment Provider Matrix (condensed)

Reuses the existing, already-solid offer/scope terms from `UBERBOND_FIRST_CASH_DECISION.md`
(uploaded pack) — $500 fixed scope, up to 3 defects, 5 business days after payment+access+scope,
one revision, $149/month optional monitoring, no result guarantee. Not rewritten here; see that
document for the full commercial terms, which this session did not find reason to change.

## Lane fit by platform (feeds `src/automation/fulfillment.mjs`'s lane-selection logic)

| Platform | Access model | Lane fit | Notes |
|---|---|---|---|
| WordPress | Admin login, ideally staging | Mohamed or contractor | Most common; rollback via plugin/manual backup |
| Wix / Squarespace / Webflow | Owner-invited collaborator access | Mohamed | No file-system access; changes are UI-only, lower risk |
| GoDaddy Website Builder | Owner-invited access | Mohamed | Similar to Wix |
| Shopify | Staff account, limited scope | Contractor if theme-code changes needed | Higher risk if editing theme code directly |
| Custom HTML/JS | Direct file/FTP or git access | Contractor | Requires real backup/rollback plan before any edit |
| Agency-controlled site | **Excluded by the offer's own hard disqualifiers** | client_provider (i.e., decline direct edits) | The existing offer document already disqualifies "another agency actively controlling the affected component" — correctly, since UberBond editing a site under someone else's active contract is a real conflict/liability risk |

Every lane requires `written-authorization` and `access-provisioned` to reach `received` status
before `implement-scope` can start — already enforced in code (`src/delivery.mjs`), unchanged.

## Contractor bench (not built this session)

No real contractor has been contacted or vetted — that would require actually reaching out to
people, outside this session's non-negotiables. Recommend Mohamed source 1-2 vetted WordPress/
Shopify contractors (e.g. via a marketplace) before volume exceeds what he can personally deliver in
5 business days, but only after the first 2-3 real paid deliveries prove the offer works end to end.
