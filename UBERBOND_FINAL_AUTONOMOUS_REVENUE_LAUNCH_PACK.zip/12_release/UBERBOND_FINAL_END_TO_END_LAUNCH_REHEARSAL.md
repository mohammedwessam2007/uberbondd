# UberBond Final End-to-End Launch Rehearsal

**This rehearsal actually executed against the real `automation/full-commercial-loop` code** (not a
description of what it should do) — see `rehearsal_log.json` in this folder for the raw, timestamped
output of every stage. 19 stages ran successfully in one pass, against an ephemeral temp-directory
store, zero real network calls, zero real credentials.

## Stage-by-stage result

| Stage | What ran | Result |
|---|---|---|
| A. DISCOVERED | Synthetic prospect inserted directly (a real Apify/Overpass import would go through `importProspects`, already covered by `automation-apify-import.test.mjs`) | pass |
| E. POLICY_ELIGIBLE | Real `signCampaignPolicy` + `isCampaignPolicyActive` + `evaluateAutomationGate` | policy active=true, gate ok=true |
| F. SEND_RESERVED / SENT | Real fake-provider reserve/send | reserved, sent |
| F. crash-after-reservation | Re-called `reserve` with the same idempotency key mid-"crash" | correctly returned the original reservation, `duplicate=true` |
| F. crash-after-send | Re-called `send` on the same reservation | correctly returned the original result, `duplicate=true`, no second send |
| G. REPLIED | Real `canTransition('SENT','REPLIED')` + a reply record | legal transition confirmed |
| N. forbidden transition | Real `assertTransition('SENT','PAID')` | correctly threw `StateMachineError` |
| H. PAID | Real `RevenueEngine.createOffer/approveOffer/issueCheckout/applyOfferPayment` (test provider) | paid, delivery auto-created |
| H. duplicate payment event | Re-applied the identical payment event | correctly deduplicated, `duplicate=true`, no double revenue event |
| I. ONBOARDING → FULFILLMENT_ACTIVE | Real `createFulfillmentTask` off the payment-gated delivery | lane=`mohamed` (correct: test-mode delivery, small diagnostic — see the AUTO-07 fix this made possible) |
| I. QA → DELIVERED | Real `updateFulfillmentTask`, QA checklist gate enforced | could not complete until all QA items marked complete, then succeeded |
| J. monitoring without consent | Real `handlers['monitoring.enroll']` called with empty consent | correctly rejected |
| J. MONITORING_ACTIVE | Same call with full consent + a real paid monitoring offer | enrolled, active |
| J. CANCELLED | Real `cancelMonitoringSubscription` | `nextRunAt` cleared immediately, no retention window |
| K. stale-job recovery | Real `store.recoverStaleJobs` against an artificially stale-locked job | recovered |
| L. exception queue | Real `buildExceptionQueue` against the accumulated store state | surfaced both the positive reply and the dead-letter job |
| M/K. daily digest | Real `handlers['digest.daily']` | generated a correct next-owner-action summary from live store state |

## What this rehearsal does NOT prove

- No real network call, real email, real payment, or real money movement occurred — by design.
- Concurrency was not truly adversarial (see acceptance-review finding AUTO-01) — this rehearsal, like
  the automated test suite, proves the contract, not real-world race conditions under I/O latency.
- The prospect→qualification→draft stages (crawl, evidence-scoring, contact discovery) were skipped
  in this specific rehearsal run for time — those stages are covered separately and extensively by
  the pre-existing 327-test suite, not re-run here to avoid duplicating that coverage.

## Bug found during this rehearsal's construction

The rehearsal initially failed at the payment-offer-creation step with `offer-evidence-required` —
this is `src/payments.mjs`'s pre-existing (and correct) requirement that an offer must be backed by
a real evidence-bound `prospect.issue` before a price can be attached to it. This is not a bug; it
is the payment-gate policy working as intended and catching an incomplete rehearsal setup. Recorded
here because "acceptance testing" should show its own false starts, not just a clean final run.
