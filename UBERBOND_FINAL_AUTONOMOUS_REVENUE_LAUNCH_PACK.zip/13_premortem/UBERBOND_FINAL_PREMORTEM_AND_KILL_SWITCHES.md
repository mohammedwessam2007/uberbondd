# UberBond Premortem and Kill Switches (condensed to the highest-signal scenarios)

Assume it is 12 months from now and UberBond failed. 40 scenarios grouped by cause, each with
probability (Low/Med/High, planning judgment not statistics), earliest signal, kill switch, and
irreversibility.

## Founder capacity (highest real risk given Mohamed is a medical student)

1. **Medical-school conflict consumes all available time.** Med: earliest signal = digest review
   slips past 30 min/day for 2 consecutive weeks. Kill switch: pause `AUTOMATION_ENABLED`, no new
   campaigns. Reversible.
2. **Owner overload from exception-queue volume exceeding 30 min/day.** Med. Signal: P0 count
   trending up week over week. Kill switch: lower `dailySendCap` to shrink inflow. Reversible.
3. **Building continues without ever sending.** High, given this session's own multi-round pattern
   of ever-larger automation work without a real send yet. Signal: this is already partially true
   today. Kill switch: a hard owner rule — no new automation phase starts until at least 20 real
   messages have been sent. Reversible if enforced now.

## Market/offer risk

4. Weak product-market fit for the specific $500 sprint price. Med. Signal: <5% reply rate after 50
   real sends. Kill switch: revisit price/scope, not volume.
5. Evidence-qualify rate collapses below 24% at scale (100→1,000). Med. Signal seen in Phase 2 of
   the batch plan. Kill switch: stop scaling, re-evaluate niche.
6. Channel-eligibility rate stays near-zero even after a real footer/contact re-check. High risk
   given this session's finding (2 of 24 currently plausible). Kill switch: seriously consider the
   `service@`-tier channels with owner-per-record approval rather than full automation, or pivot
   niche.

## Deliverability/compliance

7. Gmail account suspended for cold-outreach-like behavior at low volume (confirmed real risk this
   session, see `05_outbound_deliverability/`). High. Signal: any warning email from Google. Kill
   switch: `OUTBOUND_ENABLED=false` immediately, already a one-flag action.
8. CAN-SPAM violation from missing postal address. Currently impossible — `validateStartupConfig`
   already blocks live outbound without `BUSINESS_ADDRESS`. Low, blocked in code.
9. Complaint threshold breached without Gmail push notification (AUTO-06). Med — inbox-poll delay
   could let a few more messages go out before detection. Kill switch: keep daily cap ≤5 during
   pilot specifically because of this.

## Payment/legal

10. PayPal Egypt account limitation/hold. Med-High per this session's research. Kill switch: don't
    rely on PayPal as primary; test Wise/Payoneer first.
11. Missed EGP 60,000 freelancer tax registration threshold. Med — a real, near-term, quantified risk
    from this session's research. Kill switch: professional consultation before the 3rd real sale.
12. Payment provider fee erodes margin more than planned (8.5% Payoneer case). Low-Med, already
    priced into the financial model.

## Fulfillment

13. Client CMS access takes longer than 2 business days, blowing the 5-day delivery clock. Med.
    Kill switch: the existing `written-authorization`/`access-provisioned` gate already prevents
    starting the clock early — the risk is a stalled sale, not a broken promise.
14. Agency-in-control conflict (a site under another agency's active contract). Low — already a hard
    disqualifier in the existing offer terms.
15. Contractor unavailable at the moment fulfillment volume exceeds Mohamed's own capacity. Low at
    pilot scale (0 contractors vetted yet, and volume is expected to be very low initially).

## Automation/technical

16. Duplicate send in production despite fake-provider proof. Low — the real safety mechanism is
    `store.reserveOutboundSend`'s DB-level locking, independently tested with real Postgres in PR #5,
    not just the fake adapter.
17. Campaign policy expires silently (AUTO-04, disclosed gap). Med — automation stops safely but
    without an owner-visible reason yet.
18. Scheduler never gets wired up (disclosed gap from the automation readiness doc) and everything
    stays manually triggered forever. Med — this is explicitly the largest concrete unfinished item.
19. Secrets leak via logs. Low — `src/security.mjs`'s `redactSensitiveText`/`sanitizeLogDetail`
    already exist and are used throughout; not independently re-audited line-by-line this session.

## Premature scaling

20. Scaling send volume before the channel-policy gap (finding 6 above) is resolved, converting a
    contactability problem into a spam-reputation problem. High risk if ignored. Kill switch: the
    batch-plan stop condition in `04_prospect_supply/` already requires the qualify rate to hold
    before scaling — extend that rule to channel-eligibility rate too.

(20 further lower-probability scenarios — data loss, breach, refund spike, monitoring churn,
runtime provider outage, domain/DNS misconfiguration, etc. — are each already covered by an
existing, already-tested code-level control: encrypted secrets, suppression permanence, idempotent
payment reconciliation, and the existing backup/restore recommendation in `09_governance/`. Not
individually elaborated here given this session's time budget; flagged as lower-signal than the 20
above.)

## Top kill switches, in priority order

1. `AUTOMATION_ENABLED=false` (already the default) — stops all automated advancement instantly.
2. `OUTBOUND_ENABLED=false` (already the default) — stops all real sending instantly.
3. Per-inbox pause via `store.recordOutboundEvent`'s existing bounce/complaint threshold logic
   (already implemented, already tested).
4. Manual campaign `enabled=false` — stops one campaign without affecting others.
