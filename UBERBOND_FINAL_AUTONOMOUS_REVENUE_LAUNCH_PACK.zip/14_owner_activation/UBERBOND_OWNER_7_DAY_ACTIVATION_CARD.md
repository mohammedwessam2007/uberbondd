# UberBond Owner 7-Day Activation Card

One exact sequence. 30 minutes/day maximum. No decision fog.

## Day 1 — Verify, don't build
- Confirm `AUTOMATION_ENABLED=false` and `OUTBOUND_ENABLED=false` in every environment (should
  already be true — this is a check, not a change).
- Re-open `UBERBOND_TOMORROW_MORNING_ACTION_CARD.md`'s 5 named prospects (Perfection Air,
  MechaniCool, J & M Cooling & Heating, Generation Air, San Tan Air) in a real browser. For each,
  check the site footer/contact page for a general email (`office@`, `info@`, `admin@`,
  `contact@`) — this is the exact gap this session's tooling could not close. 30 min.

## Day 2 — Payment reality test
- Attempt to open a Wise Business account from Egypt. If it works, that changes the payment
  decision — record the result in `06_payment/`. If it fails, move to Payoneer. Do not send money
  yet, just test account opening and the receive-flow UI. 30 min.

## Day 3 — Payment reality test, continued
- Complete one unsent test invoice/payment-link flow on whichever provider passed Day 2. Screenshot
  the fee shown before confirming (do not actually complete a real transaction). Record in
  `UBERBOND_REAL_ACCOUNT_PAYMENT_TEST_CARD.md`. 30 min.

## Day 4 — Legal/tax consultation booking
- Book one paid consultation with an Egyptian accountant familiar with freelance/export-of-services
  income (not free advice-seeking — pay for a real answer given the EGP 60,000 threshold found this
  session). This is a phone call to schedule, not the consultation itself. 15 min.

## Day 5 — Postal address decision
- Research one lawful option for a publishable US-facing postal address (virtual mailbox service or
  similar) sufficient for CAN-SPAM's physical-address requirement. Do not purchase yet — compare 2-3
  options and their legitimacy for this exact purpose. 30 min.

## Day 6 — Automation review
- Read `01_automation_acceptance/UBERBOND_FULL_AUTOMATION_INDEPENDENT_ACCEPTANCE_REVIEW.md` in full.
  Decide: fix AUTO-02 (secret separation) and AUTO-04 (policy-expiry exception) before or after the
  first real send? (Recommendation: before — both are small, contained changes.) 20 min.

## Day 7 — Go/no-go checkpoint
- With Days 1-6 done, decide: is there now at least 1 real SEND_READY prospect with a confirmed
  general-business email and still-visible evidence? If yes, that is the first candidate for a
  single, manually-approved, owner-sent (not automated) test message — sending remains a separate,
  explicit, later decision this document does not make for you. If no, the correct move is
  continuing the footer-email research pass across more of the 24, not lowering the evidence bar.

## Kill switches (unchanged)
Stop immediately on any real reply, complaint, or uncertain state. Nothing in this card authorizes
an actual send — every step above is verification, testing, and research only.
