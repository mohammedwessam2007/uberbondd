# UberBond Ruthless Build / Do-Not-Build Decision

## Essential before the first real payment
- A confirmed real channel (general-business email) for at least 1 prospect — **not yet done**.
- One real payment-provider account test — **not yet done**.

## Essential before 100 real sends
- Scheduler registration for the automation-layer job types (disclosed gap).
- AUTO-02 fix (dedicated campaign-policy signing secret).
- AUTO-04 fix (expired-policy owner exception).

## Essential before approval-mode automation runs unattended
- Owner HTTP/UI routes for policy signing and monitoring consent (disclosed gap) — running
  `approval` mode without a human-reviewable way to see/renew the active policy is not appropriate.

## Essential before autonomous mode
- A real, out-of-band signed owner policy document (a governance artifact, not a config flag) —
  `AUTOMATION_AUTONOMOUS_CONFIRMED=true` alone should not be treated as sufficient authorization.

## What can wait
- The full 1,000-prospect supply pipeline (100 is plenty until the channel/reply-rate assumptions
  in the financial model are replaced with real observed data).
- Apify integration (Overpass is free and already sufficient at pilot volume).
- A dedicated contractor bench (not needed until Mohamed's own 5-business-day capacity is the
  binding constraint, which has not happened yet — zero real deliveries exist).
- Full DNS/deliverability infrastructure beyond what a single Google Workspace domain needs for a
  5-message/day pilot.

## What should never be built
- Automatic negotiation of price or scope (explicitly excluded by this mission and the underlying
  offer terms).
- Automatic website modification without per-delivery, per-instance human-confirmed access and
  authorization (already structurally prevented in `src/delivery.mjs`, should stay that way).
- A "vendor channel" workaround that uses homeowner service-request forms for B2B outreach (this
  session's policy reconsideration explicitly kept this prohibited).

## What is overengineered relative to current evidence
- The daily/weekly digest persistence layer (`automationDigests` collection) is real and tested but
  has no consumer yet beyond the control-center generator — reasonable to keep since it was cheap to
  build correctly, but not a reason to build more digest features before there is real send/reply
  data to summarize.
- A 15-phase, ~50-file external-launch process for a product that has not yet sent a single real
  message. The single highest-leverage next action is not another planning document — it is Day 1-3
  of the owner activation card above.
