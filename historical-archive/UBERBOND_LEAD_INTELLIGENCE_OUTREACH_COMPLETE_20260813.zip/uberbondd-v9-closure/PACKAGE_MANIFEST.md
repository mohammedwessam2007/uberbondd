# UberBond Lead Intelligence package

Packaged: 2026-08-13

This archive contains the UberBond V9 closure checkout plus the owner-facing Lead Intelligence layer benchmarked against Apollo, Clay and Instantly.

## Start here

1. `README.md`
2. `docs/lead-generation/BEST_LEAD_GENERATION_SOFTWARE_RESEARCH_2026-08-13.md`
3. `docs/lead-generation/LEAD_INTELLIGENCE_V3_2026-08-13.md`
4. `public/outreach.html`
5. `src/lead-intelligence-v3.mjs`

## Included

- Natural-language and structured local lead search.
- Fit, evidence, intent, contactability, suppression and freshness scoring.
- Domain/email deduplication, saved searches and public signal records.
- Provider-neutral, field-level enrichment waterfalls for owner imports and future BYOK adapters.
- Owner-only enrichment-plan and sequence-handoff routes with `providerCalls: 0` and `externalEffects: 0`.
- First-party capture contract, account-safe visitor activity, typed local enrichment, owner action queue and descriptive attribution.
- Durable JSON/Postgres intake, field-result and task collections with migration `017_lead_intelligence_v3.sql`.
- JSON/Postgres persistence, migration, UI, focused tests and full repository checks.
- Existing Outreach Workbench, V9 governance, opportunity factory and edited owner artifacts.
- Frozen USD 250 Website QA & Release-Readiness Diagnostic offer contract, truthful buyer-proof pack, demonstration report, delivery/acceptance SOP, and contract validator.

## Boundary

The build clones the operator workflow, not vendor code, protected databases, contact records, ranking models or LinkedIn data. Provider integrations remain deliberate BYOK/terms-compliant follow-up work.

No email, OAuth action, payment, deployment or external contact was performed while preparing this package.
