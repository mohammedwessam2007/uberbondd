BEGIN;

CREATE TABLE IF NOT EXISTS lead_searches (
  id text PRIMARY KEY,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'saved',
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_searches_updated_idx
  ON lead_searches(updated_at DESC);

CREATE TABLE IF NOT EXISTS lead_signals (
  id text PRIMARY KEY,
  prospect_id text NOT NULL REFERENCES prospects(id) ON DELETE CASCADE,
  type text NOT NULL,
  source_url text,
  observed_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_signals_prospect_idx
  ON lead_signals(prospect_id, observed_at DESC);

CREATE INDEX IF NOT EXISTS lead_signals_type_idx
  ON lead_signals(type, observed_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS lead_signals_digest_idx
  ON lead_signals(prospect_id, ((data->>'digest')))
  WHERE data->>'digest' IS NOT NULL;

CREATE TABLE IF NOT EXISTS lead_enrichment_runs (
  id text PRIMARY KEY,
  prospect_id text REFERENCES prospects(id) ON DELETE SET NULL,
  provider text,
  status text NOT NULL DEFAULT 'planned',
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_enrichment_runs_prospect_idx
  ON lead_enrichment_runs(prospect_id, created_at DESC);

INSERT INTO schema_migrations(version)
VALUES ('016_lead_generation_surface')
ON CONFLICT DO NOTHING;

COMMIT;
