BEGIN;

CREATE TABLE IF NOT EXISTS lead_intake_events (
  id text PRIMARY KEY,
  prospect_id text REFERENCES prospects(id) ON DELETE SET NULL,
  account_key text,
  kind text NOT NULL,
  source_type text NOT NULL,
  status text NOT NULL DEFAULT 'needs_owner_review',
  observed_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_intake_events_status_idx
  ON lead_intake_events(status, observed_at DESC);

CREATE INDEX IF NOT EXISTS lead_intake_events_account_idx
  ON lead_intake_events(account_key, observed_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS lead_intake_events_digest_idx
  ON lead_intake_events((data->>'digest'))
  WHERE data->>'digest' IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS lead_intake_events_idempotency_idx
  ON lead_intake_events((data->>'idempotencyKey'))
  WHERE data->>'idempotencyKey' IS NOT NULL AND data->>'idempotencyKey' <> '';

CREATE TABLE IF NOT EXISTS lead_field_results (
  id text PRIMARY KEY,
  prospect_id text REFERENCES prospects(id) ON DELETE CASCADE,
  field text NOT NULL,
  provider text NOT NULL,
  status text NOT NULL,
  observed_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_field_results_prospect_idx
  ON lead_field_results(prospect_id, observed_at DESC);

CREATE INDEX IF NOT EXISTS lead_field_results_field_idx
  ON lead_field_results(field, status, observed_at DESC);

CREATE TABLE IF NOT EXISTS lead_tasks (
  id text PRIMARY KEY,
  prospect_id text REFERENCES prospects(id) ON DELETE SET NULL,
  account_key text,
  task_type text NOT NULL,
  status text NOT NULL DEFAULT 'ready',
  priority integer NOT NULL DEFAULT 0,
  due_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS lead_tasks_queue_idx
  ON lead_tasks(status, priority DESC, due_at ASC NULLS FIRST);

CREATE INDEX IF NOT EXISTS lead_tasks_prospect_idx
  ON lead_tasks(prospect_id, updated_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS lead_tasks_active_dedupe_idx
  ON lead_tasks((data->>'dedupeKey'))
  WHERE data->>'dedupeKey' IS NOT NULL AND status IN ('ready', 'blocked');

INSERT INTO schema_migrations(version)
VALUES ('017_lead_intelligence_v3')
ON CONFLICT DO NOTHING;

COMMIT;
