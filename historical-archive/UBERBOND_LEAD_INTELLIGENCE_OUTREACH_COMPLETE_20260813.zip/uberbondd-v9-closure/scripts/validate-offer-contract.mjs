import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const contractPath = path.join(root, 'data/opportunity-factory/website-qa-diagnostic-offer.json');
const offerDocPath = path.join(root, 'docs/opportunities/WEBSITE_QA_DIAGNOSTIC_OFFER_CONTRACT_2026-08-13.md');
const packPath = path.join(root, 'docs/opportunities/QA_DIAGNOSTIC_BUYER_PROOF_PACK_2026-08-13.md');
const demoPath = path.join(root, 'docs/opportunities/qa-diagnostic-demo/FICTIONAL_WEBSITE_QA_DEMONSTRATION_REPORT.md');
const sopPath = path.join(root, 'docs/opportunities/WEBSITE_QA_DIAGNOSTIC_DELIVERY_ACCEPTANCE_SOP_2026-08-13.md');

const [contractText, offerDoc, pack, demo, sop] = await Promise.all([
  fs.readFile(contractPath, 'utf8'),
  fs.readFile(offerDocPath, 'utf8'),
  fs.readFile(packPath, 'utf8'),
  fs.readFile(demoPath, 'utf8'),
  fs.readFile(sopPath, 'utf8')
]);
const contract = JSON.parse(contractText);

assert.equal(contract.schemaVersion, 'uberbond.offer-contract.v1');
assert.equal(contract.status, 'FROZEN_OWNER_REVIEW_ONLY');
assert.equal(contract.activeExperiment, true);
assert.equal(contract.offer.priceUsd, 250);
assert.equal(contract.offer.currency, 'USD');
assert.equal(contract.offer.timeline.deliveryWindow, '12–24 hours after all startsAfter conditions are satisfied');
assert.equal(contract.offer.payment.due, '100% before fulfilment begins');
assert.equal(contract.scope.included.includes('up to three public, unauthenticated websites'), true);
assert.equal(contract.externalEffects.providerCalls, 0);
assert.equal(contract.externalEffects.emailsSent, 0);
assert.equal(contract.externalEffects.formsSubmitted, 0);
assert.equal(contract.externalEffects.paymentsCharged, 0);
assert.equal(contract.externalEffects.authorization, 'NONE');
assert.equal(contract.ownerGates.some(item => item.includes('prior-contact protected')), true);
assert.equal(contract.killConditions.length >= 7, true);

for (const [label, content] of [
  ['offer contract', offerDoc],
  ['buyer-proof pack', pack]
]) {
  assert.match(content, /USD 250/iu, `${label} must preserve the fixed price`);
  assert.match(content, /payment/iu, `${label} must preserve the payment boundary`);
}
assert.match(sop, /USD 250/iu, 'delivery SOP must preserve the fixed price');
assert.match(sop, /payment/iu, 'delivery SOP must preserve the payment boundary');
assert.match(demo, /cleared payment/iu, 'demonstration report must preserve the delivery boundary');
assert.match(demo, /FICTIONAL DEMONSTRATION/iu);
assert.match(demo, /NOT CUSTOMER WORK/iu);
assert.match(pack, /not customer work/iu);
assert.match(sop, /Do not log in/iu);
assert.match(sop, /Never blind-retry/iu);

console.log('offer contract validation: PASS');
console.log(JSON.stringify({
  offerId: contract.id,
  priceUsd: contract.offer.priceUsd,
  deliveryWindow: contract.offer.timeline.deliveryWindow,
  maxPublicWebsites: 3,
  providerCalls: contract.externalEffects.providerCalls,
  externalEffectsAuthorized: contract.externalEffects.authorization !== 'NONE'
}, null, 2));
