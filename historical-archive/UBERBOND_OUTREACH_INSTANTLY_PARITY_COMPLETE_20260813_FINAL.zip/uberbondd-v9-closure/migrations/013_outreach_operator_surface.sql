BEGIN;

CREATE TABLE IF NOT EXISTS lead_lists (
  id text PRIMARY KEY,
  name text NOT NULL,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS reply_drafts (
  id text PRIMARY KEY,
  prospect_id text REFERENCES prospects(id) ON DELETE SET NULL,
  thread_id text,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS reply_drafts_prospect_idx ON reply_drafts(prospect_id, created_at DESC);

INSERT INTO schema_migrations(version)
VALUES ('013_outreach_operator_surface')
ON CONFLICT DO NOTHING;

COMMIT;
