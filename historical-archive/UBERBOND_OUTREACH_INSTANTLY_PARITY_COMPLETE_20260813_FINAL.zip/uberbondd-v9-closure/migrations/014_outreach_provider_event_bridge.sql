BEGIN;

ALTER TABLE outbound_events ADD COLUMN IF NOT EXISTS provider_event_id text;
CREATE UNIQUE INDEX IF NOT EXISTS outbound_events_provider_event_unique
  ON outbound_events(provider_event_id)
  WHERE provider_event_id IS NOT NULL AND provider_event_id <> '';

CREATE TABLE IF NOT EXISTS provider_events (
  id text PRIMARY KEY,
  provider text NOT NULL,
  provider_event_key text NOT NULL UNIQUE,
  provider_event_id text,
  event_type text NOT NULL,
  campaign_id text,
  lead_email text,
  status text NOT NULL,
  received_at timestamptz NOT NULL,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS provider_events_received_idx
  ON provider_events(received_at DESC);
CREATE INDEX IF NOT EXISTS provider_events_campaign_idx
  ON provider_events(campaign_id, received_at DESC);

INSERT INTO schema_migrations(version)
VALUES ('014_outreach_provider_event_bridge')
ON CONFLICT DO NOTHING;

COMMIT;
