BEGIN;

CREATE TABLE IF NOT EXISTS automation_plans (
  id text PRIMARY KEY,
  name text NOT NULL,
  trigger text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL
);

CREATE INDEX IF NOT EXISTS automation_plans_enabled_idx
  ON automation_plans(enabled, updated_at DESC);

CREATE TABLE IF NOT EXISTS automation_runs (
  id text PRIMARY KEY,
  plan_id text NOT NULL REFERENCES automation_plans(id) ON DELETE CASCADE,
  event_key text NOT NULL,
  status text NOT NULL,
  created_at timestamptz,
  updated_at timestamptz,
  data jsonb NOT NULL,
  UNIQUE (plan_id, event_key)
);

CREATE INDEX IF NOT EXISTS automation_runs_plan_idx
  ON automation_runs(plan_id, created_at DESC);

INSERT INTO schema_migrations(version)
VALUES ('015_outreach_automation_runs')
ON CONFLICT DO NOTHING;

COMMIT;
