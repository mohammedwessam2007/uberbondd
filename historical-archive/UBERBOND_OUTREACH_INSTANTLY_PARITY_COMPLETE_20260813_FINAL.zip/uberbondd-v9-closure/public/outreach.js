const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
let token = localStorage.revenueEngineToken || localStorage.nightshiftToken || '';
let activeView = 'overview';
let selectedThreadId = '';
let editorModel = null;
let data = { summary: {}, workspace: {}, comparison: {}, edgePlan: {}, analytics: {}, health: {}, campaigns: [], prospects: [], suppressions: [], inbox: [], automations: [] };

$('#token').value = token;

const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const api = async (path, options = {}) => {
  const headers = { authorization: `Bearer ${token}`, ...(options.headers || {}) };
  if (options.body && typeof options.body === 'string' && !headers['content-type']) headers['content-type'] = 'application/json';
  const response = await fetch(path, { ...options, headers });
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('json') ? await response.json() : await response.text();
  if (!response.ok) throw new Error(payload?.error || payload || `Request failed (${response.status})`);
  return payload;
};
const fmtDate = value => value ? new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
const shortDate = value => value ? new Date(value).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
const money = value => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Number(value || 0));
const statusClass = value => ['ready', 'sent', 'replied', 'active', 'healthy', 'accepted', 'paid', 'recurring'].includes(String(value || '').toLowerCase()) ? 'good' : ['suppressed', 'bounce', 'complaint', 'stopped', 'paused', 'error', 'blocked'].includes(String(value || '').toLowerCase()) ? 'bad' : 'warn';
const chip = value => `<span class="status-chip ${statusClass(value)}">${esc(value || '—')}</span>`;
const clone = value => JSON.parse(JSON.stringify(value));
const toast = (message, error = false) => {
  const element = $('#toast');
  element.textContent = message;
  element.style.borderColor = error ? 'rgba(255,126,134,.5)' : '';
  element.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('show'), 3500);
};
const clientDefaultSequence = offer => ({
  schemaVersion: 'uberbond.outreach-workbench.v1', version: 1,
  settings: { stopOnReply: true, stopOnPositiveReply: true, stopOnUnsubscribe: true, stopOnBounce: true, stopOnOpportunity: true, stopOnPayment: true, maxNewLeadsPerDay: 0, prioritizeNewLeads: false, limitEmailsPerCompanyPerDay: 0, deliveryOptimization: 'default', insertUnsubscribeHeader: false, autoOptimize: false, autoOptimizeMetric: 'replyRate', minimumOptimizationSamples: 25, sendWindow: { start: 9, end: 17, weekdays: [1, 2, 3, 4, 5], timezone: 'recipient', minGapMinutes: 5, randomGapMinutes: 0 } },
  steps: [
    { id: 'step-1', name: 'Initial observation', kind: 'initial', delayValue: 0, delayUnit: 'days', delayDays: 0, condition: 'always', variants: [{ id: 'A', label: 'Variant A', weight: 100, subject: 'A quick observation about {{company}}', body: 'Hi {{company}} team,\n\nI reviewed the public website and noticed:\n\n{{issueTitle}}\n{{issueExcerpt}}\n\nI can help with {{offer}}. If useful, I can send a concise evidence-backed starting point.\n\nBest,\n{{senderName}}\n{{senderCompany}}\n\nP.S. If this is not relevant, {{unsubscribeUrl}}' }] },
    { id: 'step-2', name: 'Useful follow-up', kind: 'followup', delayValue: 3, delayUnit: 'days', delayDays: 3, condition: 'no_reply', variants: [{ id: 'A', label: 'Variant A', weight: 100, subject: 'Re: A quick observation about {{company}}', body: 'Hi {{company}} team,\n\nA short follow-up on the observation above. The practical starting point would be {{offer}}; the goal is to give you a small, reviewable repair queue rather than a broad redesign.\n\nShould I prepare the outline?\n\nBest,\n{{senderName}}' }] },
    { id: 'step-3', name: 'Close the loop', kind: 'breakup', delayValue: 5, delayUnit: 'days', delayDays: 5, condition: 'no_reply', variants: [{ id: 'A', label: 'Variant A', weight: 100, subject: 'Close the loop — {{company}}', body: 'Hi {{company}} team,\n\nI will close the loop here so I do not crowd your inbox. If {{offer}} becomes useful later, this thread will remain easy to find.\n\nBest,\n{{senderName}}' }] }
  ]
});

function navigate(view) {
  activeView = view;
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === view));
  $$('.workbench-view').forEach(item => item.classList.toggle('active', item.id === `view-${view}`));
  if (view === 'campaigns' && !editorModel) selectCampaign(data.campaigns.find(item => !item.systemKey)?.id || '');
  if (view === 'inbox') renderInbox();
  if (view === 'automations') renderAutomations();
  if (view === 'prospects') renderProspects();
}

function metric(label, value, note = '') { return `<div class="metric-card"><b>${esc(value)}</b><span>${esc(label)}</span>${note ? `<small>${esc(note)}</small>` : ''}</div>`; }

function renderComparison() {
  const comparison = data.comparison?.scores ? data.comparison : data.workspace?.comparison;
  if (!comparison?.scores) return;
  const score = comparison.scores;
  const ownerWins = (comparison.rows || []).filter(row => row.winner === 'UberBond');
  $('#comparison-verdict').textContent = score.uberbondWins ? 'UBERBOND WINS OWNER OBJECTIVE' : 'REVIEW WEIGHTING';
  $('#comparison-summary').innerHTML = [
    metric('UberBond weighted score', `${score.uberbond}/5`, `${ownerWins.length} weighted use-case wins`),
    metric('Instantly weighted score', `${score.instantly}/5`, 'infrastructure advantage'),
    metric('Decision margin', `${score.margin >= 0 ? '+' : ''}${score.margin}`, 'transparent model, not a network-size claim')
  ].join('');
  $('#comparison-wins').innerHTML = ownerWins.slice(0, 6).map(row => `<div class="comparison-win"><b>${esc(row.label)}</b><span>${esc(row.basis)}</span></div>`).join('');
  renderSectorSummary(comparison.detailedComparison);
}

function renderSectorSummary(detailed) {
  if (!detailed?.aggregates) return;
  const functional = detailed.aggregates.functional;
  const industry = detailed.aggregates.industry;
  const strongest = (detailed.strongestUberBondSectors || []).slice(0, 4);
  $('#comparison-sector-summary').innerHTML = `<div class="sector-summary-metrics">${metric('Functional sectors', `${functional.sectorCount}`, `${functional.sectorWins} group wins · ${functional.dimensionWins} dimension wins`)}${metric('Industry sectors', `${industry.sectorCount}`, `${industry.uberbondWins} UberBond fits · ${industry.ties} ties`)}${metric('Functional margin', `+${functional.scores.margin}`, `${functional.scores.uberbond} UberBond vs ${functional.scores.instantly} Instantly`)}${metric('Industry-fit margin', `+${industry.scores.margin}`, `${industry.scores.uberbond} UberBond vs ${industry.scores.instantly} Instantly`)}</div><div class="sector-lead-grid">${strongest.map(item => `<div class="sector-lead"><b>${esc(item.sector)}</b><strong>${esc(item.label)}</strong><span>UberBond +${esc(item.margin)}</span></div>`).join('')}</div>`;
}

function renderComparisonTable(rows, industry = false) {
  if (industry) return `<table class="workbench-table comparison-detail-table"><thead><tr><th>Industry sector</th><th>UberBond</th><th>Instantly</th><th>Winner</th><th>Best use</th></tr></thead><tbody>${rows.map(row => `<tr><td><b>${esc(row.label)}</b><small>${esc(row.basis)}</small></td><td>${esc(row.scores.uberbond)}</td><td>${esc(row.scores.instantly)}</td><td>${esc(row.winner)}</td><td>${esc(row.bestUse || '')}</td></tr>`).join('')}</tbody></table>`;
  return rows.map(sector => `<div class="comparison-sector-block"><h3>${esc(sector.label)} · ${esc(sector.winner)}</h3><p class="muted">${esc(sector.description || '')} · UberBond ${esc(sector.scores.uberbond)} vs Instantly ${esc(sector.scores.instantly)} · margin ${sector.scores.margin >= 0 ? '+' : ''}${esc(sector.scores.margin)}</p><table class="workbench-table comparison-detail-table"><thead><tr><th>Dimension</th><th>UberBond</th><th>Instantly</th><th>Winner</th><th>Evidence basis</th></tr></thead><tbody>${sector.dimensions.map(row => `<tr><td><b>${esc(row.label)}</b></td><td>${esc(row.uberbond)}</td><td>${esc(row.instantly)}</td><td>${esc(row.winner)}</td><td><small>${esc(row.basis)}</small></td></tr>`).join('')}</tbody></table></div>`).join('');
}

function openDetailedComparison() {
  const comparison = data.comparison?.scores ? data.comparison : data.workspace?.comparison;
  const detailed = comparison?.detailedComparison;
  if (!detailed) return toast('Detailed comparison is still loading', true);
  openModal(`<div class="eyebrow">MULTI-SECTOR COMPARISON</div><h2>UberBond vs Instantly</h2><p class="muted">${esc(detailed.method.interpretation)} ${esc(detailed.method.evidenceRule)}</p><div class="modal-section"><h3>Functional platform sectors · ${esc(detailed.aggregates.functional.sectorCount)} sectors / ${esc(detailed.aggregates.functional.dimensionCount)} dimensions</h3>${renderComparisonTable(detailed.functionalSectors)}</div><div class="modal-section"><h3>Buyer-industry fit · ${esc(detailed.aggregates.industry.sectorCount)} sectors</h3>${renderComparisonTable(detailed.industrySectors, true)}</div><div class="modal-section"><h3>Current Instantly advantages</h3><p class="muted">${esc(detailed.limitations[0])}</p>${(detailed.strongestInstantlySectors || []).map(item => `<p><b>${esc(item.sector)} · ${esc(item.label)}</b> — Instantly advantage ${esc(Math.abs(item.margin))} points</p>`).join('')}</div><button class="button gold" id="modal-close-action">Close</button>`);
  $('#modal-close-action').onclick = closeModal;
}

function renderEdgePlan() {
  const edge = data.edgePlan;
  if (!edge?.senderRouting?.summary) return;
  const sender = edge.senderRouting.summary;
  const deliverability = edge.deliverability?.summary || {};
  const supply = edge.evidenceSupply?.summary || {};
  const copilot = edge.copilot?.summary || {};
  $('#edge-summary').innerHTML = [
    metric('Sender mesh', `${sender.available}/${sender.senders}`, `${sender.routed} routed · ${sender.blocked} blocked`),
    metric('Stable sender health', deliverability.ready || 0, `${deliverability.holds || 0} hold(s) · ${deliverability.providerPlacementTested || 0} placement test(s)`),
    metric('Evidence queue', supply.readyForOwnerReview || 0, `${supply.researchNeeded || 0} research · ${supply.refreshNeeded || 0} refresh`),
    metric('Safe copilot actions', copilot.safeAutomations || 0, `${copilot.gatedActions || 0} high-impact actions gated`)
  ].join('');
  const cards = [
    ['Sender routing', `${sender.providers?.join(', ') || 'No provider observed'} · sticky and health-ranked`, 'No sender is reserved by this plan.'],
    ['Warmup and placement', `${deliverability.authenticationObserved || 0} authentication set(s) observed`, 'Ramp plan only; no inbox-placement guarantee.'],
    ['Evidence supply', `${supply.active || 0} active local prospect record(s)`, `${supply.verificationNeeded || 0} need contact verification.`],
    ['Owner copilot', `${copilot.next?.[0]?.action || 'keep-building-evidence'}`, 'Ranking, drafting and stopping stay safe; sending stays gated.']
  ];
  $('#edge-rows').innerHTML = cards.map(([title, headline, detail]) => `<div class="edge-card"><b>${esc(title)}</b><strong>${esc(headline)}</strong><span>${esc(detail)}</span></div>`).join('');
}

function renderOverview() {
  const summary = data.summary || {};
  const counts = data.analytics?.counts || {};
  renderComparison();
  renderEdgePlan();
  const rates = data.analytics?.rates || {};
  $('#overview-metrics').innerHTML = [
    metric('Prospects', counts.prospects ?? summary.prospects ?? 0),
    metric('Sequence plans', counts.scheduled ?? 0),
    metric('Sent', counts.sent ?? summary.sent ?? 0),
    metric('Replies', counts.replies ?? summary.replied ?? 0, `${rates.replyFromSent || 0}% from sent`),
    metric('Opportunities', counts.opportunities ?? 0),
    metric('Cleared revenue', money(data.analytics?.clearedRevenueUsd || 0), `${counts.recurring || 0} recurring`)
  ].join('');
  const ordered = [
    ['Prospects', counts.prospects || 0], ['Researched', counts.researched || 0], ['Sent', counts.sent || 0], ['Replies', counts.replies || 0],
    ['Positive replies', counts.positiveReplies || 0], ['Opportunities', counts.opportunities || 0], ['Cleared payments', counts.paymentSettled || 0], ['Recurring', counts.recurring || 0]
  ];
  const max = Math.max(1, ...ordered.map(item => item[1]));
  $('#funnel').innerHTML = ordered.map(([label, value]) => `<div class="funnel-row"><label>${esc(label)}</label><div class="funnel-track"><i style="width:${Math.max(value ? 3 : 0, Math.round(value / max * 100))}%"></i></div><strong>${esc(value)}</strong></div>`).join('');
  $('#funnel-score').textContent = `${Number(data.analytics?.weightedOutcomeScore || 0).toLocaleString()} weighted outcome points`;
  const ownerQueue = [];
  const connected = data.health?.mailboxes?.filter(item => item.connected).length || 0;
  if (!connected) ownerQueue.push(['Connect one sender slot', 'Research and plan work without Gmail; connect only when an owner-approved canary is ready.']);
  if (!data.campaigns.filter(item => !item.systemKey).length) ownerQueue.push(['Create your first sequence', 'Use the evidence-bound editor to build a small message path.']);
  if ((data.health?.uncertain || []).length) ownerQueue.push(['Reconcile uncertain effects', `${data.health.uncertain.length} external result(s) are quarantined.`]);
  const ready = data.prospects.filter(item => item.status === 'ready').length;
  if (ready) ownerQueue.push([`Review ${ready} ready prospect${ready === 1 ? '' : 's'}`, 'Open the dossier, check the route evidence, then approve only exact messages.']);
  if (!ownerQueue.length) ownerQueue.push(['Keep learning from revenue', 'The system is quiet and safe. Optimize cleared payment and repeat revenue, not opens.']);
  $('#owner-queue').innerHTML = ownerQueue.slice(0, 4).map(([title, description]) => `<div class="action-item"><i></i><div><b>${esc(title)}</b><span>${esc(description)}</span></div></div>`).join('');
  const replies = data.inbox.filter(item => item.latestReply).slice(0, 5);
  $('#recent-replies').innerHTML = replies.length ? replies.map(thread => `<div class="stack-item reply-preview"><div><b>${esc(thread.prospect?.company || thread.latestReply.from || 'Unknown thread')}</b><span>${esc((thread.latestReply.body || '').slice(0, 110))}</span></div><span class="reply-label">${esc(thread.latestReply.classification?.label || 'reply')}</span></div>`).join('') : '<div class="empty-state" style="min-height:120px"><span>No replies matched yet.</span></div>';
  const boxes = data.health.mailboxes || [];
  $('#health-glance').innerHTML = boxes.length ? boxes.map(box => `<div class="stack-item health-line"><div><b>${esc(box.slot)} · ${esc(box.email || 'Disconnected')}</b><span>${box.paused ? 'Paused' : box.connected ? 'Connected' : 'Not connected'} · ${box.sent} sent · ${box.bounces} bounce(s)</span></div><span class="health-score">${box.score}/100</span></div>`).join('') : '<div class="empty-state" style="min-height:120px"><span>No sender slots configured.</span></div>';
  const paused = data.health.globalPaused;
  $('#hero-state').textContent = paused ? 'GLOBAL OUTBOUND PAUSED' : data.summary.workerOnline ? 'WORKER ONLINE · OWNER GATED' : 'WORKER OFFLINE · PLAN MODE';
}

function renderCampaignList() {
  const campaigns = data.campaigns.filter(item => !item.systemKey);
  $('#campaign-count').textContent = campaigns.length;
  $('#campaign-list').innerHTML = campaigns.length ? campaigns.map(campaign => {
    const active = editorModel?.id === campaign.id ? 'active' : '';
    const steps = campaign.sequence?.steps?.length || 0;
    const enrolled = data.prospects.filter(item => item.campaignId === campaign.id && item.sequenceState?.status === 'active').length;
    return `<button class="campaign-list-item ${active}" data-campaign-id="${esc(campaign.id)}"><b>${esc(campaign.name)}</b><small>${esc(campaign.niche || 'No target market')}</small><div class="campaign-meta"><span>${steps} steps</span><span>${enrolled} planned</span>${campaign.approved ? '<span class="status-chip good">approved</span>' : '<span class="status-chip warn">draft</span>'}</div></button>`;
  }).join('') : '<div class="empty-state" style="min-height:160px"><span>No sequences yet. Create one to start planning.</span></div>';
  $$('.campaign-list-item').forEach(item => item.onclick = () => selectCampaign(item.dataset.campaignId));
}

function newEditorModel() {
  const sequence = clientDefaultSequence('a focused website review');
  return { id: '', name: '', niche: '', offer: '', customVariables: {}, minScore: 60, allowedCountries: [], approved: false, autoSend: false, paused: true, status: 'draft', sequence };
}

function selectCampaign(id) {
  const campaign = data.campaigns.find(item => item.id === id);
  editorModel = campaign ? clone({ ...campaign, sequence: campaign.sequence || clientDefaultSequence(campaign.offer) }) : newEditorModel();
  renderCampaignList();
  renderEditor();
}

function renderEditor() {
  if (!editorModel) return;
  $('#campaign-id').value = editorModel.id || '';
  $('#editor-title').textContent = editorModel.id ? editorModel.name : 'Create a sequence';
  $('#editor-state').textContent = editorModel.id ? (editorModel.approved ? 'APPROVED CONTRACT' : 'LOCAL DRAFT') : 'LOCAL DRAFT';
  ['campaign-diagnostics', 'campaign-control-plan', 'campaign-preflight', 'campaign-analytics', 'campaign-placement', 'campaign-duplicate', 'campaign-export', 'campaign-portable-export', 'campaign-toggle'].forEach(id => { $(`#${id}`).disabled = !editorModel.id; });
  $('#campaign-toggle').textContent = editorModel.paused ? 'Resume' : 'Pause';
  $('#campaign-name').value = editorModel.name || '';
  $('#campaign-score').value = editorModel.minScore || 60;
  $('#campaign-niche').value = editorModel.niche || '';
  $('#campaign-variables').value = Object.keys(editorModel.customVariables || {}).length ? JSON.stringify(editorModel.customVariables, null, 2) : '';
  $('#campaign-offer').value = editorModel.offer || '';
  $('#campaign-approved').checked = Boolean(editorModel.approved);
  $('#campaign-autosend').checked = Boolean(editorModel.autoSend);
  const settings = editorModel.sequence?.settings || {};
  $('#stop-reply').checked = settings.stopOnReply !== false;
  $('#stop-positive').checked = settings.stopOnPositiveReply !== false;
  $('#stop-unsubscribe').checked = settings.stopOnUnsubscribe !== false;
  $('#stop-bounce').checked = settings.stopOnBounce !== false;
  $('#stop-opportunity').checked = settings.stopOnOpportunity !== false;
  $('#stop-payment').checked = settings.stopOnPayment !== false;
  $('#window-start').value = settings.sendWindow?.start ?? 9;
  $('#window-end').value = settings.sendWindow?.end ?? 17;
  $('#window-timezone').value = settings.sendWindow?.timezone || 'recipient';
  $('#window-gap').value = settings.sendWindow?.minGapMinutes ?? 5;
  $('#random-gap').value = settings.sendWindow?.randomGapMinutes ?? 0;
  $('#max-new-leads').value = settings.maxNewLeadsPerDay ?? 0;
  $('#prioritize-new-leads').checked = Boolean(settings.prioritizeNewLeads);
  $('#company-daily-limit').value = settings.limitEmailsPerCompanyPerDay ?? 0;
  $('#delivery-optimization').value = settings.deliveryOptimization || 'default';
  $('#auto-optimize').checked = Boolean(settings.autoOptimize);
  $('#optimize-metric').value = settings.autoOptimizeMetric || 'replyRate';
  $('#optimization-samples').value = settings.minimumOptimizationSamples || 25;
  const steps = editorModel.sequence?.steps || [];
  $('#sequence-steps').innerHTML = steps.map((step, stepIndex) => `<article class="sequence-card" data-step-index="${stepIndex}">
    <div class="sequence-card-head"><div class="step-heading"><span class="step-number">${stepIndex + 1}</span><input data-field="name" value="${esc(step.name)}" aria-label="Step name"></div><div class="step-actions"><button type="button" class="icon-button move-step" data-direction="up" ${stepIndex === 0 ? 'disabled' : ''}>↑</button><button type="button" class="icon-button move-step" data-direction="down" ${stepIndex === steps.length - 1 ? 'disabled' : ''}>↓</button><button type="button" class="icon-button remove-step" ${steps.length <= 1 ? 'disabled' : ''}>×</button></div></div>
    <div class="step-meta"><label>Kind<select data-field="kind"><option ${step.kind === 'initial' ? 'selected' : ''}>initial</option><option ${step.kind === 'followup' ? 'selected' : ''}>followup</option><option ${step.kind === 'breakup' ? 'selected' : ''}>breakup</option></select></label><label>Wait<input data-field="delayValue" type="number" min="0" max="43200" value="${esc(step.delayValue ?? step.delayDays ?? 0)}"></label><label>Unit<select data-field="delayUnit"><option value="minutes" ${step.delayUnit === 'minutes' ? 'selected' : ''}>Minutes</option><option value="hours" ${step.delayUnit === 'hours' ? 'selected' : ''}>Hours</option><option value="days" ${!step.delayUnit || step.delayUnit === 'days' ? 'selected' : ''}>Days</option></select></label><label>Run when<select data-field="condition"><option value="always" ${step.condition === 'always' ? 'selected' : ''}>Always</option><option value="no_reply" ${step.condition === 'no_reply' ? 'selected' : ''}>No reply</option><option value="positive_reply" ${step.condition === 'positive_reply' ? 'selected' : ''}>Positive reply</option><option value="opened_no_reply" ${step.condition === 'opened_no_reply' ? 'selected' : ''}>Opened, no reply</option><option value="clicked_no_reply" ${step.condition === 'clicked_no_reply' ? 'selected' : ''}>Clicked, no reply</option><option value="out_of_office" ${step.condition === 'out_of_office' ? 'selected' : ''}>Out of office</option><option value="manual" ${step.condition === 'manual' ? 'selected' : ''}>Manual approval</option></select></label></div>
    <div class="variant-tabs">${(step.variants || []).map((variant, variantIndex) => `<span class="variant-tab active">${esc(variant.id || String.fromCharCode(65 + variantIndex))}</span>`).join('')}<button type="button" class="variant-add" data-step-index="${stepIndex}">＋ Add A/B variant</button></div>
    <div class="variants">${(step.variants || []).map((variant, variantIndex) => `<div class="variant-fields" data-variant-index="${variantIndex}"><label>Variant ${esc(variant.id || String.fromCharCode(65 + variantIndex))} subject<input data-field="subject" value="${esc(variant.subject)}"></label><label>Weight %<input data-field="weight" type="number" min="1" max="100" value="${esc(variant.weight || 100)}"></label><label class="toggle variant-enabled"><input data-field="enabled" type="checkbox" ${variant.enabled !== false ? 'checked' : ''}><span></span> Enabled</label><label class="wide">Body<textarea data-field="body">${esc(variant.body)}</textarea></label><small class="muted wide">Supports {{variables}}, {% if variable %}conditionals{% endif %}, and {one|another} Spintax. Missing evidence is never invented.</small>${(step.variants || []).length > 1 ? `<button type="button" class="variant-remove" data-step-index="${stepIndex}" data-variant-index="${variantIndex}">Remove variant</button>` : ''}</div>`).join('')}</div>
  </article>`).join('');
  $$('.remove-step').forEach(button => button.onclick = () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const index = Number(button.closest('.sequence-card').dataset.stepIndex); editorModel.sequence.steps.splice(index, 1); renderEditor(); });
  $$('.move-step').forEach(button => button.onclick = () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const card = button.closest('.sequence-card'); const index = Number(card.dataset.stepIndex); const target = button.dataset.direction === 'up' ? index - 1 : index + 1; if (target < 0 || target >= editorModel.sequence.steps.length) return; [editorModel.sequence.steps[index], editorModel.sequence.steps[target]] = [editorModel.sequence.steps[target], editorModel.sequence.steps[index]]; renderEditor(); });
  $$('.variant-add').forEach(button => button.onclick = () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const index = Number(button.dataset.stepIndex); const variants = editorModel.sequence.steps[index].variants; if (variants.length >= 26) return toast('A step supports up to 26 variants', true); const letter = String.fromCharCode(65 + variants.length); variants.push({ id: letter, label: `Variant ${letter}`, weight: 50, subject: variants[0]?.subject || 'A note about {{company}}', body: variants[0]?.body || 'Hi {{company}} team,\n\n' }); renderEditor(); });
  $$('.variant-remove').forEach(button => button.onclick = () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const step = editorModel.sequence.steps[Number(button.dataset.stepIndex)]; step.variants.splice(Number(button.dataset.variantIndex), 1); renderEditor(); });
}

function syncEditorFromDom() {
  if (!editorModel) return;
  editorModel.name = $('#campaign-name').value.trim();
  editorModel.minScore = Number($('#campaign-score').value || 60);
  editorModel.niche = $('#campaign-niche').value.trim();
  try {
    const variables = $('#campaign-variables').value.trim();
    editorModel.customVariables = variables ? JSON.parse(variables) : {};
    if (!editorModel.customVariables || typeof editorModel.customVariables !== 'object' || Array.isArray(editorModel.customVariables)) throw new Error('Custom variables must be a JSON object');
  } catch (error) {
    throw new Error(`Custom variables: ${error.message}`);
  }
  editorModel.offer = $('#campaign-offer').value.trim();
  editorModel.approved = $('#campaign-approved').checked;
  editorModel.autoSend = $('#campaign-autosend').checked;
  editorModel.sequence.settings = {
    ...(editorModel.sequence.settings || {}),
    stopOnReply: $('#stop-reply').checked,
    stopOnPositiveReply: $('#stop-positive').checked,
    stopOnUnsubscribe: $('#stop-unsubscribe').checked,
    stopOnBounce: $('#stop-bounce').checked,
      stopOnOpportunity: $('#stop-opportunity').checked,
      stopOnPayment: $('#stop-payment').checked,
      maxNewLeadsPerDay: Number($('#max-new-leads').value || 0),
      prioritizeNewLeads: $('#prioritize-new-leads').checked,
      limitEmailsPerCompanyPerDay: Number($('#company-daily-limit').value || 0),
      deliveryOptimization: $('#delivery-optimization').value,
      autoOptimize: $('#auto-optimize').checked,
      autoOptimizeMetric: $('#optimize-metric').value,
      minimumOptimizationSamples: Number($('#optimization-samples').value || 25),
      sendWindow: {
        ...(editorModel.sequence.settings?.sendWindow || {}),
        start: Number($('#window-start').value || 9),
        end: Number($('#window-end').value || 17),
        timezone: $('#window-timezone').value.trim() || 'recipient',
        minGapMinutes: Number($('#window-gap').value || 5),
        randomGapMinutes: Number($('#random-gap').value || 0)
      }
  };
  $$('#sequence-steps .sequence-card').forEach((card, stepIndex) => {
    const step = editorModel.sequence.steps[stepIndex];
    step.name = card.querySelector('[data-field="name"]').value.trim();
    step.kind = card.querySelector('[data-field="kind"]').value;
    step.delayValue = Number(card.querySelector('[data-field="delayValue"]').value || 0);
    step.delayUnit = card.querySelector('[data-field="delayUnit"]').value;
    step.delayDays = step.delayUnit === 'days' ? step.delayValue : step.delayDays || 0;
    step.condition = card.querySelector('[data-field="condition"]').value;
    card.querySelectorAll('[data-variant-index]').forEach(variantEl => {
      const variant = step.variants[Number(variantEl.dataset.variantIndex)];
      variant.subject = variantEl.querySelector('[data-field="subject"]').value;
      variant.weight = Number(variantEl.querySelector('[data-field="weight"]').value || 100);
      variant.enabled = variantEl.querySelector('[data-field="enabled"]').checked;
      variant.body = variantEl.querySelector('[data-field="body"]').value;
    });
  });
}

function renderProspects() {
  const search = ($('#prospect-search').value || '').trim().toLowerCase();
  const status = $('#prospect-status').value;
  const campaignId = $('#prospect-campaign').value;
  const rows = data.prospects.filter(prospect => {
    const haystack = `${prospect.company || ''} ${prospect.website || ''} ${prospect.domain || ''} ${prospect.contact?.email || ''}`.toLowerCase();
    return (!search || haystack.includes(search)) && (!status || prospect.status === status) && (!campaignId || prospect.campaignId === campaignId);
  });
  $('#prospect-rows').innerHTML = rows.length ? rows.map(prospect => `<tr><td><input class="table-check prospect-check" type="checkbox" data-id="${esc(prospect.id)}"></td><td><b>${esc(prospect.company)}</b><small>${esc(prospect.domain || prospect.website)}</small>${prospect.tags?.length ? `<small>#${esc(prospect.tags.join(' #'))}</small>` : ''}</td><td><span class="evidence-score">${esc(prospect.score?.total ?? '—')}</span><small>${esc(prospect.issue?.title || 'Evidence pending')}</small></td><td><b>${esc(prospect.contact?.email || 'No selected recipient')}</b><small>${esc(prospect.contact?.source || prospect.source || '—')}</small></td><td>${chip(prospect.sequenceState?.status || 'not planned')}<small>${prospect.sequenceState?.nextStepAt ? `next ${esc(fmtDate(prospect.sequenceState.nextStepAt))}` : esc(prospect.campaignId ? data.campaigns.find(item => item.id === prospect.campaignId)?.name || 'assigned' : 'unassigned')}</small></td><td><span class="stage-chip">${esc(prospect.opportunityStage || 'new')}</span><small>${esc(prospect.nextAction || 'No next action')}</small></td><td><button class="row-action open-prospect" data-id="${esc(prospect.id)}">Open</button></td></tr>`).join('') : '<tr><td colspan="7"><div class="empty-state" style="min-height:160px"><span>No prospects match this view.</span></div></td></tr>';
  $$('.open-prospect').forEach(button => button.onclick = () => openProspect(button.dataset.id));
  updateSelectedCount();
}

function selectedProspectIds() { return $$('.prospect-check:checked').map(input => input.dataset.id); }
function updateSelectedCount() { $('#selected-count').textContent = `${selectedProspectIds().length} selected`; }

function renderInbox() {
  const search = ($('#inbox-search').value || '').toLowerCase();
  const filter = $('#inbox-filter').value;
  const threads = data.inbox.filter(thread => {
    const haystack = `${thread.prospect?.company || ''} ${thread.prospect?.contact?.email || ''} ${thread.latestReply?.body || ''}`.toLowerCase();
    const positive = thread.latestReply?.classification?.label === 'positive' || thread.prospect?.replyLabel === 'positive';
    const opportunity = ['opportunity', 'meeting', 'offer', 'invoice', 'paid', 'delivery', 'accepted', 'recurring'].includes(thread.prospect?.opportunityStage);
    return (!search || haystack.includes(search)) && (filter === 'all' || (filter === 'needs_action' && thread.needsAction) || (filter === 'unread' && thread.unread) || (filter === 'positive' && positive) || (filter === 'opportunity' && opportunity) || (filter === 'snoozed' && thread.snoozed) || (filter === 'archived' && thread.archived));
  });
  $('#thread-list').innerHTML = threads.length ? threads.map(thread => `<button class="thread-item ${thread.id === selectedThreadId ? 'active' : ''}" data-thread-id="${esc(thread.id)}"><div class="thread-item-head"><b>${esc(thread.prospect?.company || 'Unknown thread')}</b><span class="thread-time">${esc(fmtDate(thread.lastActivityAt))}</span></div><p>${esc(thread.latestReply?.body || thread.latestMessage?.subject || 'No message preview')}</p><div class="thread-badges">${thread.unread ? '<i class="unread-dot"></i>' : ''}${thread.needsAction ? '<span class="status-chip warn">ACTION</span>' : ''}${thread.snoozed ? '<span class="status-chip">SNOOZED</span>' : ''}${thread.archived ? '<span class="status-chip">ARCHIVED</span>' : ''}${chip(thread.prospect?.opportunityStage || thread.latestReply?.classification?.label || 'sent')}</div></button>`).join('') : '<div class="empty-state" style="min-height:230px"><span>No threads match.</span></div>';
  $$('.thread-item').forEach(button => button.onclick = () => { selectedThreadId = button.dataset.threadId; renderInbox(); renderThreadDetail(); });
  if (!selectedThreadId && threads[0]) selectedThreadId = threads[0].id;
  if (selectedThreadId && threads.some(item => item.id === selectedThreadId)) renderThreadDetail();
  else if (!threads.length) $('#thread-detail').innerHTML = '<div class="empty-state"><b>No conversation selected</b><span>Matched replies will appear here after Gmail polling.</span></div>';
}

function renderThreadDetail() {
  const thread = data.inbox.find(item => item.id === selectedThreadId);
  if (!thread) return;
  const prospect = thread.prospect || {};
  const activity = [...thread.messages.map(item => ({ ...item, type: 'sent', at: item.sentAt || item.createdAt })), ...thread.replies.map(item => ({ ...item, type: 'reply', at: item.receivedAt || item.createdAt }))].sort((a, b) => String(a.at).localeCompare(String(b.at)));
  const archiveAction = thread.archived ? 'unarchive' : 'archive';
  const archiveLabel = thread.archived ? 'Unarchive' : 'Archive';
  const snoozeControls = thread.snoozed ? '<button class="button secondary" id="clear-thread-snooze">Clear snooze</button>' : '<button class="button secondary" id="snooze-thread">Snooze 24h</button>';
  $('#thread-detail').innerHTML = `<div class="detail-header"><div><div class="eyebrow">${thread.unread ? 'UNREAD · ' : ''}${thread.archived ? 'ARCHIVED · ' : ''}${thread.snoozed ? 'SNOOZED · ' : ''}THREAD</div><h2>${esc(prospect.company || 'Unknown')}</h2><a href="${esc(prospect.website || '#')}" target="_blank" rel="noopener">${esc(prospect.contact?.email || prospect.website || 'No contact')}</a></div><div class="detail-actions">${thread.unread ? '<button class="button secondary" id="mark-thread-read">Mark read</button>' : ''}<button class="button secondary" id="mark-positive">Positive</button><button class="button secondary" id="mark-negative">Not interested</button><button class="button secondary" id="mark-neutral">Neutral</button><button class="button secondary" id="create-opportunity">Create opportunity</button><button class="button secondary" id="${archiveAction}-thread">${archiveLabel}</button>${snoozeControls}<button class="button secondary" id="draft-reply">Draft reply</button><select id="detail-stage"><option value="new">new</option>${['researched', 'contacted', 'replied', 'opportunity', 'meeting', 'offer', 'invoice', 'paid', 'delivery', 'accepted', 'recurring', 'lost'].map(stage => `<option value="${stage}" ${prospect.opportunityStage === stage ? 'selected' : ''}>${stage}</option>`).join('')}</select><button class="button gold" id="save-detail-state">Save state</button></div></div><div class="thread-context"><div class="context-card"><span>Evidence</span><b>${esc(prospect.issue?.title || 'Not captured')}</b></div><div class="context-card"><span>Sequence</span><b>${esc(data.campaigns.find(item => item.id === prospect.campaignId)?.name || 'Unassigned')}</b></div><div class="context-card"><span>Next action</span><b>${esc(prospect.nextAction || 'Not set')}</b></div></div><label>Next action<input id="detail-next-action" value="${esc(prospect.nextAction || '')}" placeholder="e.g. review the paid diagnostic request"></label><div class="detail-timeline">${activity.length ? activity.map(item => `<article class="detail-message"><div class="message-meta"><span>${item.type === 'reply' ? 'REPLY' : 'SENT'} · ${esc(item.from || item.to || '')}</span><span>${esc(fmtDate(item.at))}</span></div>${item.subject ? `<strong>${esc(item.subject)}</strong>` : ''}<p>${esc(item.body || '(message body is stored at the provider)')}</p></article>`).join('') : '<div class="empty-state" style="min-height:230px"><span>No stored message body for this thread.</span></div>'}</div><div class="modal-section"><h3>Commercial continuity</h3><p class="muted">A stage is an owner note, not payment proof. Cleared revenue still requires provider-backed evidence.</p></div>`;
  $('#save-detail-state').onclick = async () => { try { await api(`/api/outreach/prospects/${encodeURIComponent(prospect.id)}/state`, { method: 'POST', body: JSON.stringify({ stage: $('#detail-stage').value, nextAction: $('#detail-next-action').value }) }); toast('Thread state saved'); await loadAll(true); } catch (error) { toast(error.message, true); } };
  $('#draft-reply').onclick = async () => { try { const draft = await api(`/api/outreach/inbox/${encodeURIComponent(prospect.id)}/reply-draft`, { method: 'POST', body: JSON.stringify({}) }); openModal(`<div class="eyebrow">OWNER-REVIEWED DRAFT ONLY</div><h2>${esc(prospect.company || 'Reply')}</h2><p class="muted">${esc(draft.reason || 'Review before using the governed send path.')}</p><label>Subject<input id="draft-subject" value="${esc(draft.subject || '')}"></label><label>Body<textarea id="draft-body">${esc(draft.body || '')}</textarea></label><div class="view-actions"><button class="button secondary" id="discard-draft">Discard</button><button class="button gold" id="save-draft">Save owner-reviewed draft</button></div>`); $('#discard-draft').onclick = closeModal; $('#save-draft').onclick = async () => { try { await api(`/api/outreach/reply-drafts/${encodeURIComponent(draft.id)}`, { method: 'PATCH', body: JSON.stringify({ status: 'owner-reviewed', subject: $('#draft-subject').value, body: $('#draft-body').value }) }); closeModal(); toast('Draft saved; no provider call made'); } catch (error) { toast(error.message, true); } }; } catch (error) { toast(error.message, true); } };
  const runInboxAction = async (action, payload = {}) => { try { await api(`/api/outreach/inbox/${encodeURIComponent(prospect.id)}/action`, { method: 'POST', body: JSON.stringify({ action, ...payload }) }); toast(`Inbox action applied: ${action.replaceAll('_', ' ')}`); await loadAll(true); } catch (error) { toast(error.message, true); } };
  $('#mark-positive').onclick = () => runInboxAction('mark_positive');
  $('#mark-negative').onclick = () => runInboxAction('mark_negative');
  $('#mark-neutral').onclick = () => runInboxAction('mark_neutral');
  $('#create-opportunity').onclick = () => runInboxAction('create_opportunity');
  $(`#${archiveAction}-thread`).onclick = () => runInboxAction(archiveAction);
  if ($('#snooze-thread')) $('#snooze-thread').onclick = () => runInboxAction('snooze', { snoozedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() });
  if ($('#clear-thread-snooze')) $('#clear-thread-snooze').onclick = () => runInboxAction('clear_snooze');
  if (thread.unread) $('#mark-thread-read').onclick = async () => { try { await api(`/api/outreach/inbox/${encodeURIComponent(prospect.id)}/read`, { method: 'POST' }); toast('Thread marked read'); await loadAll(true); } catch (error) { toast(error.message, true); } };
}

function renderAutomations() {
  const automations = data.automations || [];
  $('#automation-count').textContent = automations.length;
  $('#automation-list').innerHTML = automations.length ? automations.map(plan => `<article class="stack-item"><div class="panel-heading" style="margin-bottom:8px"><div><b>${esc(plan.name)}</b><small>${esc(plan.trigger)} · ${esc(plan.conditionMode || 'all')} conditions · ${plan.enabled ? 'enabled' : 'paused'} · ${esc(plan.runCount || 0)} run(s)</small></div>${chip(plan.enabled ? 'active' : 'paused')}</div><small class="muted">${esc((plan.actions || []).map(action => action.type).join(' · '))}</small><div style="display:flex;gap:8px;margin-top:10px"><button class="row-action toggle-automation" data-id="${esc(plan.id)}" data-enabled="${plan.enabled}">${plan.enabled ? 'Pause' : 'Enable'}</button><button class="row-action test-automation" data-id="${esc(plan.id)}">Test manual event</button></div></article>`).join('') : '<div class="empty-state" style="min-height:180px"><span>No automations yet. Add a local rule to route event work.</span></div>';
  $$('.toggle-automation').forEach(button => button.onclick = async () => { try { await api(`/api/outreach/automations/${encodeURIComponent(button.dataset.id)}`, { method: 'PATCH', body: JSON.stringify({ enabled: button.dataset.enabled !== 'true' }) }); toast('Automation state updated'); await loadAll(true); } catch (error) { toast(error.message, true); } });
  $$('.test-automation').forEach(button => button.onclick = async () => { try { const result = await api(`/api/outreach/automations/${encodeURIComponent(button.dataset.id)}/test`, { method: 'POST', body: JSON.stringify({ event: 'manual' }) }); openModal(`<div class="eyebrow">AUTOMATION TEST · NO MUTATION</div><h2>${esc(result.planName)}</h2><p class="muted">Status: ${esc(result.status)} · trigger: ${esc(result.eventTrigger)} · actions: ${esc(result.actions.map(action => action.type).join(', ') || 'none')} · blocked: ${esc(result.blockedActions.map(action => action.type).join(', ') || 'none')}</p><button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } });
}

function renderHealth() {
  const health = data.health || {};
  $('#health-banner').className = `health-banner ${health.globalPaused || health.mailboxes?.some(item => item.paused) ? 'warn' : ''}`;
  $('#health-banner').textContent = health.globalPaused ? `Global outbound is paused${health.pauseReason ? `: ${health.pauseReason}` : ''}.` : health.mailboxes?.length ? 'Observed sender state looks stable. Placement is not guaranteed; keep volume owner-controlled.' : 'No sender slots connected. Planning and dry-runs remain available.';
  $('#mailbox-health').innerHTML = health.mailboxes?.length ? health.mailboxes.map(box => `<article class="mailbox-card ${box.paused ? 'paused' : ''}"><div class="mailbox-card-head"><b>${esc(box.slot)} · ${esc(box.email || 'Disconnected')}</b><span>${box.paused ? 'PAUSED' : box.connected ? 'CONNECTED' : 'NOT CONNECTED'}</span></div><div class="health-meter"><i style="width:${box.score}%"></i></div><div class="mailbox-stats"><div><span>Score</span><b>${box.score}</b></div><div><span>Bounces</span><b>${box.bounces}</b></div><div><span>Complaints</span><b>${box.complaints}</b></div></div><div style="margin-top:13px;display:flex;justify-content:space-between;align-items:center"><small class="muted">${esc(box.pauseReason || `${box.sent} observed sends`)}</small><button class="row-action toggle-sender" data-slot="${esc(box.slot)}" data-paused="${box.paused}">${box.paused ? 'Resume' : 'Pause'}</button></div></article>`).join('') : '<div class="empty-state" style="min-height:180px"><span>Connect a Gmail slot when the owner is ready.</span></div>';
  $('#domain-health').innerHTML = health.domains?.length ? health.domains.map(domain => `<div class="domain-item ${esc(domain.state)}"><div class="domain-ring">${domain.score}</div><div><b>${esc(domain.domain)}</b><small>${esc(domain.state)} · slots ${esc(domain.mailboxes.join(', ') || 'none')}</small></div></div>`).join('') : '<div class="empty-state" style="min-height:180px"><span>No sending domain observed.</span></div>';
  $('#uncertain-effects').innerHTML = health.uncertain?.length ? health.uncertain.map(item => `<div class="stack-item uncertain-item"><div class="uncertain-text"><b>${esc(item.recipientEmail || item.idempotencyKey || 'Uncertain reservation')}</b><small>${esc(item.inbox || '')} · ${esc(fmtDate(item.reservedAt))}</small></div><button class="row-action reconcile-effect" data-id="${esc(item.id)}">Reconcile</button></div>`).join('') : '<div class="empty-state" style="min-height:120px"><span>No uncertain external effects.</span></div>';
  $$('.toggle-sender').forEach(button => button.onclick = async () => { try { const slot = button.dataset.slot; const paused = button.dataset.paused === 'true'; await api(`/api/outbound/sender/${slot}/${paused ? 'resume' : 'pause'}`, { method: 'POST', body: JSON.stringify({ reason: 'Owner action from Outreach Workbench' }) }); toast(`${slot} ${paused ? 'resumed' : 'paused'}`); await loadAll(true); } catch (error) { toast(error.message, true); } });
  $$('.reconcile-effect').forEach(button => button.onclick = async () => { try { const result = await api('/api/outreach/reconcile', { method: 'POST', body: JSON.stringify({ reservationId: button.dataset.id }) }); toast(result.reconciled ? 'Provider evidence reconciled' : 'Still uncertain; no retry was attempted', !result.reconciled); await loadAll(true); } catch (error) { toast(error.message, true); } });
}

function renderSuppressions() {
  $('#suppression-count').textContent = data.suppressions.length;
  $('#suppression-rows').innerHTML = data.suppressions.length ? data.suppressions.map(item => `<tr><td><b>${esc(item.value)}</b></td><td>${esc(item.reason || '—')}</td><td>${esc(shortDate(item.createdAt))}</td></tr>`).join('') : '<tr><td colspan="3"><div class="empty-state" style="min-height:180px"><span>No suppressions recorded.</span></div></td></tr>';
}

function renderAll() {
  renderOverview(); renderCampaignList(); renderInbox(); renderAutomations(); renderHealth(); renderSuppressions();
  const selectedCampaign = $('#prospect-campaign').value;
  const campaignOptions = data.campaigns.filter(item => !item.systemKey).map(item => `<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('');
  $('#prospect-campaign').innerHTML = `<option value="">All sequences</option>${campaignOptions}`;
  if (selectedCampaign && data.campaigns.some(item => item.id === selectedCampaign)) $('#prospect-campaign').value = selectedCampaign;
  renderProspects();
}

async function loadAll(silent = false) {
  try {
    const [summary, workspace, comparison, edgePlan, analytics, health, campaigns, prospects, suppressions, inbox, automations] = await Promise.all([
      api('/api/summary'), api('/api/outreach/workspace'), api('/api/outreach/comparison'), api('/api/outreach/edge-plan'), api('/api/outreach/analytics'), api('/api/outreach/health'),
      api('/api/campaigns'), api('/api/prospects'), api('/api/outreach/suppressions'), api('/api/outreach/inbox'), api('/api/outreach/automations')
    ]);
    data = { summary, workspace, comparison, edgePlan, analytics, health, campaigns, prospects, suppressions, inbox, automations };
    $('#top-status').textContent = `${summary.workerOnline ? 'WORKER ONLINE' : 'PLAN MODE'} · ${summary.outbound?.dryRun ? 'DRY RUN' : summary.outbound?.globalPaused ? 'PAUSED' : 'OWNER GATED'}`;
    renderAll();
    if (!silent) toast('Workbench synchronized');
  } catch (error) {
    $('#top-status').textContent = error.message;
    if (!silent) toast(error.message, true);
  }
}

function openModal(content) { $('#modal-content').innerHTML = content; $('#modal').classList.remove('hidden'); $('#modal').setAttribute('aria-hidden', 'false'); }
function closeModal() { $('#modal').classList.add('hidden'); $('#modal').setAttribute('aria-hidden', 'true'); }
function openProspect(id) {
  const prospect = data.prospects.find(item => item.id === id);
  if (!prospect) return;
  const campaign = data.campaigns.find(item => item.id === prospect.campaignId);
  openModal(`<div class="eyebrow">PROSPECT DOSSIER</div><h2>${esc(prospect.company)}</h2><p class="muted">${esc(prospect.website)} · ${esc(prospect.contact?.email || 'No selected contact')}</p><div class="modal-section"><h3>Evidence</h3><b>${esc(prospect.issue?.title || 'No primary issue')}</b><p class="muted">${esc(prospect.issue?.evidenceExcerpt || 'Research is not complete.')}</p>${prospect.issue?.evidenceUrl ? `<a class="text-button" href="${esc(prospect.issue.evidenceUrl)}" target="_blank" rel="noopener">Open source evidence ↗</a>` : ''}</div><div class="modal-section"><h3>Prepared message</h3><b>${esc(prospect.subject || 'No draft')}</b><pre>${esc(prospect.draft || 'No draft is available yet.')}</pre><div class="view-actions"><button class="button secondary" id="modal-preview">Preview sequence</button><button class="button gold" id="modal-close-action">Close</button></div></div><div class="modal-section"><h3>Governance</h3><p class="muted">Status: ${esc(prospect.status)} · Sequence: ${esc(prospect.sequenceState?.status || 'not planned')} · Campaign: ${esc(campaign?.name || 'unassigned')}. A provider send still requires the exact route evidence and V9 approval.</p></div>`);
  $('#modal-close-action').onclick = closeModal;
  $('#modal-preview').onclick = async () => {
    if (!campaign) return toast('Assign a campaign first', true);
    try {
      const preview = await api('/api/outreach/sequence/preview', { method: 'POST', body: JSON.stringify({ campaignId: campaign.id, prospectId: prospect.id }) });
      const currentIndex = Number(prospect.sequenceState?.currentStepIndex ?? 0);
      const canApprove = ['ready_for_review'].includes(prospect.sequenceState?.status) && preview.steps[currentIndex];
      const approvalStep = canApprove ? preview.steps[currentIndex] : null;
      openModal(`<div class="eyebrow">SEQUENCE PREVIEW</div><h2>${esc(prospect.company)}</h2><p class="muted">Rendered locally. Approval is exact-payload and provider-gated; this screen never sends.</p>${preview.steps.map(step => `<div class="modal-section"><h3>${esc(step.name)} · ${esc(fmtDate(step.scheduledAt))}${step.nextWindowAt ? ` · window ${esc(fmtDate(step.nextWindowAt))}` : ''}</h3><b>${esc(step.selected?.subject || '')}</b><pre>${esc(step.selected?.body || '')}</pre>${step.missingTags?.length ? `<p class="warning-text">Missing evidence-bound data: ${esc(step.missingTags.join(', '))}</p>` : step.placeholderTags?.length ? `<p class="muted">Placeholder values used: ${esc(step.placeholderTags.join(', '))}</p>` : '<p class="muted">All merge data present for this preview.</p>'}</div>`).join('')}${approvalStep ? `<div class="modal-section approval-form"><h3>Approve current step exactly</h3><p class="muted">Route evidence is required. Use the official page and the smallest excerpt proving consent, a request, or a solicited opportunity.</p><label>Route type<select id="approval-route-type"><option value="SOLICITED_APPLICATION">Solicited application</option><option value="EXPLICIT_CONSENT">Explicit consent</option><option value="REQUESTED_INFORMATION">Requested information</option></select></label><label>Permission scope<select id="approval-permission-scope"><option value="CONTRACTOR_APPLICATION">Contractor application</option><option value="JOB_APPLICATION">Job application</option><option value="SERVICE_INFORMATION">Service information</option></select></label><label>Jurisdiction (ISO country code)<input id="approval-jurisdiction" maxlength="2" placeholder="CA"></label><label>Source URL<input id="approval-source-url" value="${esc(prospect.issue?.evidenceUrl || prospect.website || '')}" placeholder="https://official-source.example/page"></label><label>Source excerpt<textarea id="approval-source-excerpt" rows="4" placeholder="Exact official excerpt proving the route">${esc(prospect.issue?.evidenceExcerpt || '')}</textarea></label><button class="button gold" id="approve-current-step">Create exact step approval</button><small class="muted">If outbound is disabled or not in canary, the request will fail closed without changing the plan.</small></div>` : ''}<button class="button secondary" id="modal-close-action">Close</button>`);
      $('#modal-close-action').onclick = closeModal;
      if (approvalStep) $('#approve-current-step').onclick = async () => {
        try {
          const routeEvidence = {
            routeType: $('#approval-route-type').value,
            permissionScope: $('#approval-permission-scope').value,
            jurisdiction: $('#approval-jurisdiction').value.trim().toUpperCase(),
            sourceUrl: $('#approval-source-url').value.trim(),
            sourceExcerpt: $('#approval-source-excerpt').value,
            relevantToRecipientRole: true,
            noUnsolicitedStatementPresent: false,
            evidenceNote: 'Owner-entered route evidence from the Outreach Workbench'
          };
          await api('/api/outreach/sequence/approve-step', { method: 'POST', body: JSON.stringify({ prospectId: prospect.id, campaignId: campaign.id, stepIndex: currentIndex, variantId: approvalStep.selectedVariantId, routeEvidence }) });
          closeModal();
          toast('Exact step approval created; no provider call made');
          await loadAll(true);
        } catch (error) { toast(error.message, true); }
      };
    } catch (error) { toast(error.message, true); }
  };
}

const downloadJson = (payload, filename) => {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
};

$('#campaign-control-plan').onclick = async () => {
  if (!editorModel?.id) return;
  try {
    const result = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/control-plan`);
    const rows = (result.queue || []).slice(0, 16).map(row => `<div class="modal-section"><h3>${esc(row.company || row.prospectId)} · ${row.eligible ? 'eligible' : 'blocked'}</h3><p class="muted">${esc(row.kind)} · ${esc(row.provider || 'provider unknown')} · ${esc(row.route || 'no sender route')} · ${esc(row.reasons.join(', ') || 'all local gates passed')}</p></div>`).join('');
    openModal(`<div class="eyebrow">CAMPAIGN CONTROL PLAN</div><h2>${esc(editorModel.name)}</h2><p class="muted">${esc(result.summary.due)} due · ${esc(result.summary.eligible)} eligible · ${esc(result.summary.blocked)} blocked · ${esc(result.summary.routed)} routed</p>${rows || '<div class="empty-state" style="min-height:120px"><span>No assigned prospects yet.</span></div>'}<p class="safety-note">${esc(result.policy)}</p><button class="button gold" id="modal-close-action">Close</button>`);
    $('#modal-close-action').onclick = closeModal;
  } catch (error) { toast(error.message, true); }
};

$('#campaign-preflight').onclick = async () => {
  if (!editorModel?.id) return;
  try {
    const result = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/preflight`, { method: 'POST', body: '{}' });
    const senders = (result.senders || []).map(row => `<div class="modal-section"><h3>${esc(row.slot)} · ${esc(row.email || 'Disconnected')} · ${esc(row.score)}/100</h3><p class="muted">${row.connected ? 'connected' : 'not connected'} · placement: ${esc(row.providerPlacement.status)}</p>${row.checks.slice(0, 8).map(check => `<p><b>${esc(check.id)}</b> · ${chip(check.status)}<br><small class="muted">${esc(check.detail)}</small></p>`).join('')}</div>`).join('');
    openModal(`<div class="eyebrow">DELIVERABILITY PREFLIGHT</div><h2>${esc(editorModel.name)}</h2><p class="muted">${esc(result.summary.senders)} sender(s) · ${esc(result.summary.blockingChecks)} blocking checks · ${esc(result.summary.warnings)} warnings · score ${esc(result.summary.score)}/100</p>${senders || '<div class="empty-state" style="min-height:120px"><span>No sender accounts are configured.</span></div>'}<p class="safety-note">${esc(result.policy)}</p><button class="button gold" id="modal-close-action">Close</button>`);
    $('#modal-close-action').onclick = closeModal;
  } catch (error) { toast(error.message, true); }
};

$('#campaign-portable-export').onclick = async () => {
  if (!editorModel?.id) return;
  try {
    const payload = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/portable-export`);
    downloadJson(payload, `uberbond-${editorModel.id}-portable.json`);
    toast('Portable campaign export prepared locally');
  } catch (error) { toast(error.message, true); }
};

$$('.nav-item').forEach(button => button.onclick = () => navigate(button.dataset.view));
$$('[data-open-view]').forEach(button => button.onclick = () => navigate(button.dataset.openView));
$('#modal-close').onclick = closeModal; $('#modal').onclick = event => { if (event.target === $('#modal')) closeModal(); };
$('#open-sector-comparison').onclick = openDetailedComparison;
$('#save-token').onclick = async () => { token = $('#token').value.trim(); localStorage.revenueEngineToken = token; await loadAll(); };
$('#refresh-all').onclick = () => loadAll();
$('#advance-plans').onclick = async () => { try { const result = await api('/api/outreach/sequence/advance', { method: 'POST', body: JSON.stringify({}) }); toast(`${result.counts.readyForReview} plan(s) ready for owner review`); await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#global-pause').onclick = async () => { try { if (data.health.globalPaused) { await api('/api/outbound/resume', { method: 'POST' }); toast('Global outbound resumed — owner gate remains active'); } else { await api('/api/outbound/pause', { method: 'POST', body: JSON.stringify({ reason: 'Owner emergency stop from Outreach Workbench' }) }); toast('Global outbound paused'); } await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#new-campaign').onclick = () => { editorModel = newEditorModel(); navigate('campaigns'); renderCampaignList(); renderEditor(); };
$('#add-step').onclick = () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const index = editorModel.sequence.steps.length + 1; editorModel.sequence.steps.push({ id: `step-${Date.now()}`, name: `Step ${index}`, kind: 'followup', delayValue: 3, delayUnit: 'days', delayDays: 3, condition: 'no_reply', variants: [{ id: 'A', label: 'Variant A', weight: 100, enabled: true, subject: 'Re: {{company}}', body: 'Hi {{company}} team,\n\nA short follow-up.\n\nBest,\n{{senderName}}' }] }); renderEditor(); };
$('#campaign-editor-form').onsubmit = async event => { event.preventDefault(); try { syncEditorFromDom(); if (!editorModel.name || !editorModel.offer) return toast('Name and offer are required', true); const path = editorModel.id ? `/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}` : '/api/campaigns'; const campaign = await api(path, { method: editorModel.id ? 'PATCH' : 'POST', body: JSON.stringify(editorModel) }); toast(`Saved ${campaign.name}`); await loadAll(true); selectCampaign(campaign.id); } catch (error) { toast(error.message, true); } };
$('#campaign-diagnostics').onclick = async () => { if (!editorModel?.id) return; try { const result = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/sending-status`); const issues = result.issueTracking?.length ? result.issueTracking.map(issue => `<div class="modal-section"><h3>${esc(issue.code)} · ${chip(issue.severity)}</h3><p>${esc(issue.message)}</p><small class="muted">${esc(issue.action)}</small></div>`).join('') : '<div class="empty-state" style="min-height:120px"><span>No blocking issues observed.</span></div>'; openModal(`<div class="eyebrow">CAMPAIGN DIAGNOSTICS</div><h2>${esc(editorModel.name)}</h2><p class="muted">${chip(result.status)} · ${esc(result.assignedLeads)} assigned · ${esc(result.progress?.percent || 0)}% complete · ${esc(result.due)} due · ${esc(result.connectedSenders)} sender(s)</p>${issues}<p class="safety-note">${esc(result.policy || 'No provider call is implied by this diagnostic.')}</p><button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#campaign-analytics').onclick = async () => { if (!editorModel?.id) return; try { const result = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/analytics`); openModal(`<div class="eyebrow">VARIANT ANALYTICS</div><h2>${esc(result.campaignName || editorModel.name)}</h2><p class="muted">Metric: ${esc(result.metric)} · minimum samples: ${esc(result.minimumSamples)} · sent: ${esc(result.totals.sent)} · replies: ${esc(result.totals.replies)} · cleared: ${money(result.totals.clearedRevenueUsd)}</p>${result.steps.length ? result.steps.map(step => `<div class="modal-section"><h3>${esc(step.stepId)} · variant ${esc(step.variantId)}</h3><p>Sent ${esc(step.sent)} · open ${esc(step.openRate)}% · click ${esc(step.clickRate)}% · reply ${esc(step.replyRate)}% · opportunity ${esc(step.opportunityRate)}%</p></div>`).join('') : '<div class="empty-state"><span>Collect observations before optimizing.</span></div>'}<button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#campaign-placement').onclick = async () => { if (!editorModel?.id) return; try { const plan = await api('/api/outreach/placement/plan', { method: 'POST', body: JSON.stringify({ campaignId: editorModel.id }) }); openModal(`<div class="eyebrow">CAMPAIGN PLACEMENT PLAN</div><h2>${esc(editorModel.name)}</h2>${plan.tests.map(test => `<div class="modal-section"><h3>${esc(test.slot)} · ${esc(test.email || 'Disconnected')}</h3>${test.checks.map(check => `<p><b>${esc(check.name)}</b> · ${chip(check.status)}<br><small class="muted">${esc(check.detail)}</small></p>`).join('')}</div>`).join('')}<button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#campaign-duplicate').onclick = async () => { if (!editorModel?.id) return; try { const duplicate = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/duplicate`, { method: 'POST', body: JSON.stringify({}) }); toast(`Duplicated ${duplicate.name}`); await loadAll(true); selectCampaign(duplicate.id); } catch (error) { toast(error.message, true); } };
$('#campaign-export').onclick = async () => { if (!editorModel?.id) return; try { const payload = await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/export`); const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }); const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `uberbond-${editorModel.id}.json`; link.click(); URL.revokeObjectURL(link.href); toast('Campaign export prepared locally'); } catch (error) { toast(error.message, true); } };
$('#campaign-toggle').onclick = async () => { if (!editorModel?.id) return; try { const action = editorModel.paused ? 'resume' : 'pause'; await api(`/api/outreach/campaigns/${encodeURIComponent(editorModel.id)}/${action}`, { method: 'POST' }); toast(`Campaign ${action}d`); await loadAll(true); selectCampaign(editorModel.id); } catch (error) { toast(error.message, true); } };
$('#preview-sequence').onclick = async () => { try { syncEditorFromDom(); } catch (error) { return toast(error.message, true); } const prospect = data.prospects.find(item => item.status === 'ready') || data.prospects[0]; if (!prospect) return toast('Import or research a prospect first', true); try { const preview = await api('/api/outreach/sequence/preview', { method: 'POST', body: JSON.stringify({ sequence: editorModel.sequence, campaign: editorModel, prospectId: prospect.id }) }); $('#sequence-preview').classList.remove('hidden'); $('#sequence-preview').innerHTML = `<h3>Preview for ${esc(prospect.company)}</h3>${preview.steps.map(step => `<article class="preview-step"><div class="preview-step-head"><span>${esc(step.name)} · ${esc(step.kind)}</span><span>${esc(fmtDate(step.scheduledAt))} · ${esc(step.selectedVariantId)}</span></div><strong>${esc(step.selected?.subject || '')}</strong><pre>${esc(step.selected?.body || '')}</pre>${step.missingTags?.length ? `<p class="warning-text">Missing data: ${esc(step.missingTags.join(', '))}</p>` : step.placeholderTags?.length ? `<p class="muted">Placeholder values used: ${esc(step.placeholderTags.join(', '))}</p>` : ''}</article>`).join('')}`; } catch (error) { toast(error.message, true); } };
$('#prospect-search').oninput = renderProspects; $('#prospect-status').onchange = renderProspects; $('#prospect-campaign').onchange = renderProspects; $('#clear-prospect-filters').onclick = () => { $('#prospect-search').value = ''; $('#prospect-status').value = ''; $('#prospect-campaign').value = ''; renderProspects(); };
$('#run-evidence-search').onclick = async () => { try { const query = { query: $('#evidence-search-query').value.trim(), country: $('#evidence-search-country').value.trim(), minScore: Number($('#evidence-search-min-score').value || 0), researchedOnly: $('#evidence-search-researched-only').checked, hasEmail: $('#evidence-search-has-email').checked }; const result = await api('/api/outreach/evidence-search', { method: 'POST', body: JSON.stringify({ query, limit: 25 }) }); $('#evidence-search-status').textContent = `${result.returned} of ${result.totalMatched} matched`; $('#evidence-search-policy').textContent = result.policy; const rows = result.results.map(item => { const evidenceUrl = /^https?:\/\//i.test(item.evidence?.url || '') ? `<a href="${esc(item.evidence.url)}" target="_blank" rel="noreferrer">Open evidence ↗</a>` : ''; return `<div class="modal-section"><h3>${esc(item.company)} · ${esc(item.evidenceRank)}</h3><p>${esc(item.email || 'No selected email')} · score ${esc(item.score)} · confidence ${esc(item.evidence?.confidence || 0)}</p><p><b>${esc(item.evidence?.title || 'Observed issue')}</b><br><small class="muted">${esc(item.evidence?.excerpt || 'No excerpt recorded.')}</small></p><small class="muted">${esc(item.domain)} ${evidenceUrl ? `· ${evidenceUrl}` : ''}</small></div>`; }).join(''); openModal(`<div class="eyebrow">EVIDENCE SEARCH</div><h2>${esc(result.returned)} observed prospect(s)</h2><p class="muted">Ranked by score, issue confidence and evidence freshness. Suppression and missing-contact policy applied.</p>${rows || '<div class="empty-state" style="min-height:160px"><span>No observed prospects matched these constraints.</span></div>'}<p class="safety-note">${esc(result.policy)}</p><button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#clear-evidence-search').onclick = () => { $('#evidence-search-query').value = ''; $('#evidence-search-country').value = ''; $('#evidence-search-min-score').value = 60; $('#evidence-search-researched-only').checked = true; $('#evidence-search-has-email').checked = true; $('#evidence-search-status').textContent = 'Not run'; $('#evidence-search-policy').textContent = 'Policy: local evidence only; no private-email inference or contact invention.'; };
$('#inbox-search').oninput = renderInbox; $('#inbox-filter').onchange = renderInbox;
$('#select-all').onchange = event => { $$('.prospect-check').forEach(input => { input.checked = event.target.checked; }); updateSelectedCount(); }; document.addEventListener('change', event => { if (event.target.matches('.prospect-check')) updateSelectedCount(); });
$('#apply-bulk').onclick = async () => { const prospectIds = selectedProspectIds(); const action = $('#bulk-action').value; const value = $('#bulk-value').value.trim(); if (!prospectIds.length || !action) return toast('Select prospects and a bulk action', true); try { if (action === 'enroll') { const campaignId = $('#prospect-campaign').value || data.campaigns.find(item => !item.systemKey)?.id; if (!campaignId) throw new Error('Create a sequence first'); await api('/api/outreach/enroll', { method: 'POST', body: JSON.stringify({ campaignId, prospectIds, mode: 'plan' }) }); } else { const payload = { action, prospectIds }; if (action === 'tag') payload.tags = [value]; if (action === 'stage') payload.stage = value; if (action === 'suppress') payload.reason = value || 'owner-bulk-suppression'; await api('/api/outreach/bulk', { method: 'POST', body: JSON.stringify(payload) }); } toast(`Applied ${action} to ${prospectIds.length}`); await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#dry-run-selected').onclick = async () => { const prospectIds = selectedProspectIds(); const campaignId = $('#prospect-campaign').value || data.campaigns.find(item => !item.systemKey)?.id; if (!prospectIds.length || !campaignId) return toast('Select prospects and a sequence first', true); try { const result = await api('/api/outreach/dry-run', { method: 'POST', body: JSON.stringify({ campaignId, prospectIds }) }); openModal(`<div class="eyebrow">NO-EFFECT DRY RUN</div><h2>${result.counts.eligible} eligible · ${result.counts.blocked} blocked</h2><p class="muted">Provider calls: ${result.providerCalls} · External effects: ${result.externalEffects}</p>${result.rows.map(row => `<div class="modal-section"><h3>${esc(row.company)} · ${row.eligible ? 'eligible for review' : 'blocked'}</h3><p class="muted">${esc(row.reasons.join(', ') || 'All deterministic planning gates passed')}</p><small>${row.steps.length} planned step(s)</small></div>`).join('')}<button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#run-research').onclick = async () => { try { await api('/api/run', { method: 'POST', body: JSON.stringify({ limit: 25 }) }); toast('Research batch queued'); await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#poll-replies').onclick = async () => { try { await api('/api/poll-replies', { method: 'POST' }); toast('Reply poll queued'); await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#placement-plan').onclick = async () => { try { const plan = await api('/api/outreach/placement/plan', { method: 'POST', body: JSON.stringify({}) }); openModal(`<div class="eyebrow">PLACEMENT PLAN · NO PROVIDER CALL</div><h2>${plan.tests.length} sender slot(s)</h2><p class="muted">This is a transparent local checklist. Provider inbox/promotions/spam and DNS tests remain marked not-run until an adapter is deliberately configured.</p>${plan.tests.map(test => `<div class="modal-section"><h3>${esc(test.slot)} · ${esc(test.email || 'Disconnected')}</h3>${test.checks.map(check => `<p><b>${esc(check.name)}</b> · ${chip(check.status)}<br><small class="muted">${esc(check.detail)}</small></p>`).join('')}</div>`).join('')}<button class="button gold" id="modal-close-action">Close</button>`); $('#modal-close-action').onclick = closeModal; } catch (error) { toast(error.message, true); } };
$('#connect-a').onclick = () => { location.href = `/oauth/google/start?slot=A&token=${encodeURIComponent(token)}`; }; $('#connect-b').onclick = () => { location.href = `/oauth/google/start?slot=B&token=${encodeURIComponent(token)}`; };
$('#suppression-form').onsubmit = async event => { event.preventDefault(); try { await api('/api/outreach/suppressions', { method: 'POST', body: JSON.stringify({ value: $('#suppression-value').value, reason: $('#suppression-reason').value }) }); $('#suppression-value').value = ''; toast('Suppression added'); await loadAll(true); } catch (error) { toast(error.message, true); } };
$('#automation-form').onsubmit = async event => {
  event.preventDefault();
  try {
    const field = $('#automation-condition-field').value.trim();
    const conditions = field ? [{ field, operator: $('#automation-condition-operator').value, value: $('#automation-condition-value').value.trim() }] : [];
    const plan = await api('/api/outreach/automations', { method: 'POST', body: JSON.stringify({ name: $('#automation-name').value.trim(), trigger: $('#automation-trigger').value, conditionMode: $('#automation-condition-mode').value, conditions, actions: [{ type: $('#automation-action').value }], enabled: $('#automation-enabled').checked }) });
    $('#automation-name').value = ''; $('#automation-condition-field').value = ''; $('#automation-condition-value').value = ''; toast(`Saved ${plan.name}`); await loadAll(true);
  } catch (error) { toast(error.message, true); }
};

loadAll();
setInterval(() => loadAll(true), 30000);
