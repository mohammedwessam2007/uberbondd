import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { config, validateStartupConfig } from './src/config.mjs';
import { createStore, ConflictError, StoreError } from './src/store.mjs';
import { Pipeline } from './src/pipeline.mjs';
import { RevenueEngine } from './src/revenue.mjs';
import { id, now, csvEscape, normalizeDomain } from './src/utils.mjs';
import { parseCsv } from './src/csv.mjs';
import { googleAuthUrl, exchangeCode, sealTokens, getProfile } from './src/gmail.mjs';
import { startScheduler } from './src/scheduler.mjs';
import { DISCOVERY_CATEGORIES, parseBbox, normalizeCategories } from './src/discovery.mjs';
import { parseStrictBoolean, parseDryRunBoolean, InputError } from './src/input.mjs';
import { DurableQueue } from './src/queue.mjs';
import { DiscoveryRunner } from './src/discovery-runner.mjs';
import { importProspects } from './src/prospect-import.mjs';
import { createJobHandlers } from './src/job-handlers.mjs';
import { normalizeCountryList } from './src/send-safety.mjs';
import { verifyUnsubscribeToken } from './src/unsubscribe.mjs';
import { resolveOmniaV9Mode } from './src/omnia-v9/integrations/config.mjs';
import { resolveOutboundFinalAdmissionHook } from './src/omnia-v9/integrations/outbound-admission.mjs';
import { createAuthoritativeOutreachConsequenceGate } from './src/omnia-v9/integrations/outreach-consequence-admission.mjs';
import { digestOutboundEffectPayload } from './src/omnia-v9/integrations/outbound-consequence-gate.mjs';
import {
  createOutreachApproval,
  createOutreachRouteEvidence,
  evaluateOutreachGovernance,
  outreachMessageDigest
} from './src/outreach-governance.mjs';
import {
  OUTREACH_WORKBENCH_VERSION,
  buildDeliverabilitySnapshot,
  buildInboxThreads,
  buildRevenueWeightedAnalytics,
  buildVariantAnalytics,
  buildCampaignSendingStatus,
  buildInboxActionPatch,
  buildOwnerReplyDraft,
  buildSequencePlan,
  defaultSequence,
  enrollProspect,
  advanceSequence,
  normalizeOpportunityStage,
  normalizeSequence,
  previewSequence,
  sanitizeTags
} from './src/outreach-workbench.mjs';
import {
  internalReplyFromProviderEvent,
  normalizeProviderEvent,
  providerWebhookHeaders,
  verifyWebhookSignature
} from './src/outreach-provider-events.mjs';
import {
  evaluateAutomationPlan,
  normalizeAutomationPlan
} from './src/outreach-automation.mjs';
import {
  buildDetailedComparison,
  buildEvidenceLeadSearch,
  buildOwnerEdgePlan,
  buildOwnerUseCaseScorecard
} from './src/outreach-operator.mjs';
import {
  buildCampaignControlPlan,
  buildDeliverabilityPreflight,
  buildPortableCampaignExport,
  buildProviderIntegrationSpec
} from './src/outreach-upgrades.mjs';

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

validateStartupConfig(config);
const root = path.dirname(fileURLToPath(import.meta.url));
const store = createStore(config);
await store.init();
const queue = new DurableQueue(store, config, console);
let revenue;
const omniaV9Mode = resolveOmniaV9Mode(process.env);
console.log(`OMNIA V9 outbound integration mode: ${omniaV9Mode}`);
const pipeline = new Pipeline(store, config, {
  onProspectComplete: async prospect => revenue?.onProspectComplete(prospect),
  outboundFinalAdmissionShadow: resolveOutboundFinalAdmissionHook({ mode: omniaV9Mode, store }),
  outboundConsequenceGate: createAuthoritativeOutreachConsequenceGate({ store, cfg: config })
});
const enqueueResearch = payload => queue.enqueue('research.batch', payload, {
  maxAttempts: 3,
  dedupeKey: payload.leadId ? `research:lead:${payload.leadId}` : `research:${payload.reason || 'manual'}:${Math.floor(Date.now() / 30000)}`
});
revenue = new RevenueEngine(store, config, pipeline, { enqueueResearch });
const discoveryRunner = new DiscoveryRunner(store, config);
const handlers = createJobHandlers({ store, pipeline, revenue, discoveryRunner });
let stopScheduler = () => {};
let localWorkerPromise = null;
if (config.processRole === 'all') {
  stopScheduler = startScheduler(queue, config, console);
  localWorkerPromise = queue.startWorker(handlers, { concurrency: config.queue.concurrency });
}
const oauthStates = new Map();

const baseHeaders = {
  'cache-control': 'no-store',
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'permissions-policy': 'camera=(), microphone=(), geolocation=()'
};
const json = (res, status, data, extra = {}) => {
  res.writeHead(status, { ...baseHeaders, ...extra, 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
};
const text = (res, status, data, type = 'text/plain; charset=utf-8', extra = {}) => {
  res.writeHead(status, { ...baseHeaders, ...extra, 'content-type': type });
  res.end(data);
};
const bodyText = async req => {
  let content = '';
  for await (const chunk of req) {
    content += chunk;
    if (Buffer.byteLength(content) > 5e6) throw new HttpError(413, 'Request body too large');
  }
  return content;
};
const parseBody = async req => {
  const content = await bodyText(req);
  if (!content) return {};
  try { return JSON.parse(content); }
  catch { throw new HttpError(400, 'Malformed JSON body'); }
};
// Constant-time comparison so a valid admin token cannot be recovered byte-by-byte
// through response-timing analysis. timingSafeEqual throws on length mismatch, so
// guard length first (leaking only length, which is standard and negligible here).
const safeEqual = (a, b) => {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
};
const auth = req => {
  if (!config.adminToken) return true;
  const header = req.headers.authorization || '';
  const bearer = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (safeEqual(bearer, config.adminToken)) return true;
  const queryToken = new URL(req.url, config.baseUrl).searchParams.get('token') || '';
  return safeEqual(queryToken, config.adminToken);
};
const pct = (numerator, denominator) => denominator ? Math.round(numerator / denominator * 100) : 0;
const publicApi = pathname => pathname === '/api/health' || pathname === '/api/public/unsubscribe' || pathname === '/api/public/config' || pathname === '/api/public/audit' || pathname.startsWith('/api/public/report/') || pathname.startsWith('/api/public/artifacts/') || pathname === '/api/public/checkout' || pathname === '/webhooks/lemonsqueezy';
const clientIp = req => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
const ownerWorkspace = () => ({
  id: 'owner', mode: 'owner-only', owner: config.sender.name, billing: 'free-owner-seat',
  version: OUTREACH_WORKBENCH_VERSION,
  externalEffects: 'owner-approved-only',
  capabilities: [
    'sequences', 'variants', 'merge-preview', 'spintax', 'conditional-templates',
    'custom-variables', 'precise-delays', 'campaign-lifecycle', 'variant-analytics',
    'owner-optimization', 'dry-run', 'unibox', 'inbox-actions', 'reply-drafts', 'lead-lists',
    'automation-plans', 'automation-execution', 'step-approvals', 'provider-events', 'placement-plan', 'revenue-funnel', 'deliverability', 'suppression', 'v9-authorization',
    'evidence-search', 'owner-use-case-scorecard', 'campaign-diagnostics', 'campaign-control-plan', 'deliverability-preflight', 'portable-campaign-export', 'provider-integration-contract', 'provider-effect-adapter', 'sticky-sender-plan', 'esp-routing', 'owner-edge-plan', 'sender-mesh', 'warmup-ramp-plan', 'evidence-supply-plan', 'owner-copilot'
  ]
});
const boundedIds = value => [...new Set((Array.isArray(value) ? value : []).map(item => String(item || '').trim()).filter(Boolean))].slice(0, 250);
const validProspectIds = async input => {
  const ids = boundedIds(input.prospectIds);
  const prospects = await store.list('prospects');
  const byId = new Map(prospects.map(item => [item.id, item]));
  return { ids, prospects: ids.map(item => byId.get(item)).filter(Boolean), missing: ids.filter(item => !byId.has(item)) };
};
const OUTREACH_EVENT_ALIASES = new Map([
  ['sent', 'sent'], ['delivered', 'delivered'], ['open', 'opened'], ['opened', 'opened'],
  ['click', 'clicked'], ['clicked', 'clicked'], ['reply', 'reply'], ['replied', 'reply'],
  ['bounce', 'hard_bounce'], ['bounced', 'hard_bounce'], ['hard_bounce', 'hard_bounce'],
  ['complaint', 'complaint'], ['unsubscribe', 'unsubscribed'], ['unsubscribed', 'unsubscribed']
]);

async function applyOutreachAutomations(event, { prospect, campaign = null, inbox = '', source = 'provider-event' } = {}) {
  const plans = (await store.list('automationPlans')).filter(plan => plan.enabled === true && plan.id);
  if (!plans.length || !prospect) return [];
  const eventKey = String(event.providerEventKey || `${event.provider || 'provider'}:${event.eventType}:${event.occurredAt || now()}`);
  const replies = await store.list('replies');
  const latestReply = replies.filter(item => item.prospectId === prospect.id)
    .sort((a, b) => String(b.receivedAt || b.createdAt || '').localeCompare(String(a.receivedAt || a.createdAt || '')))[0] || null;
  const results = [];
  for (const plan of plans) {
    const evaluation = evaluateAutomationPlan({ plan, event, prospect, campaign: campaign || {}, now: new Date() });
    if (!evaluation.matched) continue;
    const existing = await store.findOne('automationRuns', { planId: plan.id, eventKey });
    if (existing) {
      results.push({ planId: plan.id, status: 'duplicate', runId: existing.id, externalEffects: 0, providerCalls: 0 });
      continue;
    }
    const run = {
      id: id('automation-run'), planId: plan.id, eventKey, status: 'running',
      eventType: event.eventType, prospectId: prospect.id, source,
      evaluation, actions: [], blockedActions: evaluation.blockedActions,
      createdAt: now(), updatedAt: now()
    };
    try {
      await store.add('automationRuns', run);
    } catch (error) {
      if (error instanceof ConflictError) {
        const duplicate = await store.findOne('automationRuns', { planId: plan.id, eventKey });
        results.push({ planId: plan.id, status: 'duplicate', runId: duplicate?.id || '', externalEffects: 0, providerCalls: 0 });
        continue;
      }
      throw error;
    }
    let currentProspect = prospect;
    const actionResults = [];
    for (const action of evaluation.actions) {
      let status = 'applied';
      let detail = {};
      try {
        if (action.type === 'stop_sequence') {
          const sequenceState = currentProspect.sequenceState
            ? { ...currentProspect.sequenceState, status: 'stopped', stoppedReason: `automation:${plan.id}`, nextStepAt: null, nextStep: null }
            : currentProspect.sequenceState;
          currentProspect = await store.patch('prospects', prospect.id, { nextFollowupAt: null, sequenceState });
        } else if (action.type === 'create_owner_reply_draft') {
          const draft = buildOwnerReplyDraft({ prospect: currentProspect, reply: latestReply || { subject: event.replySubject || event.subject || '', label: currentProspect.replyLabel }, sender: config.sender, offer: campaign?.offer || '' });
          const record = { id: id('replydraft'), prospectId: prospect.id, threadId: latestReply?.threadId || event.threadId || prospect.threadId || '', status: 'draft', replyId: latestReply?.id || '', automationPlanId: plan.id, ...draft, createdAt: now(), updatedAt: now() };
          await store.add('replyDrafts', record);
          detail = { draftId: record.id };
        } else if (action.type === 'route_to_unibox') {
          detail = { routed: true, threadId: event.threadId || currentProspect.threadId || '' };
        } else if (action.type === 'global_suppress_email') {
          const email = String(currentProspect.contact?.email || event.leadEmail || '').trim().toLowerCase();
          if (!email) { status = 'blocked'; detail = { reason: 'recipient-email-missing' }; }
          else {
            try { await store.add('suppressions', { id: id('sup'), value: email, reason: `automation:${plan.id}`, createdAt: now() }); }
            catch (error) { if (!(error instanceof ConflictError)) throw error; }
            const sequenceState = currentProspect.sequenceState
              ? { ...currentProspect.sequenceState, status: 'stopped', stoppedReason: `automation:${plan.id}`, nextStepAt: null, nextStep: null }
              : currentProspect.sequenceState;
            currentProspect = await store.patch('prospects', prospect.id, { status: 'suppressed', nextFollowupAt: null, sequenceState });
          }
        } else if (action.type === 'pause_sender_for_review') {
          if (!inbox) { status = 'blocked'; detail = { reason: 'sender-slot-missing' }; }
          else { await store.setSenderPaused(inbox, true, `Automation ${plan.name} requested review`); detail = { inbox, paused: true }; }
        } else if (action.type === 'global_pause_review') {
          const notification = { id: id('notification'), type: 'outreach-automation-global-pause-review', prospectId: prospect.id, status: 'unread', message: `Automation ${plan.name} requested an owner review for global outbound pause`, createdAt: now(), updatedAt: now() };
          await store.add('notifications', notification);
          detail = { notificationId: notification.id, ownerActionRequired: true };
        } else if (action.type === 'create_opportunity') {
          const sequenceState = currentProspect.sequenceState
            ? { ...currentProspect.sequenceState, status: 'stopped', stoppedReason: `automation:${plan.id}`, nextStepAt: null, nextStep: null }
            : currentProspect.sequenceState;
          currentProspect = await store.patch('prospects', prospect.id, { opportunityStage: 'opportunity', opportunityMarkedAt: now(), nextFollowupAt: null, sequenceState });
        } else if (action.type === 'mark_revenue_continuity') {
          currentProspect = await store.patch('prospects', prospect.id, { revenueContinuityReviewAt: now(), nextAction: 'Owner review: connect this opportunity to cleared revenue evidence' });
        } else if (action.type === 'create_owner_review') {
          const notification = { id: id('notification'), type: 'outreach-automation-owner-review', prospectId: prospect.id, status: 'unread', message: `Automation ${plan.name} created an owner review item`, createdAt: now(), updatedAt: now() };
          await store.add('notifications', notification);
          detail = { notificationId: notification.id };
        } else if (action.type === 'recalculate_evidence_readiness') {
          currentProspect = await store.patch('prospects', prospect.id, { evidenceReadinessReviewAt: now() });
        } else if (action.type === 'delay') {
          const seconds = Number(action.params.seconds || 0);
          currentProspect = await store.patch('prospects', prospect.id, { automationNextActionAt: new Date(Date.now() + seconds * 1000).toISOString() });
          detail = { seconds };
        }
      } catch (error) {
        status = 'error'; detail = { reason: error.message };
      }
      actionResults.push({ type: action.type, status, detail, externalEffects: 0, providerCalls: 0 });
    }
    const runStatus = actionResults.some(item => item.status === 'error') ? 'error' : actionResults.some(item => item.status === 'blocked') || evaluation.blockedActions.length ? 'needs_owner_review' : 'applied';
    await store.patch('automationRuns', run.id, { status: runStatus, actions: actionResults, finishedAt: now(), updatedAt: now() });
    await store.log('outreach_automation_run', { planId: plan.id, runId: run.id, eventKey, prospectId: prospect.id, status: runStatus, actionCount: actionResults.length, blockedActionCount: evaluation.blockedActions.length, externalEffects: 0, providerCalls: 0 });
    results.push({ planId: plan.id, runId: run.id, status: runStatus, actions: actionResults, blockedActions: evaluation.blockedActions, externalEffects: 0, providerCalls: 0 });
  }
  return results;
}

async function applyOutreachProviderEvent(event, { source = 'provider-webhook' } = {}) {
  let ledger = await store.findOne('providerEvents', { providerEventKey: event.providerEventKey });
  if (ledger?.status === 'applied' || ledger?.status === 'unmatched') {
    return { accepted: true, duplicate: true, matched: ledger.status === 'applied', providerEventKey: event.providerEventKey, externalEffects: 0 };
  }
  if (!ledger) {
    try {
      ledger = await store.add('providerEvents', {
        id: id('provider-event'), provider: event.provider, providerEventKey: event.providerEventKey,
        providerEventId: event.providerEventId, eventType: event.eventType, campaignId: event.campaignId,
        leadEmail: event.leadEmail, status: 'received', receivedAt: event.receivedAt,
        data: event, createdAt: event.receivedAt, updatedAt: event.receivedAt
      });
    } catch (error) {
      if (!(error instanceof ConflictError)) throw error;
      ledger = await store.findOne('providerEvents', { providerEventKey: event.providerEventKey });
      if (ledger?.status === 'applied' || ledger?.status === 'unmatched') {
        return { accepted: true, duplicate: true, matched: ledger.status === 'applied', providerEventKey: event.providerEventKey, externalEffects: 0 };
      }
    }
  }

  const [messages, prospects, accounts] = await Promise.all([
    store.list('messages'), store.list('prospects'), store.list('accounts')
  ]);
  const messageIdentities = item => [item.id, item.gmailId, item.emailId, item.providerEmailId, item.providerMessageId].filter(Boolean).map(String);
  const message = messages.find(item =>
    (event.emailId && messageIdentities(item).includes(String(event.emailId))) ||
    (event.threadId && String(item.threadId || '') === String(event.threadId) && (!event.leadEmail || String(item.to || '').toLowerCase() === event.leadEmail))
  ) || null;
  const prospect = (event.prospectId && prospects.find(item => item.id === event.prospectId)) ||
    (message?.prospectId && prospects.find(item => item.id === message.prospectId)) ||
    prospects.find(item => {
      const emailMatches = event.leadEmail && String(item.contact?.email || '').trim().toLowerCase() === event.leadEmail;
      const campaignMatches = !event.campaignId || String(item.campaignId || '') === String(event.campaignId);
      return emailMatches && campaignMatches;
    }) || null;

  if (!prospect) {
    await store.patch('providerEvents', ledger.id, { status: 'unmatched', matchedAt: now(), updatedAt: now() });
    await store.log('outreach_provider_event_unmatched', {
      provider: event.provider, providerEventKey: event.providerEventKey, providerEventId: event.providerEventId,
      eventType: event.eventType, campaignId: event.campaignId, leadEmail: event.leadEmail, source, externalEffects: 0
    });
    return { accepted: true, duplicate: false, matched: false, providerEventKey: event.providerEventKey, externalEffects: 0, providerCalls: 0 };
  }

  const inbox = String(event.raw?.inbox || message?.inbox || prospect.inbox || accounts.find(item => item.email?.toLowerCase() === event.accountEmail)?.slot || '').trim();
  const recipientEmail = String(prospect.contact?.email || event.leadEmail || '').trim().toLowerCase();
  try {
    await store.recordOutboundEvent({
      id: id('outbound-event'), providerEventId: event.providerEventKey, inbox, eventType: event.eventType,
      prospectId: prospect.id, recipientEmail,
      detail: {
        provider: event.provider, providerEventId: event.providerEventId, providerEventKey: event.providerEventKey,
        emailId: event.emailId, campaignId: event.campaignId, source
      }, occurredAt: event.occurredAt
    }, {
      hardBouncePauseThreshold: config.outbound?.hardBouncePauseThreshold,
      complaintPauseThreshold: config.outbound?.complaintPauseThreshold,
      failurePauseThreshold: config.outbound?.failurePauseThreshold
    });
  } catch (error) {
    if (!(error instanceof ConflictError)) throw error;
  }

  let currentMessage = message;
  if (!currentMessage && event.eventType === 'sent' && event.emailId) {
    currentMessage = await store.add('messages', {
      id: `msg_${event.providerEventKey.replace(/[^a-z0-9_-]/gi, '').slice(0, 100)}`,
      prospectId: prospect.id, campaignId: prospect.campaignId || event.campaignId || null, inbox,
      to: event.leadEmail, from: event.accountEmail, provider: event.provider,
      providerEmailId: event.emailId, emailId: event.emailId, subject: event.subject,
      body: event.raw?.email_text || '', threadId: event.threadId || `provider:${event.provider}:${prospect.id}`,
      sentAt: event.occurredAt, createdAt: event.receivedAt, providerEventId: event.providerEventId
    });
  } else if (currentMessage && ['sent', 'opened', 'clicked'].includes(event.eventType)) {
    const patch = event.eventType === 'opened'
      ? { opened: true, openedAt: event.occurredAt }
      : event.eventType === 'clicked'
        ? { clicked: true, clickedAt: event.occurredAt }
        : { provider: event.provider, providerEmailId: event.emailId || currentMessage.providerEmailId || '' };
    currentMessage = await store.patch('messages', currentMessage.id, patch);
  }

  const stopSequence = reason => prospect.sequenceState
    ? { ...prospect.sequenceState, status: 'stopped', stoppedReason: reason, nextStepAt: null, nextStep: null }
    : prospect.sequenceState;
  const patch = {
    providerLastEvent: event.eventType, providerLastEventAt: event.occurredAt,
    providerLastEventKey: event.providerEventKey, providerLeadStatus: event.rawType,
    ...(event.threadId && !prospect.threadId ? { threadId: event.threadId } : {})
  };
  if (event.eventType === 'reply') {
    const reply = internalReplyFromProviderEvent(event, { prospectId: prospect.id, threadId: event.threadId || currentMessage?.threadId || prospect.threadId });
    if (reply) {
      try { await store.add('replies', reply); }
      catch (error) { if (!(error instanceof ConflictError)) throw error; }
    }
    patch.status = 'replied'; patch.repliedAt = event.occurredAt; patch.replyEventAt = event.occurredAt;
    patch.nextFollowupAt = null; patch.sequenceState = stopSequence('reply-event');
  } else if (event.eventType === 'automatic') {
    patch.status = 'sent'; patch.replyLabel = 'automatic'; patch.automaticReplyAt = event.occurredAt;
    patch.automaticReplyNeedsOwnerReview = true; patch.nextFollowupAt = null;
    const campaign = prospect.sequenceState?.campaignId ? await store.get('campaigns', prospect.sequenceState.campaignId) : null;
    if (campaign?.sequence?.settings?.stopOnAutoReply !== false) patch.sequenceState = stopSequence('automatic-reply');
  } else if (['hard_bounce', 'complaint', 'unsubscribed'].includes(event.eventType)) {
    patch.status = event.eventType === 'unsubscribed' ? 'suppressed' : event.eventType === 'hard_bounce' ? 'bounce' : 'complaint';
    patch.nextFollowupAt = null; patch.sequenceState = stopSequence(event.eventType);
    if (recipientEmail) {
      try { await store.add('suppressions', { id: id('sup'), value: recipientEmail, reason: `provider-event:${event.eventType}`, createdAt: event.occurredAt }); }
      catch (error) { if (!(error instanceof ConflictError)) throw error; }
    }
  } else if (event.eventType === 'positive') {
    patch.status = 'replied'; patch.replyLabel = 'positive'; patch.repliedAt = event.occurredAt;
    patch.opportunityStage = 'opportunity'; patch.nextFollowupAt = null; patch.sequenceState = stopSequence('positive-status');
  } else if (event.eventType === 'negative') {
    patch.status = 'replied'; patch.replyLabel = 'negative'; patch.nextFollowupAt = null; patch.sequenceState = stopSequence('negative-status');
  } else if (['meeting_booked', 'meeting_completed'].includes(event.eventType)) {
    patch.opportunityStage = 'meeting'; patch.meetingAt = event.occurredAt;
  } else if (event.eventType === 'out_of_office') {
    patch.replyLabel = 'automatic'; patch.outOfOfficeAt = event.occurredAt;
  }
  const updatedProspect = await store.patch('prospects', prospect.id, patch);
  const campaign = updatedProspect?.campaignId ? await store.get('campaigns', updatedProspect.campaignId) : null;
  const automationRuns = await applyOutreachAutomations(event, { prospect: updatedProspect || prospect, campaign, inbox, source });
  await store.patch('providerEvents', ledger.id, { status: 'applied', prospectId: prospect.id, messageId: currentMessage?.id || '', automationRunIds: automationRuns.map(item => item.runId).filter(Boolean), appliedAt: now(), updatedAt: now() });
  await store.log('outreach_provider_event_applied', {
    provider: event.provider, providerEventKey: event.providerEventKey, providerEventId: event.providerEventId,
    eventType: event.eventType, prospectId: prospect.id, messageId: currentMessage?.id || '', source, externalEffects: 0
  });
  return { accepted: true, duplicate: false, matched: true, providerEventKey: event.providerEventKey, eventType: event.eventType, prospectId: prospect.id, messageId: currentMessage?.id || '', automationRuns, externalEffects: 0, providerCalls: 0 };
}
async function summary() {
  const [prospects, jobs, suppressions, accounts, discoveryRuns, revenueSummary, queueStats, pausedState, workers, settings, senderHealth, outboundReservations] = await Promise.all([
    store.list('prospects'), store.list('jobs'), store.list('suppressions'),
    store.list('accounts'), store.list('discoveryRuns'), revenue.summary(), queue.stats(), queue.pausedState(), queue.liveWorkers(),
    store.getSettings(), store.list('senderHealth'), store.list('outboundReservations')
  ]);
  const completed = prospects.filter(item => ['ready', 'research-complete', 'rejected', 'sent', 'replied'].includes(item.status));
  const qualified = prospects.filter(item => ['ready', 'research-complete', 'sent', 'replied'].includes(item.status));
  const today = new Date().toISOString().slice(0, 10);
  return {
    workspace: ownerWorkspace(),
    autopilot: config.autopilot,
    running: Number(queueStats.counts?.active || 0) > 0,
    paused: Boolean(pausedState.paused),
    workerOnline: workers.length > 0,
    workers,
    processRole: config.processRole,
    storeBackend: config.storeBackend,
    prospects: prospects.length,
    queued: prospects.filter(item => ['queued', 'new', 'retry', 'claimed'].includes(item.status)).length,
    completed: completed.length,
    qualified: qualified.length,
    ready: prospects.filter(item => item.status === 'ready').length,
    sent: prospects.filter(item => item.status === 'sent').length,
    replied: prospects.filter(item => item.status === 'replied').length,
    positive: prospects.filter(item => item.replyLabel === 'positive').length,
    suppressed: suppressions.length,
    qualificationRate: pct(qualified.length, completed.length),
    jobs: jobs.slice(0, 12),
    queue: queueStats,
    accounts: accounts.map(account => ({ slot: account.slot, email: account.email, connected: account.connected, lastReplyPoll: account.lastReplyPoll })),
    revenue: revenueSummary,
    discovery: {
      enabled: config.discovery.enabled,
      dryRun: config.discovery.dryRun,
      dailyCap: config.discovery.dailyCap,
      runs: discoveryRuns.length,
      importedToday: discoveryRuns
        .filter(run => (run.runDate || run.startedAt?.slice(0, 10)) === today && run.status !== 'error')
        .reduce((sum, run) => sum + Number(run.importedCount || 0), 0)
    },
    outbound: {
      enabled: config.outbound.enabled,
      dryRun: config.outbound.dryRun,
      globalPaused: settings.outboundPaused === true,
      pauseReason: settings.outboundPauseReason || '',
      allowedCountries: normalizeCountryList(config.outbound.allowedCountries),
      senderHealth,
      reservedToday: outboundReservations.filter(item => String(item.reservedAt || '').startsWith(today) && ['reserved','dispatching','sent','uncertain'].includes(item.status)).length,
      uncertain: outboundReservations.filter(item => item.status === 'uncertain').length
    }
  };
}

async function applyUnsubscribe(token) {
  const verified = verifyUnsubscribeToken(token, config.unsubscribeSecret);
  if (!verified) throw new HttpError(400, 'This unsubscribe link is invalid or expired');
  const prospect = await store.get('prospects', verified.prospectId);
  if (!prospect?.contact?.email) throw new HttpError(404, 'The outreach record was not found');
  const email = String(prospect.contact.email).toLowerCase();
  try {
    await store.add('suppressions', { id: id('sup'), value: email, reason: 'one-click-unsubscribe', createdAt: now() });
  } catch (error) {
    if (!(error instanceof ConflictError)) throw error;
  }
  await store.patch('prospects', prospect.id, { status: 'suppressed', nextFollowupAt: null, unsubscribedAt: now() });
  await store.log('one_click_unsubscribe', { prospectId: prospect.id, email });
  return { ok: true };
}

async function serveFile(res, file, contentType, cache = 'private, max-age=300') {
  try {
    const data = await fs.readFile(file);
    res.writeHead(200, { ...baseHeaders, 'content-type': contentType, 'cache-control': cache });
    res.end(data);
    return true;
  } catch { return false; }
}

async function staticFile(req, res) {
  let relative = decodeURIComponent(new URL(req.url, config.baseUrl).pathname);
  if (relative === '/') relative = '/index.html';
  if (relative.startsWith('/screenshots/')) {
    const file = path.resolve(config.screenshotDir, relative.slice('/screenshots/'.length));
    if (!file.startsWith(path.resolve(config.screenshotDir) + path.sep)) return false;
    return serveFile(res, file, 'image/png');
  }
  const file = path.resolve(root, 'public', relative.slice(1));
  if (!file.startsWith(path.resolve(root, 'public') + path.sep)) return false;
  const extension = path.extname(file);
  const types = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
    '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json'
  };
  try {
    const data = await fs.readFile(file);
    res.writeHead(200, {
      ...baseHeaders,
      'content-type': types[extension] || 'application/octet-stream',
      'cache-control': extension === '.html' ? 'no-store' : 'public, max-age=3600',
      'content-security-policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data: blob:; frame-ancestors 'none'; base-uri 'self'; form-action 'self' https://*.lemonsqueezy.com https://*.paddle.com"
    });
    res.end(data);
    return true;
  } catch { return false; }
}


function errorStatus(error) {
  if (error instanceof HttpError || error instanceof InputError) return error.status;
  if (error instanceof ConflictError) return 409;
  if (error instanceof StoreError && error.code === 'FOREIGN_KEY') return 422;
  if (/Too many|cap reached/i.test(error.message)) return 429;
  if (/disabled|not configured|DATABASE_URL/i.test(error.message)) return 503;
  return 500;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, config.baseUrl);
    const method = req.method;
    if (method === 'GET' && url.pathname === '/unsubscribe') {
      const token = url.searchParams.get('token') || '';
      const action = `/api/public/unsubscribe?token=${encodeURIComponent(token)}`;
      return text(res, 200, `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Stop UberBond messages</title><style>body{font-family:system-ui;background:#05070d;color:#eef1f8;display:grid;place-items:center;min-height:100vh;margin:0}main{max-width:520px;padding:32px;border:1px solid #293044;border-radius:16px;background:#0a0e19}button{padding:14px 20px;border:0;border-radius:10px;background:#f7a327;color:#111;font-weight:700}</style></head><body><main><h1>Stop future messages</h1><p>Confirm once and this address will be added to UberBond’s permanent suppression list.</p><form method="post" action="${action}"><button type="submit">Unsubscribe</button></form></main></body></html>`, 'text/html; charset=utf-8');
    }
    if (method === 'POST' && url.pathname === '/api/public/unsubscribe') {
      await bodyText(req);
      return json(res, 200, await applyUnsubscribe(url.searchParams.get('token') || ''));
    }
    if (method === 'POST' && /^\/webhooks\/outreach\/[a-z0-9-]+$/.test(url.pathname)) {
      const provider = url.pathname.split('/').pop().toLowerCase();
      if (provider !== 'instantly') return json(res, 404, { error: 'Unsupported outreach provider' });
      const raw = await bodyText(req);
      const headers = providerWebhookHeaders(req.headers);
      const verification = verifyWebhookSignature({
        rawBody: raw, signature: headers.signature, timestamp: headers.timestamp,
        secret: config.outbound.webhookSecret, maxAgeSeconds: config.outbound.webhookMaxAgeSeconds
      });
      if (!verification.ok) {
        const status = verification.reason === 'webhook-secret-not-configured' ? 503 : 401;
        return json(res, status, { error: status === 503 ? 'Webhook receiver is not configured' : 'Invalid webhook signature' });
      }
      let input;
      try { input = raw ? JSON.parse(raw) : {}; }
      catch { throw new HttpError(400, 'Malformed webhook JSON body'); }
      let event;
      try { event = normalizeProviderEvent(input, { provider, rawBody: raw, receivedAt: new Date() }); }
      catch (error) { throw new HttpError(422, error.message); }
      return json(res, 202, await applyOutreachProviderEvent(event, { source: `signed-${provider}-webhook` }));
    }
    if ((url.pathname.startsWith('/api/') || url.pathname === '/oauth/google/start') && !publicApi(url.pathname) && !auth(req)) {
      return json(res, 401, { error: 'Unauthorized' });
    }

    if (method === 'GET' && url.pathname === '/api/health') {
      const [pausedState, workers, queueStats] = await Promise.all([queue.pausedState(), queue.liveWorkers(), queue.stats()]);
      return json(res, 200, { ok: true, time: now(), autopilot: config.autopilot, storeBackend: config.storeBackend, processRole: config.processRole, worker: { online: workers.length > 0, paused: Boolean(pausedState.paused), activeJobs: Number(queueStats.counts?.active || 0), workers }, version: `revenue-engine-${config.version}` });
    }
    if (method === 'GET' && url.pathname === '/api/public/config') {
      return json(res, 200, {
        brand: 'UberBond', publicAuditEnabled: config.revenue.publicIntake,
        prices: { full: config.revenue.fullAuditPrice, strategy: config.revenue.strategyAuditPrice, monitoring: config.revenue.monitoringPrice, implementationFrom: config.revenue.implementationFrom },
        bookingUrl: config.revenue.bookingUrl
      });
    }
    if (method === 'POST' && url.pathname === '/api/public/audit') {
      return json(res, 202, await revenue.createLead(await parseBody(req), clientIp(req)));
    }
    if (method === 'GET' && url.pathname.startsWith('/api/public/report/')) {
      const token = decodeURIComponent(url.pathname.slice('/api/public/report/'.length));
      const report = await revenue.publicReport(token);
      return report ? json(res, 200, report) : json(res, 404, { error: 'Report not found' });
    }
    if (method === 'GET' && url.pathname.startsWith('/api/public/artifacts/')) {
      const artifactId = decodeURIComponent(url.pathname.slice('/api/public/artifacts/'.length));
      if (!/^artifact_[a-z0-9-]+$/i.test(artifactId)) return json(res, 400, { error: 'Invalid artifact id' });
      const artifact = await store.getArtifact(artifactId);
      if (!artifact) return json(res, 404, { error: 'Artifact not found' });
      res.writeHead(200, {
        ...baseHeaders,
        'content-type': artifact.contentType || 'application/octet-stream',
        'content-length': String(artifact.byteSize || artifact.content.length),
        'cache-control': 'public, max-age=86400, immutable',
        etag: `"${artifact.sha256}"`
      });
      return res.end(artifact.content);
    }
    if (method === 'POST' && url.pathname === '/api/public/checkout') {
      const input = await parseBody(req);
      const lead = await revenue.leadByToken(input.token);
      if (!lead) return json(res, 404, { error: 'Report not found' });
      const checkout = revenue.checkoutFor(lead, String(input.product || 'full'));
      return checkout.configured ? json(res, 200, checkout) : json(res, 503, { error: 'Checkout is not configured yet', checkout });
    }
    if (method === 'POST' && url.pathname === '/webhooks/lemonsqueezy') {
      const raw = await bodyText(req);
      return json(res, 200, await revenue.handleLemonWebhook(raw, req.headers['x-signature']));
    }

    if (method === 'GET' && url.pathname === '/api/summary') return json(res, 200, await summary());
    if (method === 'GET' && url.pathname === '/api/outreach/workspace') {
      const [campaigns, prospects, suppressions, accounts, senderHealth, leadLists, replyDrafts] = await Promise.all([
        store.list('campaigns'), store.list('prospects'), store.list('suppressions'), store.list('accounts'), store.list('senderHealth'), store.list('leadLists'), store.list('replyDrafts')
      ]);
      return json(res, 200, {
        workspace: ownerWorkspace(),
        counts: {
          campaigns: campaigns.filter(item => !item.systemKey).length,
          prospects: prospects.length,
          enrolled: prospects.filter(item => item.sequenceState?.status === 'active').length,
          suppressed: suppressions.length,
          leadLists: leadLists.length,
          replyDrafts: replyDrafts.filter(item => item.status === 'draft').length,
          connectedMailboxes: accounts.filter(item => item.connected).length,
          pausedMailboxes: senderHealth.filter(item => item.paused).length
        },
        outbound: {
          enabled: config.outbound.enabled,
          dryRun: config.outbound.dryRun,
          launchPhase: config.outbound.launchPhase,
          globalPaused: (await store.getSettings()).outboundPaused === true
        },
        comparison: buildOwnerUseCaseScorecard({ externalProvider: config.outbound.provider })
      });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/comparison') {
      return json(res, 200, buildOwnerUseCaseScorecard({ externalProvider: config.outbound.provider }));
    }
    if (method === 'GET' && url.pathname === '/api/outreach/comparison/sectors') {
      return json(res, 200, buildDetailedComparison({ externalProvider: config.outbound.provider }));
    }
    if (method === 'GET' && url.pathname === '/api/outreach/provider-spec') {
      return json(res, 200, buildProviderIntegrationSpec({
        baseUrl: config.baseUrl,
        provider: config.outbound.provider,
        webhookSecretConfigured: Boolean(config.outbound.webhookSecret)
      }));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/evidence-search') {
      const input = await parseBody(req);
      const [prospects, suppressions] = await Promise.all([store.list('prospects'), store.list('suppressions')]);
      return json(res, 200, buildEvidenceLeadSearch({ prospects, suppressions, query: input.query && typeof input.query === 'object' ? input.query : input, limit: input.limit }));
    }
    if (method === 'GET' && url.pathname === '/api/outreach/edge-plan') {
      const [prospects, suppressions, campaigns, accounts, senderHealth, outboundEvents, outboundReservations, messages, replies, settings] = await Promise.all([
        store.list('prospects'), store.list('suppressions'), store.list('campaigns'), store.list('accounts'), store.list('senderHealth'),
        store.list('outboundEvents'), store.list('outboundReservations'), store.list('messages'), store.list('replies'), store.getSettings()
      ]);
      const inbox = buildInboxThreads({ prospects, messages, replies });
      return json(res, 200, buildOwnerEdgePlan({
        prospects, suppressions, campaigns, accounts, senderHealth, outboundEvents, outboundReservations, inbox,
        health: { uncertain: outboundReservations.filter(item => item.status === 'uncertain').length, globalPaused: settings.outboundPaused === true }
      }));
    }
    if (method === 'GET' && url.pathname === '/api/outreach/analytics') {
      const [prospects, messages, replies, orders, subscriptions, revenueEvents] = await Promise.all([
        store.list('prospects'), store.list('messages'), store.list('replies'), store.list('orders'),
        store.list('subscriptions'), store.list('revenueEvents')
      ]);
      return json(res, 200, buildRevenueWeightedAnalytics({ prospects, messages, replies, orders, subscriptions, revenueEvents }));
    }
    if (method === 'GET' && /^\/api\/outreach\/campaigns\/[^/]+\/analytics$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const [prospects, messages, replies, orders, revenueEvents, outboundEvents] = await Promise.all([
        store.list('prospects'), store.list('messages'), store.list('replies'), store.list('orders'),
        store.list('revenueEvents'), store.list('outboundEvents')
      ]);
      return json(res, 200, buildVariantAnalytics({ campaignId, campaign, prospects, messages, replies, orders, revenueEvents, outboundEvents }));
    }
    if (method === 'GET' && /^\/api\/outreach\/campaigns\/[^/]+\/sending-status$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const [prospects, accounts, senderHealth, settings] = await Promise.all([
        store.list('prospects'), store.list('accounts'), store.list('senderHealth'), store.getSettings()
      ]);
      return json(res, 200, buildCampaignSendingStatus({ campaign, prospects, accounts, senderHealth, globalPaused: settings.outboundPaused === true }));
    }
    if (method === 'GET' && /^\/api\/outreach\/campaigns\/[^/]+\/control-plan$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const [prospects, messages, outboundEvents, accounts, senderHealth, suppressions] = await Promise.all([
        store.list('prospects'), store.list('messages'), store.list('outboundEvents'), store.list('accounts'), store.list('senderHealth'), store.list('suppressions')
      ]);
      const outboundReservations = await store.list('outboundReservations');
      return json(res, 200, buildCampaignControlPlan({ campaign, prospects, messages, outboundEvents, outboundReservations, accounts, senderHealth, suppressions, now: new Date() }));
    }
    if (method === 'POST' && /^\/api\/outreach\/campaigns\/[^/]+\/preflight$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const [accounts, senderHealth] = await Promise.all([store.list('accounts'), store.list('senderHealth')]);
      return json(res, 200, buildDeliverabilityPreflight({ campaign, accounts, senderHealth, now: new Date() }));
    }
    if (method === 'GET' && /^\/api\/outreach\/campaigns\/[^/]+\/export$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const prospects = (await store.list('prospects')).filter(item => item.campaignId === campaignId);
      return json(res, 200, { exportVersion: 'uberbond.outreach-campaign-export.v1', exportedAt: now(), campaign, prospects: prospects.map(item => ({ id: item.id, company: item.company, domain: item.domain, contact: item.contact, evidence: item.issue, score: item.score, sequenceState: item.sequenceState })) }, { 'content-disposition': `attachment; filename="uberbond-${campaignId}.json"` });
    }
    if (method === 'GET' && /^\/api\/outreach\/campaigns\/[^/]+\/portable-export$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const [prospects, suppressions] = await Promise.all([store.list('prospects'), store.list('suppressions')]);
      return json(res, 200, buildPortableCampaignExport({ campaign, prospects, suppressions, now: new Date() }), { 'content-disposition': `attachment; filename="uberbond-${campaignId}-portable.json"` });
    }
    if (method === 'POST' && /^\/api\/outreach\/campaigns\/[^/]+\/duplicate$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const current = await store.get('campaigns', campaignId);
      if (!current) throw new HttpError(404, 'Campaign not found');
      const input = await parseBody(req);
      const duplicate = {
        ...current,
        id: id('camp'),
        name: String(input.name || `${current.name || 'Campaign'} copy`).slice(0, 180),
        approved: false,
        autoSend: false,
        paused: true,
        status: 'draft',
        createdAt: now(),
        updatedAt: now(),
        sequence: structuredClone(current.sequence || defaultSequence(current)),
        sequenceVersion: Number(current.sequenceVersion || current.sequence?.version || 1)
      };
      await store.add('campaigns', duplicate);
      await store.log('outreach_campaign_duplicated', { sourceCampaignId: campaignId, campaignId: duplicate.id });
      return json(res, 201, duplicate);
    }
    if (method === 'POST' && /^\/api\/outreach\/campaigns\/[^/]+\/(pause|resume)$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const action = url.pathname.split('/')[5];
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const updated = await store.patch('campaigns', campaignId, { paused: action === 'pause', status: action === 'pause' ? 'paused' : 'active', updatedAt: now() });
      await store.log(`outreach_campaign_${action}d`, { campaignId, ownerOnly: true });
      return json(res, 200, updated);
    }
    if (method === 'POST' && /^\/api\/outreach\/campaigns\/[^/]+\/optimize-plan$/.test(url.pathname)) {
      const campaignId = decodeURIComponent(url.pathname.split('/')[4]);
      const campaign = await store.get('campaigns', campaignId);
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const input = await parseBody(req);
      const [prospects, messages, replies, orders, revenueEvents, outboundEvents] = await Promise.all([
        store.list('prospects'), store.list('messages'), store.list('replies'), store.list('orders'),
        store.list('revenueEvents'), store.list('outboundEvents')
      ]);
      const analytics = buildVariantAnalytics({ campaignId, campaign, prospects, messages, replies, orders, revenueEvents, outboundEvents });
      const eligible = analytics.steps.filter(item => item.sent >= analytics.minimumSamples);
      const winners = new Map();
      for (const item of eligible) {
        const current = winners.get(item.stepId);
        if (!current || Number(item[analytics.metric] || 0) > Number(current[analytics.metric] || 0)) winners.set(item.stepId, item);
      }
      const plan = [...winners.values()].map(winner => ({ stepId: winner.stepId, keepVariantId: winner.variantId, metric: analytics.metric, value: winner[analytics.metric], disable: eligible.filter(item => item.stepId === winner.stepId && item.variantId !== winner.variantId).map(item => item.variantId) }));
      if (input.apply === true) {
        if (input.confirmSequenceChange !== true) throw new HttpError(400, 'Set confirmSequenceChange=true to apply an optimization plan');
        const sequence = structuredClone(campaign.sequence || defaultSequence(campaign));
        for (const item of plan) {
          const step = sequence.steps?.find(stepValue => stepValue.id === item.stepId);
          if (!step) continue;
          step.variants = (step.variants || []).map(variant => ({ ...variant, enabled: variant.id === item.keepVariantId || !item.disable.includes(variant.id) }));
        }
        sequence.version = Number(sequence.version || 1) + 1;
        const updated = await store.patch('campaigns', campaignId, { sequence: normalizeSequence(sequence, { campaign }), sequenceVersion: Number(campaign.sequenceVersion || sequence.version - 1) + 1, approved: false, autoSend: false, paused: true, status: 'draft', updatedAt: now() });
        await store.log('outreach_campaign_optimization_applied', { campaignId, plan, ownerReviewRequired: true });
        return json(res, 200, { applied: true, plan, campaign: updated, externalEffects: 0 });
      }
      return json(res, 200, { applied: false, plan, analytics, externalEffects: 0, policy: 'recommendation only until owner confirms' });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/inbox') {
      const [prospects, messages, replies] = await Promise.all([
        store.list('prospects'), store.list('messages'), store.list('replies')
      ]);
      return json(res, 200, buildInboxThreads({ prospects, messages, replies }));
    }
    if (method === 'GET' && url.pathname === '/api/outreach/health') {
      const [accounts, senderHealth, outboundEvents, outboundReservations, prospects] = await Promise.all([
        store.list('accounts'), store.list('senderHealth'), store.list('outboundEvents'),
        store.list('outboundReservations'), store.list('prospects')
      ]);
      const settings = await store.getSettings();
      return json(res, 200, {
        ...buildDeliverabilitySnapshot({ accounts, senderHealth, outboundEvents, outboundReservations, prospects }),
        globalPaused: settings.outboundPaused === true,
        pauseReason: settings.outboundPauseReason || '',
        allowedCountries: normalizeCountryList(config.outbound.allowedCountries)
      });
    }
    if (method === 'POST' && url.pathname === '/api/outreach/reconcile') {
      const input = await parseBody(req);
      const reservationId = String(input.reservationId || '').trim();
      if (!reservationId) throw new HttpError(400, 'reservationId is required');
      const result = await pipeline.reconcileOutboundReservation(reservationId);
      return json(res, result.ok || result.reconciled ? 200 : 409, { ...result, providerCalls: result.reason === 'provider-effect-adapter-disabled' ? 0 : 1, externalEffects: 0 });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/suppressions') {
      return json(res, 200, (await store.list('suppressions')).reverse());
    }
    if (method === 'GET' && url.pathname === '/api/outreach/activity') {
      const [auditLog, outboundEvents] = await Promise.all([store.list('auditLog'), store.list('outboundEvents')]);
      const activity = [
        ...auditLog.map(item => ({ ...item, activityType: 'audit' })),
        ...outboundEvents.map(item => ({ ...item, activityType: 'outbound-event', type: item.eventType }))
      ].sort((a, b) => String(b.createdAt || b.occurredAt || '').localeCompare(String(a.createdAt || a.occurredAt || '')));
      return json(res, 200, activity.slice(0, 200));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/sequence/preview') {
      const input = await parseBody(req);
      const campaign = input.campaignId ? await store.get('campaigns', String(input.campaignId)) : (input.campaign || {});
      const prospect = input.prospectId ? await store.get('prospects', String(input.prospectId)) : (input.prospect || {});
      if (input.prospectId && !prospect) throw new HttpError(404, 'Prospect not found');
      try {
        const sequence = normalizeSequence(input.sequence || campaign?.sequence, { campaign: campaign || {} });
        return json(res, 200, previewSequence({ sequence, prospect: prospect || {}, campaign: campaign || {}, sender: config.sender, startAt: input.startAt || new Date() }));
      } catch (error) {
        throw new HttpError(400, error.message);
      }
    }
    if (method === 'POST' && url.pathname === '/api/outreach/dry-run') {
      const input = await parseBody(req);
      const campaign = await store.get('campaigns', String(input.campaignId || ''));
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const allProspects = await store.list('prospects');
      const selected = boundedIds(input.prospectIds).length
        ? (await validProspectIds(input)).prospects
        : allProspects.filter(item => item.campaignId === campaign.id);
      const suppressions = await store.list('suppressions');
      const rows = buildSequencePlan({ campaign, prospects: selected, suppressions, now: input.startAt || new Date(), sender: config.sender });
      return json(res, 200, {
        mode: 'dry-run', externalEffects: 0, providerCalls: 0, campaignId: campaign.id,
        generatedAt: now(), counts: {
          total: rows.length, eligible: rows.filter(item => item.eligible).length,
          blocked: rows.filter(item => !item.eligible).length, plannedSteps: rows.reduce((sum, item) => sum + item.steps.length, 0)
        }, rows
      });
    }
    if (method === 'POST' && url.pathname === '/api/outreach/enroll') {
      const input = await parseBody(req);
      if (String(input.mode || 'plan') === 'live') throw new HttpError(400, 'Live enrollment is not available from the workbench; use the exact V9 approval path');
      const campaign = await store.get('campaigns', String(input.campaignId || ''));
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      const { prospects, missing } = await validProspectIds(input);
      if (!prospects.length) throw new HttpError(400, 'At least one prospectId is required');
      const state = [];
      for (const prospect of prospects) {
        if (prospect.sequenceState?.status === 'active' && input.force !== true) {
          state.push({ prospectId: prospect.id, status: 'skipped', reason: 'already-enrolled' });
          continue;
        }
        const sequenceState = enrollProspect({ prospect, campaign, now: new Date(input.startAt || Date.now()), sender: config.sender });
        await store.patch('prospects', prospect.id, { sequenceState, outreachMode: 'owner-plan', lastWorkbenchAction: 'sequence-enrolled' });
        state.push({ prospectId: prospect.id, status: 'enrolled', nextStepAt: sequenceState.nextStepAt });
      }
      await store.log('outreach_sequence_enrolled', { campaignId: campaign.id, prospectIds: state.filter(item => item.status === 'enrolled').map(item => item.prospectId), mode: 'owner-plan' });
      return json(res, 200, { mode: 'owner-plan', externalEffects: 0, state, missing });
    }
    if (method === 'POST' && url.pathname === '/api/outreach/sequence/advance') {
      const input = await parseBody(req);
      const requestedIds = boundedIds(input.prospectIds);
      const allProspects = await store.list('prospects');
      const selected = requestedIds.length
        ? (await validProspectIds(input)).prospects
        : allProspects.filter(item => item.sequenceState?.status === 'active' && (!input.campaignId || item.sequenceState?.campaignId === input.campaignId || item.campaignId === input.campaignId));
      const [campaigns, suppressions] = await Promise.all([store.list('campaigns'), store.list('suppressions')]);
      const campaignById = new Map(campaigns.map(item => [item.id, item]));
      const results = [];
      for (const prospect of selected) {
        const campaignId = String(input.campaignId || prospect.sequenceState?.campaignId || prospect.campaignId || '');
        const campaign = campaignById.get(campaignId);
        if (!campaign) {
          results.push({ prospectId: prospect.id, action: 'blocked', reason: 'campaign-missing' });
          continue;
        }
        if (!prospect.sequenceState || !['active', 'ready_for_review'].includes(prospect.sequenceState.status)) {
          results.push({ prospectId: prospect.id, action: 'skipped', reason: 'sequence-not-active' });
          continue;
        }
        let advanced;
        try {
          advanced = advanceSequence({
            state: prospect.sequenceState,
            sequence: campaign.sequence,
            prospect,
            campaign,
            suppressions,
            now: input.now || new Date(),
            sender: config.sender
          });
        } catch (error) {
          results.push({ prospectId: prospect.id, action: 'blocked', reason: error.message });
          continue;
        }
        const patch = {
          sequenceState: advanced.state,
          lastWorkbenchAction: `sequence-${advanced.action}`,
          ...(advanced.action === 'stopped' ? { nextFollowupAt: null } : {})
        };
        if (advanced.reason === 'suppressed') patch.status = 'suppressed';
        await store.patch('prospects', prospect.id, patch);
        results.push({ prospectId: prospect.id, action: advanced.action, reason: advanced.reason, step: advanced.step ? { stepId: advanced.step.id, scheduledAt: advanced.step.scheduledAt, variantId: advanced.step.selectedVariantId } : null });
      }
      await store.log('outreach_sequence_advanced', { prospectIds: results.map(item => item.prospectId), resultCount: results.length, externalEffects: 0 });
      return json(res, 200, {
        mode: 'owner-plan', externalEffects: 0, providerCalls: 0,
        counts: {
          total: results.length,
          readyForReview: results.filter(item => item.action === 'ready_for_review').length,
          waiting: results.filter(item => ['waiting', 'waiting_condition', 'manual_review'].includes(item.action)).length,
          stopped: results.filter(item => item.action === 'stopped').length,
          blocked: results.filter(item => item.action === 'blocked').length
        }, results
      });
    }
    if (method === 'POST' && /^\/api\/outreach\/inbox\/[^/]+\/read$/.test(url.pathname)) {
      const prospectId = decodeURIComponent(url.pathname.split('/')[4]);
      const replies = (await store.list('replies')).filter(item => item.prospectId === prospectId && !item.readAt);
      for (const reply of replies) await store.patch('replies', reply.id, { readAt: now() });
      await store.log('outreach_thread_read', { prospectId, replyCount: replies.length });
      return json(res, 200, { prospectId, markedRead: replies.length });
    }
    if (method === 'POST' && /^\/api\/outreach\/inbox\/[^/]+\/action$/.test(url.pathname)) {
      const prospectId = decodeURIComponent(url.pathname.split('/')[4]);
      const prospect = await store.get('prospects', prospectId);
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const input = await parseBody(req);
      let action;
      try {
        action = buildInboxActionPatch({ prospect, action: input.action, snoozedUntil: input.snoozedUntil, now: new Date() });
      } catch (error) { throw new HttpError(400, error.message); }
      const updated = await store.patch('prospects', prospectId, action.patch);
      const replies = (await store.list('replies')).filter(item => item.prospectId === prospectId).sort((a, b) => String(b.receivedAt || b.createdAt || '').localeCompare(String(a.receivedAt || a.createdAt || '')));
      if (action.patch.replyLabel && replies[0]) {
        await store.patch('replies', replies[0].id, {
          label: action.patch.replyLabel,
          classification: { ...(replies[0].classification || {}), label: action.patch.replyLabel, source: 'owner', confidence: 1 },
          classifiedAt: now()
        });
      }
      await store.log('outreach_inbox_action', {
        prospectId, action: action.action, outcome: action.outcome, snoozedUntil: action.patch.inboxSnoozedUntil || '', externalEffects: 0, providerCalls: 0
      });
      return json(res, 200, { ...action, prospect: updated, externalEffects: 0, providerCalls: 0 });
    }
    if (method === 'POST' && /^\/api\/outreach\/inbox\/[^/]+\/reply-draft$/.test(url.pathname)) {
      const prospectId = decodeURIComponent(url.pathname.split('/')[4]);
      const prospect = await store.get('prospects', prospectId);
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const input = await parseBody(req);
      const replies = (await store.list('replies')).filter(item => item.prospectId === prospectId).sort((a, b) => String(b.receivedAt || b.createdAt || '').localeCompare(String(a.receivedAt || a.createdAt || '')));
      const reply = input.replyId ? replies.find(item => item.id === input.replyId) : replies[0];
      const draft = buildOwnerReplyDraft({ prospect, reply: reply || { subject: input.subject || '', label: input.label || prospect.replyLabel }, sender: config.sender, offer: input.offer || '' });
      const record = { id: id('replydraft'), prospectId, threadId: reply?.threadId || prospect.threadId || '', status: 'draft', replyId: reply?.id || '', ...draft, createdAt: now(), updatedAt: now() };
      await store.add('replyDrafts', record);
      await store.log('outreach_reply_draft_created', { prospectId, replyId: reply?.id || '', draftId: record.id, safeToSend: false });
      return json(res, 201, { ...record, externalEffects: 0, policy: 'draft-only; owner must review and use the exact governed send path' });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/reply-drafts') {
      return json(res, 200, (await store.list('replyDrafts')).reverse());
    }
    if (method === 'PATCH' && /^\/api\/outreach\/reply-drafts\/[^/]+$/.test(url.pathname)) {
      const draftId = decodeURIComponent(url.pathname.split('/')[4]);
      const current = await store.get('replyDrafts', draftId);
      if (!current) throw new HttpError(404, 'Reply draft not found');
      const input = await parseBody(req);
      const status = ['draft', 'owner-reviewed', 'discarded'].includes(String(input.status || '')) ? String(input.status) : current.status;
      const patch = { status, updatedAt: now() };
      if (input.subject !== undefined) patch.subject = String(input.subject || '').slice(0, 200);
      if (input.body !== undefined) patch.body = String(input.body || '').slice(0, 12000);
      const updated = await store.patch('replyDrafts', draftId, patch);
      await store.log('outreach_reply_draft_updated', { draftId, status });
      return json(res, 200, { ...updated, externalEffects: 0 });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/lead-lists') {
      const lists = await store.list('leadLists');
      const prospects = await store.list('prospects');
      const byId = new Map(prospects.map(item => [item.id, item]));
      return json(res, 200, lists.reverse().map(list => ({ ...list, memberCount: boundedIds(list.prospectIds).length, members: boundedIds(list.prospectIds).map(prospectId => byId.get(prospectId)).filter(Boolean).map(item => ({ id: item.id, company: item.company, domain: item.domain, email: item.contact?.email || '' })) })));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/lead-lists') {
      const input = await parseBody(req);
      const name = String(input.name || '').trim().slice(0, 180);
      if (!name) throw new HttpError(400, 'List name is required');
      const { ids, missing } = await validProspectIds(input);
      const record = { id: id('list'), name, prospectIds: ids, description: String(input.description || '').slice(0, 500), createdAt: now(), updatedAt: now() };
      await store.add('leadLists', record);
      await store.log('outreach_lead_list_created', { listId: record.id, memberCount: ids.length });
      return json(res, 201, { ...record, missing });
    }
    if (method === 'PATCH' && /^\/api\/outreach\/lead-lists\/[^/]+$/.test(url.pathname)) {
      const listId = decodeURIComponent(url.pathname.split('/')[4]);
      const current = await store.get('leadLists', listId);
      if (!current) throw new HttpError(404, 'Lead list not found');
      const input = await parseBody(req);
      const validated = input.prospectIds !== undefined ? await validProspectIds(input) : { ids: boundedIds(current.prospectIds), missing: [] };
      const nextIds = validated.ids;
      const updated = await store.patch('leadLists', listId, { name: String(input.name ?? current.name).slice(0, 180), description: String(input.description ?? current.description ?? '').slice(0, 500), prospectIds: nextIds, updatedAt: now() });
      return json(res, 200, { ...updated, missing: validated.missing });
    }
    if (method === 'GET' && url.pathname === '/api/outreach/automations') {
      const [plans, runs] = await Promise.all([store.list('automationPlans'), store.list('automationRuns')]);
      return json(res, 200, plans.reverse().map(plan => ({
        ...plan,
        runs: runs.filter(run => run.planId === plan.id).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 10),
        runCount: runs.filter(run => run.planId === plan.id).length
      })));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/automations') {
      const input = await parseBody(req);
      let plan;
      try { plan = normalizeAutomationPlan(input, { id: id('automation'), now: new Date() }); }
      catch (error) { throw new HttpError(400, error.message); }
      await store.add('automationPlans', plan);
      await store.log('outreach_automation_created', { planId: plan.id, trigger: plan.trigger, enabled: plan.enabled, actionCount: plan.actions.length, externalEffects: 0 });
      return json(res, 201, { ...plan, externalEffects: 0, providerCalls: 0 });
    }
    if (method === 'PATCH' && /^\/api\/outreach\/automations\/[^/]+$/.test(url.pathname)) {
      const planId = decodeURIComponent(url.pathname.split('/')[4]);
      const current = await store.get('automationPlans', planId);
      if (!current) throw new HttpError(404, 'Automation not found');
      const input = await parseBody(req);
      let plan;
      try { plan = normalizeAutomationPlan({ ...current, ...input }, { id: planId, now: new Date() }); }
      catch (error) { throw new HttpError(400, error.message); }
      const updated = await store.patch('automationPlans', planId, plan);
      await store.log('outreach_automation_updated', { planId, enabled: updated.enabled, trigger: updated.trigger, externalEffects: 0 });
      return json(res, 200, { ...updated, externalEffects: 0, providerCalls: 0 });
    }
    if (method === 'GET' && /^\/api\/outreach\/automations\/[^/]+\/runs$/.test(url.pathname)) {
      const planId = decodeURIComponent(url.pathname.split('/')[4]);
      if (!await store.get('automationPlans', planId)) throw new HttpError(404, 'Automation not found');
      return json(res, 200, (await store.list('automationRuns')).filter(run => run.planId === planId).reverse());
    }
    if (method === 'POST' && /^\/api\/outreach\/automations\/[^/]+\/test$/.test(url.pathname)) {
      const planId = decodeURIComponent(url.pathname.split('/')[4]);
      const plan = await store.get('automationPlans', planId);
      if (!plan) throw new HttpError(404, 'Automation not found');
      const input = await parseBody(req);
      const event = input.event && typeof input.event === 'object' ? input.event : { eventType: input.event || 'manual' };
      const prospect = input.prospectId ? await store.get('prospects', String(input.prospectId)) : {};
      const campaign = input.campaignId ? await store.get('campaigns', String(input.campaignId)) : prospect?.campaignId ? await store.get('campaigns', prospect.campaignId) : {};
      return json(res, 200, { ...evaluateAutomationPlan({ plan, event, prospect: prospect || {}, campaign: campaign || {}, now: new Date() }), mutation: 'none', policy: 'test only; no automation run was persisted and no provider call was made' });
    }
    if (method === 'POST' && /^\/api\/outreach\/automation\/preview$/.test(url.pathname)) {
      const input = await parseBody(req);
      const event = String(input.event || '').trim().toLowerCase();
      const prospect = input.prospectId ? await store.get('prospects', String(input.prospectId)) : null;
      const campaign = input.campaignId ? await store.get('campaigns', String(input.campaignId)) : prospect?.campaignId ? await store.get('campaigns', prospect.campaignId) : null;
      const actions = {
        lead_replied: ['stop_sequence', 'create_owner_reply_draft', 'route_to_unibox'],
        lead_positive: ['stop_sequence', 'create_opportunity', 'create_owner_reply_draft'],
        lead_unsubscribed: ['global_suppress_email', 'stop_sequence'],
        email_bounced: ['global_suppress_email', 'pause_sender_for_review', 'stop_sequence'],
        email_complaint: ['global_suppress_email', 'pause_sender_for_review', 'global_pause_review'],
        payment_cleared: ['stop_sequence', 'mark_revenue_continuity'],
        campaign_completed: ['create_owner_review'],
        enrichment_completed: ['recalculate_evidence_readiness']
      }[event] || [];
      const safeActions = actions.filter(action => action !== 'global_pause_review' || input.allowGlobalPause === true);
      return json(res, 200, {
        event, campaignId: campaign?.id || input.campaignId || '', prospectId: prospect?.id || input.prospectId || '',
        actions: safeActions, blockedActions: actions.filter(action => !safeActions.includes(action)),
        externalEffects: 0, mutation: 'none', policy: 'preview only; every mutation remains owner-controlled and audited'
      });
    }
    if (method === 'POST' && url.pathname === '/api/outreach/events') {
      const input = await parseBody(req);
      const rawEventType = String(input.eventType || input.type || '').trim().toLowerCase();
      const eventType = OUTREACH_EVENT_ALIASES.get(rawEventType) || rawEventType;
      if (!eventType) throw new HttpError(400, 'Unsupported outreach event type');
      let event;
      try {
        event = normalizeProviderEvent({
          ...input,
          eventType,
          event_type: eventType,
          prospectId: input.prospectId,
          messageId: input.messageId || input.gmailId,
          leadEmail: input.recipientEmail || input.leadEmail,
          reply_text: input.replyText || input.body
        }, { provider: input.provider || config.outbound.provider, rawBody: JSON.stringify(input), receivedAt: new Date() });
      } catch (error) { throw new HttpError(400, error.message); }
      return json(res, 202, await applyOutreachProviderEvent(event, { source: 'owner-authenticated-event-ingestion' }));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/placement/plan') {
      const input = await parseBody(req);
      const campaign = input.campaignId ? await store.get('campaigns', String(input.campaignId)) : null;
      if (input.campaignId && !campaign) throw new HttpError(404, 'Campaign not found');
      const [accounts, senderHealth] = await Promise.all([store.list('accounts'), store.list('senderHealth')]);
      const requestedSlots = Array.isArray(input.inboxes) ? input.inboxes.map(item => String(item || '').trim()).filter(Boolean) : [];
      const slots = requestedSlots.length ? requestedSlots : accounts.map(item => item.slot).filter(Boolean);
      const tests = [...new Set(slots)].map(slot => {
        const account = accounts.find(item => item.slot === slot) || {};
        const health = senderHealth.find(item => item.inbox === slot) || {};
        return {
          slot,
          email: account.email || '',
          connected: Boolean(account.connected),
          paused: Boolean(health.paused),
          checks: [
            { name: 'sender-authentication', status: account.connected ? 'observed' : 'blocked', detail: account.connected ? 'Connected account observed locally' : 'Connect the sender before any provider test' },
            { name: 'sender-health', status: health.paused ? 'blocked' : 'observed', detail: health.paused ? health.pauseReason || 'Sender is paused' : 'No local pause signal observed' },
            { name: 'inbox-promotions-spam-placement', status: 'not-run', detail: 'Provider-specific placement test is not configured; no external call was made' },
            { name: 'spf-dkim-dmarc', status: 'not-run', detail: 'DNS verification is not configured; do not infer placement from local health' }
          ]
        };
      });
      return json(res, 200, {
        mode: 'owner-plan', campaignId: campaign?.id || '', generatedAt: now(), tests,
        providerCalls: 0, externalEffects: 0,
        policy: 'transparent local plan; provider placement and DNS checks require a separately configured adapter'
      });
    }
    if (method === 'PATCH' && /^\/api\/outreach\/campaigns\/[^/]+$/.test(url.pathname)) {
      const campaignId = url.pathname.split('/').pop();
      const current = await store.get('campaigns', campaignId);
      if (!current) throw new HttpError(404, 'Campaign not found');
      const input = await parseBody(req);
      const candidate = { ...current, ...input };
      let sequence;
      try { sequence = normalizeSequence(input.sequence || current.sequence, { campaign: candidate }); }
      catch (error) { throw new HttpError(400, error.message); }
      const patch = {
        name: String(input.name ?? current.name).slice(0, 180),
        niche: String(input.niche ?? current.niche ?? '').slice(0, 240),
        offer: String(input.offer ?? current.offer ?? '').slice(0, 500),
        description: String(input.description ?? current.description ?? '').slice(0, 1000),
        customVariables: input.customVariables && typeof input.customVariables === 'object' ? Object.fromEntries(Object.entries(input.customVariables).slice(0, 80).map(([key, value]) => [String(key).slice(0, 80), String(value ?? '').slice(0, 2000)])) : (current.customVariables || {}),
        allowedCountries: normalizeCountryList(input.allowedCountries ?? current.allowedCountries ?? []),
        minScore: Math.max(50, Math.min(95, Number(input.minScore ?? current.minScore ?? 60))),
        sequence: { ...sequence, version: Math.max(Number(current.sequence?.version || 0) + (input.sequence ? 1 : 0), Number(sequence.version || 1)) },
        sequenceVersion: Math.max(Number(current.sequenceVersion || 0) + (input.sequence ? 1 : 0), Number(sequence.version || 1)),
        updatedAt: now()
      };
      if (input.approved !== undefined) patch.approved = parseStrictBoolean(input.approved, 'approved', current.approved);
      if (input.autoSend !== undefined) patch.autoSend = parseStrictBoolean(input.autoSend, 'autoSend', current.autoSend);
      if (input.maxFollowups !== undefined) patch.maxFollowups = Math.min(11, Math.max(0, Number(input.maxFollowups)));
      if (input.paused !== undefined) patch.paused = input.paused === true;
      if (input.status !== undefined && ['draft', 'active', 'paused', 'completed'].includes(String(input.status))) patch.status = String(input.status);
      const sequenceChanged = input.sequence !== undefined && JSON.stringify(input.sequence) !== JSON.stringify(current.sequence);
      const offerChanged = input.offer !== undefined && String(input.offer ?? '') !== String(current.offer ?? '');
      const customVariablesChanged = input.customVariables !== undefined && JSON.stringify(input.customVariables || {}) !== JSON.stringify(current.customVariables || {});
      if (sequenceChanged || offerChanged || customVariablesChanged) {
        patch.approved = false;
        patch.autoSend = false;
        patch.paused = true;
        patch.status = 'draft';
      }
      const updated = await store.patch('campaigns', campaignId, patch);
      return json(res, 200, updated);
    }
    if (method === 'POST' && url.pathname === '/api/outreach/bulk') {
      const input = await parseBody(req);
      const action = String(input.action || '').trim().toLowerCase();
      const { prospects, missing } = await validProspectIds(input);
      if (!prospects.length) throw new HttpError(400, 'At least one prospectId is required');
      if (!['tag', 'suppress', 'pause', 'stop', 'stage', 'queue-research'].includes(action)) throw new HttpError(400, 'Unsupported bulk action');
      const results = [];
      if (action === 'suppress') {
        const seen = new Set();
        for (const prospect of prospects) {
          const value = String(input.scope || 'email') === 'domain'
            ? normalizeDomain(prospect.website || prospect.domain || '')
            : String(prospect.contact?.email || '').trim().toLowerCase();
          if (!value || seen.has(value)) continue;
          seen.add(value);
          try { await store.add('suppressions', { id: id('sup'), value, reason: String(input.reason || 'owner-bulk-suppression').slice(0, 240), createdAt: now() }); }
          catch (error) { if (!(error instanceof ConflictError)) throw error; }
        }
        for (const prospect of prospects) {
          await store.patch('prospects', prospect.id, { status: 'suppressed', nextFollowupAt: null, sequenceState: { ...(prospect.sequenceState || {}), status: 'stopped', stoppedReason: 'suppressed' } });
          results.push({ prospectId: prospect.id, status: 'suppressed' });
        }
      } else if (action === 'tag') {
        const tags = sanitizeTags(input.tags || [input.tag]);
        if (!tags.length) throw new HttpError(400, 'At least one valid tag is required');
        for (const prospect of prospects) {
          const merged = sanitizeTags([...(prospect.tags || []), ...tags]);
          await store.patch('prospects', prospect.id, { tags: merged });
          results.push({ prospectId: prospect.id, status: 'tagged', tags: merged });
        }
      } else if (action === 'pause' || action === 'stop') {
        for (const prospect of prospects) {
          const next = { ...(prospect.sequenceState || {}), status: action === 'pause' ? 'paused' : 'stopped', stoppedReason: action === 'stop' ? String(input.reason || 'owner-stopped') : '' };
          await store.patch('prospects', prospect.id, { sequenceState: next, nextFollowupAt: null });
          results.push({ prospectId: prospect.id, status: next.status });
        }
      } else if (action === 'stage') {
        const stage = normalizeOpportunityStage(input.stage);
        for (const prospect of prospects) {
          await store.patch('prospects', prospect.id, { opportunityStage: stage, nextAction: String(input.nextAction || '').slice(0, 500) });
          results.push({ prospectId: prospect.id, status: 'stage-updated', stage });
        }
      } else if (action === 'queue-research') {
        for (const prospect of prospects) {
          await store.patch('prospects', prospect.id, { status: 'queued', error: '' });
          results.push({ prospectId: prospect.id, status: 'queued' });
        }
        await enqueueResearch({ limit: Math.min(config.maxBatch, prospects.length), reason: 'outreach-bulk-research' });
      }
      await store.log('outreach_bulk_action', { action, prospectIds: prospects.map(item => item.id), resultCount: results.length });
      return json(res, 200, { action, results, missing });
    }
    if (method === 'POST' && url.pathname === '/api/outreach/suppressions') {
      const input = await parseBody(req);
      const value = String(input.value || '').trim().toLowerCase();
      if (!value || value.length > 320) throw new HttpError(400, 'A valid email or domain is required');
      const suppression = { id: id('sup'), value, reason: String(input.reason || 'owner-manual-suppression').slice(0, 240), createdAt: now() };
      await store.add('suppressions', suppression);
      return json(res, 201, suppression);
    }
    if (method === 'POST' && /^\/api\/outreach\/prospects\/[^/]+\/state$/.test(url.pathname)) {
      const prospectId = url.pathname.split('/')[4];
      const prospect = await store.get('prospects', prospectId);
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const input = await parseBody(req);
      const patch = {};
      if (input.stage !== undefined) patch.opportunityStage = normalizeOpportunityStage(input.stage);
      if (input.nextAction !== undefined) patch.nextAction = String(input.nextAction || '').slice(0, 500);
      if (input.nextActionAt !== undefined) patch.nextActionAt = input.nextActionAt ? new Date(input.nextActionAt).toISOString() : null;
      if (input.ownerNote !== undefined) patch.ownerNote = String(input.ownerNote || '').slice(0, 2000);
      if (input.tags !== undefined) patch.tags = sanitizeTags(input.tags);
      const updated = await store.patch('prospects', prospectId, patch);
      await store.log('outreach_prospect_state_updated', { prospectId, stage: patch.opportunityStage || prospect.opportunityStage || 'new' });
      return json(res, 200, updated);
    }
    const listRoutes = new Map([
      ['/api/prospects', 'prospects'], ['/api/leads', 'leads'], ['/api/orders', 'orders'],
      ['/api/subscriptions', 'subscriptions'], ['/api/monitoring-runs', 'monitoringRuns'],
      ['/api/notifications', 'notifications'], ['/api/replies', 'replies'], ['/api/social-tasks', 'socialTasks'],
      ['/api/campaigns', 'campaigns'], ['/api/discovery-runs', 'discoveryRuns'], ['/api/jobs', 'jobs'],
      ['/api/outbound-reservations', 'outboundReservations'], ['/api/outbound-events', 'outboundEvents'], ['/api/sender-health', 'senderHealth']
    ]);
    if (method === 'GET' && listRoutes.has(url.pathname)) {
      return json(res, 200, (await store.list(listRoutes.get(url.pathname))).reverse());
    }
    if (method === 'GET' && url.pathname.startsWith('/api/prospects/')) {
      const prospect = await store.get('prospects', url.pathname.split('/').pop());
      return prospect ? json(res, 200, prospect) : json(res, 404, { error: 'Prospect not found' });
    }
    if (method === 'GET' && url.pathname === '/api/discovery/config') {
      return json(res, 200, {
        enabled: config.discovery.enabled, dryRun: config.discovery.dryRun, dailyCap: config.discovery.dailyCap,
        bbox: config.discovery.bbox, categories: config.discovery.categories, country: config.discovery.country,
        city: config.discovery.city, supportedCategories: Object.keys(DISCOVERY_CATEGORIES)
      });
    }

    if (method === 'POST' && url.pathname === '/api/outbound/pause') {
      const input = await parseBody(req);
      return json(res, 200, await store.setOutboundPaused(true, input.reason || 'Paused from command center'));
    }
    if (method === 'POST' && url.pathname === '/api/outbound/resume') {
      return json(res, 200, await store.setOutboundPaused(false, ''));
    }
    if (method === 'POST' && url.pathname === '/api/outreach/sequence/approve-step') {
      const input = await parseBody(req);
      const prospect = await store.get('prospects', String(input.prospectId || ''));
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const campaign = await store.get('campaigns', String(input.campaignId || prospect.sequenceState?.campaignId || prospect.campaignId || ''));
      if (!campaign) throw new HttpError(404, 'Campaign not found');
      if (String(prospect.campaignId || '') !== String(campaign.id || '')) throw new HttpError(400, 'Prospect and campaign are not bound together');
      if (!campaign.approved || !campaign.autoSend) throw new HttpError(400, 'Campaign must be approved and autoSend-enabled before exact step approval');
      if (campaign.paused) throw new HttpError(400, 'Campaign is paused');
      const stepIndex = Number(input.stepIndex);
      if (!Number.isInteger(stepIndex) || stepIndex < 0 || stepIndex > 11) throw new HttpError(400, 'stepIndex must be an integer from 0 through 11');
      const state = prospect.sequenceState;
      if (!state || !['ready_for_review', 'approved'].includes(state.status)) throw new HttpError(400, 'The sequence step must first be advanced to ready_for_review');
      if (Number(state.currentStepIndex || 0) !== stepIndex) throw new HttpError(400, 'Only the current sequence step can be approved');
      if (state.status === 'approved' && state.approvedApprovalId) {
        const existing = stepIndex === 0 ? prospect.outreachApproval : prospect.followupApprovals?.[String(stepIndex)];
        if (existing?.approvalId === state.approvedApprovalId) {
          return json(res, 200, { approved: true, idempotent: true, prospectId: prospect.id, stepIndex, approvalId: existing.approvalId, approvalDigest: existing.approvalDigest, routeDigest: existing.routeDigest, messageDigest: existing.messageDigest, effectPayloadDigest: existing.effectPayloadDigest, expiresAt: existing.expiresAt, externalEffects: 0 });
        }
      }
      let normalized;
      try { normalized = normalizeSequence(campaign.sequence, { campaign }); }
      catch (error) { throw new HttpError(400, error.message); }
      if (Number(state.sequenceVersion || 0) !== Number(normalized.version || 1)) throw new HttpError(409, 'Sequence content changed; re-enroll and advance this prospect before approval');
      const preview = previewSequence({ sequence: normalized, prospect, campaign, sender: config.sender, startAt: state.enrolledAt || now() });
      const planned = preview.steps[stepIndex];
      if (!planned?.selected) throw new HttpError(400, 'The selected sequence step has no usable variant');
      const selectedVariantId = String(input.variantId || state.selectedVariants?.[planned.id] || planned.selectedVariantId);
      const selected = planned.variants.find(variant => variant.id === selectedVariantId) || planned.selected;
      if (!selected?.subject || !selected?.body) throw new HttpError(400, 'The selected sequence variant is incomplete');
      if (planned.missingTags?.length) throw new HttpError(400, `Missing merge data: ${planned.missingTags.join(', ')}`);
      const subject = String(input.subject ?? selected.subject);
      const body = String(input.body ?? selected.body);
      if (subject !== selected.subject || body !== selected.body) throw new HttpError(400, 'Exact step approval must match the rendered sequence variant; edit the campaign and preview again');
      const recipientEmail = String(prospect.contact?.email || '').trim().toLowerCase();
      if (!recipientEmail) throw new HttpError(400, 'Prospect has no resolved recipient');
      const account = await store.findOne('accounts', { slot: prospect.inbox });
      if (!account?.connected || !account.email) throw new HttpError(400, 'The selected Gmail sender account must be connected before approval');
      const approvedAt = now();
      const approvalExpiresAt = String(input.expiresAt || new Date(Date.parse(approvedAt) + 24 * 3600000).toISOString());
      let route;
      try {
        route = createOutreachRouteEvidence({ ...(input.routeEvidence || {}), recipientEmail, provider: config.outbound.provider }, new Date(approvedAt));
      } catch (error) {
        throw new HttpError(400, error.message);
      }
      const effectPayload = {
        from: `${config.sender.name} <${account.email}>`,
        to: recipientEmail,
        subject,
        body,
        threadId: stepIndex ? prospect.threadId : undefined,
        replyToId: stepIndex ? prospect.rfcMessageId : undefined,
        listUnsubscribe: prospect.oneClickUnsubscribeUrl
      };
      const messageDigest = outreachMessageDigest({
        recipientEmail, subject, body, provider: config.outbound.provider, inbox: prospect.inbox,
        followup: stepIndex, threadId: stepIndex ? prospect.threadId : '', replyToId: stepIndex ? prospect.rfcMessageId : '',
        listUnsubscribe: prospect.oneClickUnsubscribeUrl
      });
      let approval;
      try {
        approval = createOutreachApproval({
          approvalId: input.approvalId,
          prospectId: prospect.id,
          campaignId: campaign.id,
          recipientEmail,
          provider: config.outbound.provider,
          inbox: prospect.inbox,
          followup: stepIndex,
          routeDigest: route.routeDigest,
          messageDigest,
          effectPayloadDigest: digestOutboundEffectPayload(effectPayload),
          approvedBy: config.outbound.approverId,
          approvedAt,
          expiresAt: approvalExpiresAt
        }, config.outbound.approvalSecret);
      } catch (error) {
        throw new HttpError(400, error.message);
      }
      const candidate = stepIndex === 0
        ? { ...prospect, subject, draft: body, outreachRoute: route, outreachApproval: approval }
        : { ...prospect, outreachRoute: route, followupApprovals: { ...(prospect.followupApprovals || {}), [String(stepIndex)]: approval } };
      const governance = evaluateOutreachGovernance({ prospect: candidate, campaign, cfg: config, subject, body, followup: stepIndex, date: new Date(approvedAt) });
      if (!governance.ok) throw new HttpError(400, `Approval refused: ${governance.reason}`);
      const nextState = {
        ...state,
        status: 'approved',
        approvedStepIndex: stepIndex,
        approvedVariantId: selected.id,
        approvedSubject: subject,
        approvedBody: body,
        approvedApprovalId: approval.approvalId,
        approvedAt,
        approvedMessageDigest: messageDigest,
        stepStates: (state.stepStates || []).map(step => step.stepId === planned.id ? { ...step, status: 'approved', approvalId: approval.approvalId, approvedAt, selectedVariantId: selected.id } : step)
      };
      const patch = {
        sequenceState: nextState,
        outreachRoute: route,
        outreachApprovedAt: approvedAt,
        ...(stepIndex === 0 ? { subject, draft: body, outreachApproval: approval, status: 'ready' } : { followupApprovals: { ...(prospect.followupApprovals || {}), [String(stepIndex)]: approval } })
      };
      await store.patch('prospects', prospect.id, patch);
      await store.log('outreach_sequence_step_approved', {
        prospectId: prospect.id, campaignId: campaign.id, stepIndex, stepId: planned.id, variantId: selected.id,
        approvalId: approval.approvalId, approvalDigest: approval.approvalDigest, routeDigest: route.routeDigest,
        messageDigest, effectPayloadDigest: approval.effectPayloadDigest, approvedAt, expiresAt: approval.expiresAt
      });
      return json(res, 201, {
        approved: true, externalEffects: 0, prospectId: prospect.id, stepIndex, stepId: planned.id, variantId: selected.id,
        approvalId: approval.approvalId, approvalDigest: approval.approvalDigest, routeDigest: route.routeDigest,
        messageDigest, effectPayloadDigest: approval.effectPayloadDigest, expiresAt: approval.expiresAt
      });
    }
    if (method === 'POST' && url.pathname === '/api/outbound/approve-prospect') {
      const input = await parseBody(req);
      const prospect = await store.get('prospects', String(input.prospectId || ''));
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const campaign = await store.get('campaigns', prospect.campaignId);
      if (!campaign?.approved || !campaign.autoSend) throw new HttpError(400, 'Campaign must be approved and autoSend-enabled before message approval');
      const followup = Number(input.followup || 0);
      if (!Number.isInteger(followup) || followup < 0 || followup > 11) throw new HttpError(400, 'followup must be an integer from 0 through 11');
      const subject = String(input.subject ?? (followup === 0 ? prospect.subject : ''));
      const body = String(input.body ?? (followup === 0 ? prospect.draft : ''));
      if (!subject.trim() || !body.trim()) throw new HttpError(400, 'The exact subject and body are required');
      const recipientEmail = String(prospect.contact?.email || '').trim().toLowerCase();
      if (!recipientEmail) throw new HttpError(400, 'Prospect has no resolved recipient');
      const account = await store.findOne('accounts', { slot: prospect.inbox });
      if (!account?.connected || !account.email) throw new HttpError(400, 'The selected Gmail sender account must be connected before approval');
      const approvedAt = now();
      const approvalExpiresAt = String(input.expiresAt || new Date(Date.parse(approvedAt) + 24 * 3600000).toISOString());
      const route = createOutreachRouteEvidence({
        ...(input.routeEvidence || {}),
        recipientEmail,
        provider: config.outbound.provider
      }, new Date(approvedAt));
      const effectPayload = {
        from: `${config.sender.name} <${account.email}>`,
        to: recipientEmail,
        subject,
        body,
        threadId: followup ? prospect.threadId : undefined,
        replyToId: followup ? prospect.rfcMessageId : undefined,
        listUnsubscribe: prospect.oneClickUnsubscribeUrl
      };
      const messageDigest = outreachMessageDigest({
        recipientEmail,
        subject,
        body,
        provider: config.outbound.provider,
        inbox: prospect.inbox,
        followup,
        threadId: followup ? prospect.threadId : '',
        replyToId: followup ? prospect.rfcMessageId : '',
        listUnsubscribe: prospect.oneClickUnsubscribeUrl
      });
      const approval = createOutreachApproval({
        approvalId: input.approvalId,
        prospectId: prospect.id,
        campaignId: campaign.id,
        recipientEmail,
        provider: config.outbound.provider,
        inbox: prospect.inbox,
        followup,
        routeDigest: route.routeDigest,
        messageDigest,
        effectPayloadDigest: digestOutboundEffectPayload(effectPayload),
        approvedBy: config.outbound.approverId,
        approvedAt,
        expiresAt: approvalExpiresAt
      }, config.outbound.approvalSecret);
      const candidate = followup === 0
        ? { ...prospect, subject, draft: body, outreachRoute: route, outreachApproval: approval }
        : { ...prospect, outreachRoute: route, followupApprovals: { ...(prospect.followupApprovals || {}), [String(followup)]: approval } };
      const governance = evaluateOutreachGovernance({ prospect: candidate, campaign, cfg: config, subject, body, followup, date: new Date(approvedAt) });
      if (!governance.ok) throw new HttpError(400, `Approval refused: ${governance.reason}`);
      const patch = followup === 0 ? {
        subject,
        draft: body,
        outreachRoute: route,
        outreachApproval: approval,
        status: 'ready',
        outreachApprovedAt: approvedAt
      } : {
        outreachRoute: route,
        followupApprovals: candidate.followupApprovals,
        outreachApprovedAt: approvedAt
      };
      await store.patch('prospects', prospect.id, patch);
      await store.log('outreach_message_approved', {
        prospectId: prospect.id,
        campaignId: campaign.id,
        followup,
        approvalId: approval.approvalId,
        approvalDigest: approval.approvalDigest,
        routeDigest: route.routeDigest,
        messageDigest,
        effectPayloadDigest: approval.effectPayloadDigest,
        approvedAt,
        expiresAt: approval.expiresAt
      });
      return json(res, 201, {
        approved: true,
        prospectId: prospect.id,
        followup,
        approvalId: approval.approvalId,
        approvalDigest: approval.approvalDigest,
        routeDigest: route.routeDigest,
        messageDigest,
        effectPayloadDigest: approval.effectPayloadDigest,
        expiresAt: approval.expiresAt
      });
    }
    if (method === 'POST' && url.pathname === '/api/outbound/revoke-prospect-approval') {
      const input = await parseBody(req);
      const prospect = await store.get('prospects', String(input.prospectId || ''));
      if (!prospect) throw new HttpError(404, 'Prospect not found');
      const followup = Number(input.followup || 0);
      if (!Number.isInteger(followup) || followup < 0 || followup > 11) throw new HttpError(400, 'followup must be an integer from 0 through 11');
      const sequenceState = prospect.sequenceState && Number(prospect.sequenceState.currentStepIndex || 0) === followup
        ? {
            ...prospect.sequenceState,
            status: 'ready_for_review',
            approvedStepIndex: null,
            approvedAt: '',
            approvedVariantId: '',
            approvedSubject: '',
            approvedBody: '',
            approvedApprovalId: '',
            approvedMessageDigest: '',
            stepStates: (prospect.sequenceState.stepStates || []).map(step => step.stepId === prospect.sequenceState.stepStates?.[followup]?.stepId ? { ...step, status: 'ready_for_review', approvalId: '' } : step)
          }
        : null;
      const patch = followup === 0
        ? { outreachApproval: null, status: sequenceState ? prospect.status : prospect.status === 'ready' ? 'research-complete' : prospect.status, nextFollowupAt: null, ...(sequenceState ? { sequenceState } : {}) }
        : { followupApprovals: { ...(prospect.followupApprovals || {}), [String(followup)]: null }, nextFollowupAt: null, ...(sequenceState ? { sequenceState } : {}) };
      await store.patch('prospects', prospect.id, patch);
      await store.log('outreach_message_approval_revoked', { prospectId: prospect.id, followup, reason: String(input.reason || 'owner-revoked').slice(0, 500), revokedAt: now() });
      return json(res, 200, { revoked: true, prospectId: prospect.id, followup });
    }
    if (method === 'POST' && /^\/api\/outbound\/sender\/[AB]\/pause$/.test(url.pathname)) {
      const slot = url.pathname.split('/')[4];
      const input = await parseBody(req);
      return json(res, 200, await store.setSenderPaused(slot, true, input.reason || 'Paused from command center'));
    }
    if (method === 'POST' && /^\/api\/outbound\/sender\/[AB]\/resume$/.test(url.pathname)) {
      const slot = url.pathname.split('/')[4];
      return json(res, 200, await store.setSenderPaused(slot, false, ''));
    }

    if (method === 'POST' && url.pathname === '/api/campaigns') {
      const input = await parseBody(req);
      const campaignSeed = { name: input.name || 'Untitled campaign', niche: input.niche || '', offer: input.offer || '', customVariables: input.customVariables || {} };
      let sequence;
      try { sequence = normalizeSequence(input.sequence, { campaign: campaignSeed }); }
      catch (error) { throw new HttpError(400, error.message); }
      const campaign = {
        id: id('camp'), name: input.name || 'Untitled campaign', niche: input.niche || '', offer: input.offer || '',
        description: String(input.description || '').slice(0, 1000),
        customVariables: input.customVariables && typeof input.customVariables === 'object' ? Object.fromEntries(Object.entries(input.customVariables).slice(0, 80).map(([key, value]) => [String(key).slice(0, 80), String(value ?? '').slice(0, 2000)])) : {},
        allowedCountries: normalizeCountryList(Array.isArray(input.allowedCountries) ? input.allowedCountries : String(input.allowedCountries || '').split(',')),
        minScore: Math.max(50, Math.min(95, Number(input.minScore || 60))),
        dailyCaps: {
          A: Math.min(config.caps.A, Number(input.dailyCapA || config.caps.A)),
          B: Math.min(config.caps.B, Number(input.dailyCapB || config.caps.B))
        },
        maxFollowups: Math.min(11, Math.max(0, Number(input.maxFollowups ?? 0))),
        autoSend: parseStrictBoolean(input.autoSend, 'autoSend', false),
        approved: parseStrictBoolean(input.approved, 'approved', false),
        paused: true,
        status: 'draft',
        sequence,
        sequenceVersion: sequence.version,
        createdAt: now()
      };
      await store.add('campaigns', campaign);
      return json(res, 201, campaign);
    }
    if (method === 'POST' && url.pathname === '/api/prospects/import') {
      const input = await parseBody(req);
      if (!Array.isArray(input.prospects)) throw new HttpError(400, 'prospects array required');
      const result = await importProspects(store, config, input.prospects, input.campaignId);
      if (result.added.length) await enqueueResearch({ limit: Math.min(config.maxBatch, result.added.length), reason: 'json-import' });
      return json(res, 201, { added: result.added.length, skipped: result.skipped.length, prospects: result.added, details: result.skipped });
    }
    if (method === 'POST' && url.pathname === '/api/prospects/import-csv') {
      const rows = parseCsv(await bodyText(req));
      const result = await importProspects(store, config, rows, url.searchParams.get('campaignId') || '');
      if (result.added.length) await enqueueResearch({ limit: Math.min(config.maxBatch, result.added.length), reason: 'csv-import' });
      return json(res, 201, { rows: rows.length, added: result.added.length, skipped: result.skipped.length, details: result.skipped });
    }
    if (method === 'POST' && url.pathname === '/api/discovery/run') {
      const input = await parseBody(req);
      const campaignId = String(input.campaignId || config.discovery.campaignId || '');
      const campaign = campaignId ? await store.get('campaigns', campaignId) : null;
      if (!campaignId || !campaign) throw new HttpError(400, 'A valid discovery campaign is required');
      if (!campaign.approved) throw new HttpError(400, 'The discovery campaign must be approved');
      const bbox = String(input.bbox || config.discovery.bbox || '');
      if (!bbox) throw new HttpError(400, 'A discovery bounding box is required');
      try {
        parseBbox(bbox, config.discovery.maxBboxSpan);
        normalizeCategories(Array.isArray(input.categories) ? input.categories : (input.categories || config.discovery.categories));
      } catch (error) {
        throw new HttpError(400, error.message);
      }
      if (input.limit !== undefined && (!Number.isFinite(Number(input.limit)) || Number(input.limit) <= 0)) {
        throw new HttpError(400, 'Discovery limit must be a positive number');
      }
      const normalized = { ...input, campaignId, bbox, dryRun: parseDryRunBoolean(input.dryRun, config.discovery.dryRun) };
      const fingerprint = crypto.createHash('sha256').update(JSON.stringify(normalized)).digest('hex').slice(0, 16);
      const job = await queue.enqueue('discovery.run', normalized, {
        singletonKey: 'singleton:discovery.run',
        maxAttempts: 4,
        dedupeKey: `discovery:manual:${fingerprint}:${Math.floor(Date.now() / 60000)}`
      });
      return json(res, 202, { queued: true, jobId: job.id, status: job.status, type: job.type });
    }
    if (method === 'POST' && url.pathname === '/api/run') {
      const input = await parseBody(req);
      const job = await queue.enqueue('research.batch', {
        limit: Math.min(config.maxBatch, Math.max(1, Number(input.limit || config.maxBatch))), reason: 'manual'
      }, { maxAttempts: 3, dedupeKey: `research:manual:${Math.floor(Date.now() / 30000)}` });
      return json(res, 202, { queued: true, jobId: job.id, status: job.status });
    }
    if (method === 'POST' && url.pathname === '/api/run-monitoring') {
      const job = await queue.enqueue('monitoring.process', {}, { maxAttempts: 5, singletonKey: 'singleton:monitoring.process', dedupeKey: `monitoring:manual:${Math.floor(Date.now() / 60000)}` });
      return json(res, 202, { queued: true, jobId: job.id, status: job.status });
    }
    if (method === 'POST' && url.pathname === '/api/worker/pause') {
      const state = await queue.setPaused(true, 'admin-api');
      return json(res, 200, state);
    }
    if (method === 'POST' && url.pathname === '/api/worker/resume') {
      const state = await queue.setPaused(false, 'admin-api');
      return json(res, 200, state);
    }
    if (method === 'POST' && url.pathname.startsWith('/api/jobs/') && url.pathname.endsWith('/retry')) {
      const job = await queue.requeueDeadLetter(url.pathname.split('/')[3]);
      return job ? json(res, 200, job) : json(res, 404, { error: 'Dead-letter job not found' });
    }
    if (method === 'POST' && url.pathname.startsWith('/api/prospects/') && url.pathname.endsWith('/retry')) {
      const prospectId = url.pathname.split('/')[3];
      const prospect = await store.patch('prospects', prospectId, { status: 'retry', error: '' });
      if (!prospect) return json(res, 404, { error: 'Prospect not found' });
      const job = await queue.enqueue('research.batch', { limit: 1, reason: 'prospect-retry', prospectId }, {
        maxAttempts: 3, dedupeKey: `research:retry:${prospectId}:${Date.now()}`
      });
      return json(res, 200, { prospect, jobId: job.id });
    }
    if (method === 'POST' && url.pathname === '/api/poll-replies') {
      const job = await queue.enqueue('replies.poll', {}, { maxAttempts: 5, singletonKey: 'singleton:replies.poll', dedupeKey: `replies:manual:${Math.floor(Date.now() / 60000)}` });
      return json(res, 202, { queued: true, jobId: job.id, status: job.status });
    }
    if (method === 'POST' && url.pathname === '/api/suppress') {
      const input = await parseBody(req);
      if (!input.value) throw new HttpError(400, 'value required');
      const suppression = { id: id('sup'), value: String(input.value).toLowerCase(), reason: input.reason || 'manual', createdAt: now() };
      await store.add('suppressions', suppression);
      return json(res, 201, suppression);
    }
    if (method === 'POST' && url.pathname === '/api/notifications/read') {
      const input = await parseBody(req);
      const notification = await store.patch('notifications', input.id, { status: 'read', readAt: now() });
      return notification ? json(res, 200, notification) : json(res, 404, { error: 'Notification not found' });
    }
    if (method === 'POST' && url.pathname === '/api/test/unlock') {
      if (!config.revenue.allowTestUnlock) return json(res, 403, { error: 'Test payment unlock is disabled' });
      const input = await parseBody(req);
      return json(res, 200, await revenue.unlockLead(input.leadId, input.product || 'full', { provider: 'test', eventId: id('test'), amountCents: Number(input.amountCents || 0) }));
    }

    if (method === 'GET' && url.pathname === '/api/export.csv') {
      const columns = ['company', 'website', 'country', 'niche', 'source', 'status', 'score', 'tier', 'contact', 'issue', 'service', 'subject', 'draft'];
      const rows = (await store.list('prospects')).map(prospect => [
        prospect.company, prospect.website, prospect.country, prospect.niche, prospect.source, prospect.status,
        prospect.score?.total || '', prospect.score?.tier || '', prospect.contact?.email || '',
        prospect.issue?.title || '', prospect.issue?.service || '', prospect.subject || '', prospect.draft || ''
      ]);
      return text(res, 200, [columns, ...rows].map(row => row.map(csvEscape).join(',')).join('\n'), 'text/csv; charset=utf-8', { 'content-disposition': 'attachment; filename="uberbond-opportunities.csv"' });
    }
    if (method === 'GET' && url.pathname === '/api/export.json') {
      const [prospects, campaigns, leads, orders, subscriptions] = await Promise.all([
        store.list('prospects'), store.list('campaigns'), store.list('leads'), store.list('orders'), store.list('subscriptions')
      ]);
      return text(res, 200, JSON.stringify({ exportedAt: now(), prospects, campaigns, leads, orders, subscriptions }, null, 2), 'application/json; charset=utf-8', { 'content-disposition': 'attachment; filename="uberbond-revenue-engine.json"' });
    }

    if (method === 'GET' && url.pathname === '/oauth/google/start') {
      const slot = url.searchParams.get('slot') === 'B' ? 'B' : 'A';
      const state = crypto.randomBytes(20).toString('hex');
      oauthStates.set(state, { slot, created: Date.now() });
      res.writeHead(302, { location: googleAuthUrl(config.google, state) });
      return res.end();
    }
    if (method === 'GET' && url.pathname === '/oauth/google/callback') {
      const stateKey = url.searchParams.get('state');
      const state = oauthStates.get(stateKey);
      if (!state || Date.now() - state.created > 600000) throw new HttpError(400, 'Invalid OAuth state');
      oauthStates.delete(stateKey);
      const tokens = await exchangeCode(config.google, url.searchParams.get('code'));
      tokens.expires_at = Date.now() + (tokens.expires_in || 3600) * 1000;
      let account = { id: `gmail-${state.slot}`, slot: state.slot, tokens: sealTokens(tokens, config.encryptionKey), connected: true, createdAt: now() };
      const profile = await getProfile(config.google, account, config.encryptionKey);
      account.email = profile.data.emailAddress;
      account.tokens = sealTokens(profile.tokens, config.encryptionKey);
      await store.upsert('accounts', account);
      res.writeHead(302, { location: '/admin.html?gmail=connected' });
      return res.end();
    }

    if (await staticFile(req, res)) return;
    return json(res, 404, { error: 'Not found' });
  } catch (error) {
    const status = errorStatus(error);
    // Always log full detail server-side; never expose raw internal messages on 5xx
    // (this handler also serves the unauthenticated public API). 4xx messages are
    // intentional, caller-facing validation text and stay as-is.
    if (status >= 500) console.error(error);
    const message = status === 503
      ? 'Service temporarily unavailable. Please try again shortly.'
      : status >= 500
        ? 'Something went wrong on our side. Please try again.'
        : error.message;
    return json(res, status, { error: message });
  }
});

server.listen(config.port, () => console.log(`UberBond Revenue Engine running on ${config.baseUrl} using ${config.storeBackend}`));

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Received ${signal}; shutting down.`);
  stopScheduler();
  if (localWorkerPromise) await queue.stopWorker().catch(error => console.error('Local worker stop failed', error));
  server.close(async () => {
    await store.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
