import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { Store } from '../src/store.mjs';
import { Pipeline } from '../src/pipeline.mjs';
import { approveProspectForTest, TEST_OUTREACH_APPROVAL_SECRET } from './helpers/outreach-governance.mjs';
import { allowOutboundConsequenceForTest } from './helpers/outbound-consequence-gate.mjs';

const now = new Date('2026-07-13T10:00:00.000Z');
const campaign = { id: 'adapter-campaign', approved: true, autoSend: true, allowedCountries: ['GB'], minScore: 60, dailyCaps: { A: 10 }, maxFollowups: 0 };
const cfg = {
  outbound: {
    enabled: true, dryRun: false, launchPhase: 'canary', provider: 'fixture', useEffectAdapter: false,
    approvalSecret: TEST_OUTREACH_APPROVAL_SECRET, routeEvidenceMaxAgeDays: 7, allowedCountries: ['United Kingdom'],
    hourlyCaps: { A: 3 }, minGapSeconds: 0, canaryDailyCap: 3, canaryHourlyCap: 1, canaryMinGapSeconds: 0,
    recipientCooldownDays: 365, domainCooldownDays: 90, businessHourStart: 9, businessHourEnd: 17,
    minEvidenceConfidence: 0.75, hardBouncePauseThreshold: 2, complaintPauseThreshold: 1, failurePauseThreshold: 3
  },
  sender: { name: 'Mohamed', company: 'UberBond', address: 'Business address' },
  caps: { A: 10 }, google: {}, encryptionKey: 'adapter-test-key'
};

async function storeForTest() {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'uberbond-effect-adapter-'));
  const store = new Store(directory);
  await store.init();
  return store;
}

test('pipeline uses the provider-effect adapter when configured and records provider identity', async () => {
  const store = await storeForTest();
  const base = {
    id: 'adapter-prospect', campaignId: campaign.id, company: 'Clinic', website: 'https://clinic.example', domain: 'clinic.example',
    country: 'United Kingdom', inbox: 'A', draft: 'A governed evidence-backed note.', subject: 'A website observation',
    unsubscribeUrl: 'https://uberbond.example/unsubscribe?token=test', oneClickUnsubscribeUrl: 'https://uberbond.example/api/public/unsubscribe?token=test',
    contact: { email: 'careers@clinic.example', source: 'website', verified: 'unverified' }, score: { total: 80 },
    issue: { title: 'Booking path issue', confidence: 0.9, safeForOutreach: true, evidenceUrl: 'https://clinic.example/book', evidenceExcerpt: 'The booking button returned an error.' }
  };
  const prospect = approveProspectForTest({ prospect: base, campaign, cfg, date: now });
  await store.add('campaigns', campaign);
  await store.add('prospects', { ...prospect, status: 'ready' });
  await store.add('accounts', { id: 'adapter-account', slot: 'A', connected: true, email: 'outreach@uberbond.example', tokens: 'unused' });
  let legacySendCalls = 0;
  let prepared;
  const pipeline = new Pipeline(store, cfg, {
    clock: () => now,
    outboundConsequenceGate: allowOutboundConsequenceForTest,
    sendEmail: async () => { legacySendCalls += 1; throw new Error('legacy send path must not be called'); },
    getMessage: async () => ({ data: { payload: { headers: [{ name: 'Message-ID', value: '<adapter@example>' }] } } }),
    effectAdapterFactory: ({ messageIdDomain }) => ({
      providerName: 'test-effect-provider',
      prepare: async input => { prepared = input; return { ...input, messageId: `<prepared@${messageIdDomain}>` }; },
      dispatch: async () => ({ classification: 'ACCEPTED', providerReferenceId: 'provider-message-1', evidence: { detail: { gmailThreadId: 'provider-thread-1' } } })
    })
  });

  const result = await pipeline.maybeSend(prospect, campaign);
  assert.equal(result.sent, true);
  assert.equal(legacySendCalls, 0);
  assert.equal(prepared.businessKey, 'initial:adapter-prospect');
  assert.equal(prepared.executionId, result.reservation.id);
  const reservation = (await store.list('outboundReservations'))[0];
  assert.equal(reservation.status, 'sent');
  assert.equal(reservation.providerOutcome, 'ACCEPTED');
  assert.equal(reservation.providerReferenceId, 'provider-message-1');
  assert.equal(reservation.providerEffectIdentity.startsWith('<v9-'), true);
});
