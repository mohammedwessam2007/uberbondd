import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { Store } from '../src/store.mjs';
import { Pipeline } from '../src/pipeline.mjs';
import { approveProspectForTest, TEST_OUTREACH_APPROVAL_SECRET } from './helpers/outreach-governance.mjs';
import { allowOutboundConsequenceForTest } from './helpers/outbound-consequence-gate.mjs';

const observedAt = new Date('2026-07-13T10:00:00.000Z');
const campaign = { id: 'reconcile-campaign', approved: true, autoSend: true, allowedCountries: ['GB'], minScore: 60, dailyCaps: { A: 10 }, maxFollowups: 0 };
const cfg = {
  outbound: {
    enabled: true, dryRun: false, launchPhase: 'canary', provider: 'fixture', useEffectAdapter: false,
    approvalSecret: TEST_OUTREACH_APPROVAL_SECRET, routeEvidenceMaxAgeDays: 7, allowedCountries: ['United Kingdom'],
    hourlyCaps: { A: 3 }, minGapSeconds: 0, canaryDailyCap: 3, canaryHourlyCap: 1, canaryMinGapSeconds: 0,
    recipientCooldownDays: 365, domainCooldownDays: 90, businessHourStart: 9, businessHourEnd: 17,
    minEvidenceConfidence: 0.75, hardBouncePauseThreshold: 2, complaintPauseThreshold: 1, failurePauseThreshold: 3
  },
  sender: { name: 'Mohamed', company: 'UberBond', address: 'Business address' }, caps: { A: 10 }, google: {}, encryptionKey: 'reconcile-test-key'
};

test('uncertain adapter effects reconcile by read-only evidence and never dispatch again', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'uberbond-effect-reconcile-'));
  const store = new Store(directory);
  await store.init();
  const prospect = approveProspectForTest({ prospect: {
    id: 'reconcile-prospect', campaignId: campaign.id, company: 'Clinic', website: 'https://clinic.example', domain: 'clinic.example', country: 'United Kingdom',
    inbox: 'A', draft: 'Evidence-backed note.', subject: 'A website observation',
    unsubscribeUrl: 'https://uberbond.example/unsubscribe?token=test', oneClickUnsubscribeUrl: 'https://uberbond.example/api/public/unsubscribe?token=test',
    contact: { email: 'careers@clinic.example', source: 'website', verified: 'unverified' }, score: { total: 80 },
    issue: { title: 'Booking issue', confidence: 0.9, safeForOutreach: true, evidenceUrl: 'https://clinic.example/book', evidenceExcerpt: 'The booking button returned an error.' }
  }, campaign, cfg, date: observedAt });
  await store.add('campaigns', campaign);
  await store.add('prospects', { ...prospect, status: 'ready' });
  await store.add('accounts', { id: 'reconcile-account', slot: 'A', connected: true, email: 'outreach@uberbond.example', tokens: 'unused' });
  let dispatches = 0;
  const pipeline = new Pipeline(store, cfg, {
    clock: () => observedAt,
    outboundConsequenceGate: allowOutboundConsequenceForTest,
    sendEmail: async () => { throw new Error('legacy provider call must not occur'); },
    effectAdapterFactory: () => ({
      providerName: 'test-effect-provider',
      prepare: async input => input,
      dispatch: async () => { dispatches += 1; return { classification: 'UNCERTAIN', evidence: null, dispatchError: 'response lost' }; },
      reconcile: async () => ({ lifecycle: 'RECONCILED_ACCEPTED', providerReferenceId: 'reconciled-message-1', observedAt: observedAt.toISOString(), detail: { gmailThreadId: 'reconciled-thread-1' } }),
      classifyOutcome: evidence => evidence.lifecycle === 'RECONCILED_ACCEPTED' ? 'RECONCILED_ACCEPTED' : 'UNCERTAIN'
    })
  });
  const first = await pipeline.maybeSend(prospect, campaign);
  assert.equal(first.uncertain, true);
  const reservation = (await store.list('outboundReservations'))[0];
  const reconciled = await pipeline.reconcileOutboundReservation(reservation.id);
  assert.equal(reconciled.reconciled, true);
  assert.equal(dispatches, 1);
  assert.equal((await store.get('outboundReservations', reservation.id)).status, 'sent');
  assert.equal((await store.get('prospects', prospect.id)).sendSafety.reason, 'provider-effect-reconciled');
});
