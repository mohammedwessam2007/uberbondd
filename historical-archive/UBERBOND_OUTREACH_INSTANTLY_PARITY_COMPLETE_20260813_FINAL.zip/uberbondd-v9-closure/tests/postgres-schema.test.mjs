import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

async function migratedDb() {
  const db = new PGlite();
  for (const name of ['001_initial.sql', '002_durable_queue.sql', '003_shared_artifacts.sql', '004_unattended_send_safety.sql', '005_omnia_v9_proof_store.sql', '006_omnia_v9_execution_receipt_uniqueness.sql', '007_omnia_v9_authorization_bound_receipts.sql']) {
    await db.exec(await fs.readFile(new URL(`../migrations/${name}`, import.meta.url), 'utf8'));
  }
  return db;
}

async function providerBridgeDb() {
  const db = await migratedDb();
  for (const name of ['012_outreach_recipient_cooldowns.sql', '013_outreach_operator_surface.sql', '014_outreach_provider_event_bridge.sql', '015_outreach_automation_runs.sql']) {
    await db.exec(await fs.readFile(new URL(`../migrations/${name}`, import.meta.url), 'utf8'));
  }
  return db;
}

test('PostgreSQL migration creates every required table and index foundation', async () => {
  const db = await migratedDb();
  try {
    const tables = await db.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'");
    const names = new Set(tables.rows.map(row => row.table_name));
    for (const name of ['prospects','campaigns','jobs','messages','replies','suppressions','social_tasks','accounts','audit_log','settings','leads','orders','subscriptions','monitoring_runs','notifications','revenue_events','discovery_runs','worker_heartbeats','artifacts','outbound_reservations','sender_health','outbound_events','omnia_v9_objects','omnia_v9_revocations','omnia_v9_approval_usage','omnia_v9_authority_reservations','omnia_v9_execution_receipt_bindings','omnia_v9_execution_authorization_bindings']) {
      assert(names.has(name), `missing table ${name}`);
    }
  } finally { await db.close(); }
});

test('PostgreSQL constraints reject duplicate business and provider identities', async () => {
  const db = await migratedDb();
  try {
    await db.query("INSERT INTO campaigns(id, approved, auto_send, data) VALUES ('c1', true, false, '{}'::jsonb)");
    await db.query("INSERT INTO prospects(id, domain, campaign_id, data) VALUES ('p1', 'example.com', 'c1', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO prospects(id, domain, campaign_id, data) VALUES ('p2', 'example.com', 'c1', '{}'::jsonb)"));
    await db.query("INSERT INTO suppressions(id, value, data) VALUES ('s1', 'no@example.com', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO suppressions(id, value, data) VALUES ('s2', 'no@example.com', '{}'::jsonb)"));
    await db.query("INSERT INTO replies(id, gmail_id, data) VALUES ('r1', 'gmail-1', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO replies(id, gmail_id, data) VALUES ('r2', 'gmail-1', '{}'::jsonb)"));
    await db.query("INSERT INTO accounts(id, slot, data) VALUES ('a1', 'A', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO accounts(id, slot, data) VALUES ('a2', 'A', '{}'::jsonb)"));
    await db.query("INSERT INTO orders(id, provider_event_id, data) VALUES ('o1', 'evt-1', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO orders(id, provider_event_id, data) VALUES ('o2', 'evt-1', '{}'::jsonb)"));
    await db.query("INSERT INTO revenue_events(id, provider_event_id, data) VALUES ('v1', 'rev-1', '{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO revenue_events(id, provider_event_id, data) VALUES ('v2', 'rev-1', '{}'::jsonb)"));
  } finally { await db.close(); }
});

test('PostgreSQL prospect claiming uses SKIP LOCKED-compatible state columns', async () => {
  const db = await migratedDb();
  try {
    await db.query("INSERT INTO campaigns(id, approved, auto_send, data) VALUES ('c1', true, false, '{}'::jsonb)");
    await db.query("INSERT INTO prospects(id, domain, campaign_id, status, created_at, data) VALUES ('p1', 'one.test', 'c1', 'queued', now(), '{\"id\":\"p1\",\"status\":\"queued\"}'::jsonb)");
    const result = await db.query(`WITH candidates AS (SELECT id FROM prospects WHERE status = ANY($1::text[]) ORDER BY created_at ASC NULLS FIRST FOR UPDATE SKIP LOCKED LIMIT $2) UPDATE prospects p SET status='claimed', updated_at=now(), data=jsonb_set(p.data,'{status}','\"claimed\"'::jsonb) FROM candidates c WHERE p.id=c.id RETURNING p.id`, [['queued'], 1]);
    assert.equal(result.rows[0].id, 'p1');
  } finally { await db.close(); }
});

test('durable queue migration adds retry, locking, dedupe, and dead-letter columns', async () => {
  const db = await migratedDb();
  try {
    const columns = await db.query("SELECT column_name FROM information_schema.columns WHERE table_name='jobs'");
    const names = new Set(columns.rows.map(row => row.column_name));
    for (const name of ['queue','priority','attempts','max_attempts','run_at','locked_at','locked_by','heartbeat_at','last_error','dedupe_key','singleton_key','dead_lettered_at','result']) {
      assert(names.has(name), `missing jobs.${name}`);
    }
    await db.query(`INSERT INTO jobs(id,type,queue,status,dedupe_key,run_at,data) VALUES ('j1','test','test','queued','once',now(),'{"id":"j1","status":"queued"}'::jsonb)`);
    await assert.rejects(db.query(`INSERT INTO jobs(id,type,queue,status,dedupe_key,run_at,data) VALUES ('j2','test','test','queued','once',now(),'{"id":"j2","status":"queued"}'::jsonb)`));
    await db.query(`INSERT INTO jobs(id,type,queue,status,singleton_key,run_at,data) VALUES ('j3','single','single','active','one-active',now(),'{"id":"j3","status":"active"}'::jsonb)`);
    await assert.rejects(db.query(`INSERT INTO jobs(id,type,queue,status,singleton_key,run_at,data) VALUES ('j4','single','single','queued','one-active',now(),'{"id":"j4","status":"queued"}'::jsonb)`));
    await db.query(`UPDATE jobs SET status='completed' WHERE id='j3'`);
    await db.query(`INSERT INTO jobs(id,type,queue,status,singleton_key,run_at,data) VALUES ('j5','single','single','queued','one-active',now(),'{"id":"j5","status":"queued"}'::jsonb)`);
  } finally { await db.close(); }
});

test('shared artifact table stores binary screenshots for separate web and worker services', async () => {
  const db = await migratedDb();
  try {
    const content = Buffer.from('png-bytes');
    await db.query(`INSERT INTO artifacts(id,content_type,byte_size,sha256,metadata,content) VALUES ('artifact_test','image/png',$1,'hash','{}'::jsonb,$2)`, [content.length, content]);
    const result = await db.query(`SELECT content_type,byte_size,content FROM artifacts WHERE id='artifact_test'`);
    assert.equal(result.rows[0].content_type, 'image/png');
    assert.equal(Number(result.rows[0].byte_size), content.length);
    assert.equal(Buffer.from(result.rows[0].content).toString(), 'png-bytes');
  } finally { await db.close(); }
});

test('PostgreSQL can atomically claim one requested prospect without taking the oldest unrelated row', async () => {
  const db = await migratedDb();
  try {
    await db.query("INSERT INTO campaigns(id, approved, auto_send, data) VALUES ('c-target', true, false, '{}'::jsonb)");
    await db.query("INSERT INTO prospects(id, domain, campaign_id, status, created_at, data) VALUES ('old-target', 'old-target.test', 'c-target', 'queued', '2026-01-01', '{\"id\":\"old-target\",\"status\":\"queued\"}'::jsonb)");
    await db.query("INSERT INTO prospects(id, domain, campaign_id, status, created_at, data) VALUES ('wanted-target', 'wanted-target.test', 'c-target', 'queued', '2026-02-01', '{\"id\":\"wanted-target\",\"status\":\"queued\"}'::jsonb)");
    const result = await db.query(`UPDATE prospects SET status='claimed', data=jsonb_set(data,'{status}','\"claimed\"'::jsonb) WHERE id=$1 AND status=ANY($2::text[]) RETURNING id`, ['wanted-target', ['queued','new','retry','error']]);
    assert.equal(result.rows[0].id, 'wanted-target');
    const old = await db.query("SELECT status FROM prospects WHERE id='old-target'");
    assert.equal(old.rows[0].status, 'queued');
  } finally { await db.close(); }
});

test('outbound safety migration enforces durable idempotency and sender health uniqueness', async () => {
  const db = await migratedDb();
  try {
    await db.query("INSERT INTO outbound_reservations(id,idempotency_key,inbox,recipient_email,status,reserved_at,data) VALUES ('or1','initial:p1','A','info@example.com','reserved',now(),'{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO outbound_reservations(id,idempotency_key,inbox,recipient_email,status,reserved_at,data) VALUES ('or2','initial:p1','A','info@example.com','reserved',now(),'{}'::jsonb)"));
    await db.query("INSERT INTO sender_health(id,inbox,data) VALUES ('sh1','A','{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO sender_health(id,inbox,data) VALUES ('sh2','A','{}'::jsonb)"));
  } finally { await db.close(); }
});

test('provider event bridge migration creates a durable webhook ledger and event identity', async () => {
  const db = await providerBridgeDb();
  try {
    const columns = await db.query("SELECT column_name FROM information_schema.columns WHERE table_name='outbound_events'");
    assert(new Set(columns.rows.map(row => row.column_name)).has('provider_event_id'));
    const providerEvents = await db.query("SELECT table_name FROM information_schema.tables WHERE table_name='provider_events'");
    assert.equal(providerEvents.rows.length, 1);
    await db.query("INSERT INTO provider_events(id,provider,provider_event_key,event_type,status,received_at,data) VALUES ('pe1','instantly','instantly:reply:1','reply','received',now(),'{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO provider_events(id,provider,provider_event_key,event_type,status,received_at,data) VALUES ('pe2','instantly','instantly:reply:1','reply','received',now(),'{}'::jsonb)"));
    await db.query("INSERT INTO outbound_events(id,event_type,occurred_at,provider_event_id,data) VALUES ('oe1','reply',now(),'instantly:reply:1','{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO outbound_events(id,event_type,occurred_at,provider_event_id,data) VALUES ('oe2','reply',now(),'instantly:reply:1','{}'::jsonb)"));
  } finally { await db.close(); }
});

test('automation migration keeps one plan run per provider event key', async () => {
  const db = await providerBridgeDb();
  try {
    await db.query("INSERT INTO automation_plans(id,name,trigger,data) VALUES ('ap1','Positive route','lead_positive','{}'::jsonb)");
    await db.query("INSERT INTO automation_runs(id,plan_id,event_key,status,data) VALUES ('ar1','ap1','instantly:positive:1','applied','{}'::jsonb)");
    await assert.rejects(db.query("INSERT INTO automation_runs(id,plan_id,event_key,status,data) VALUES ('ar2','ap1','instantly:positive:1','applied','{}'::jsonb)"));
  } finally { await db.close(); }
});

test('P6 execution receipt binding migration enforces one consequence and one digest identity', async () => {
  const db = await migratedDb();
  try {
    const a = 'a'.repeat(64);
    const b = 'b'.repeat(64);
    const c = 'c'.repeat(64);
    const receipt = JSON.stringify({ receiptDigest: a, reservation: { id: 'res1' } });
    await db.query(`INSERT INTO omnia_v9_execution_receipt_bindings(reservation_id,receipt_digest,tenant_id,outcome,pre_effect_context_digest,pre_effect_observation_digest,receipt) VALUES ('res1',$1,'tenant1','PROVIDER_ACCEPTED',$2,$3,$4::jsonb)`, [a, b, c, receipt]);
    await assert.rejects(db.query(`INSERT INTO omnia_v9_execution_receipt_bindings(reservation_id,receipt_digest,tenant_id,outcome,pre_effect_context_digest,pre_effect_observation_digest,receipt) VALUES ('res1',$1,'tenant1','PROVIDER_ACCEPTED',$2,$3,$4::jsonb)`, ['d'.repeat(64), b, c, receipt]));
    await assert.rejects(db.query(`INSERT INTO omnia_v9_execution_receipt_bindings(reservation_id,receipt_digest,tenant_id,outcome,pre_effect_context_digest,pre_effect_observation_digest,receipt) VALUES ('res2',$1,'tenant1','PROVIDER_ACCEPTED',$2,$3,$4::jsonb)`, [a, b, c, receipt]));
  } finally { await db.close(); }
});

test('P7 authorization binding migration enforces one immutable authority chain per consequence', async () => {
  const db = await migratedDb();
  try {
    const receiptDigest = 'a'.repeat(64);
    const contextDigest = 'b'.repeat(64);
    const observationDigest = 'c'.repeat(64);
    const bindingDigest = 'd'.repeat(64);
    const otherBindingDigest = 'e'.repeat(64);
    const intentDigest = 'f'.repeat(64);
    const decisionDigest = '1'.repeat(64);
    const policyDigest = '2'.repeat(64);
    const constitutionDigest = '3'.repeat(64);
    await db.query(`INSERT INTO omnia_v9_execution_receipt_bindings(reservation_id,receipt_digest,tenant_id,outcome,pre_effect_context_digest,pre_effect_observation_digest,receipt) VALUES ('p7-res1',$1,'tenant1','PROVIDER_ACCEPTED',$2,$3,'{}'::jsonb)`, [receiptDigest, contextDigest, observationDigest]);
    await db.query(`INSERT INTO omnia_v9_execution_authorization_bindings(reservation_id,receipt_digest,binding_digest,tenant_id,intent_digest,authorization_decision_digest,approval_id,policy_version,policy_digest,constitution_digest,binding) VALUES ('p7-res1',$1,$2,'tenant1',$3,$4,'approval1','policy-v1',$5,$6,'{}'::jsonb)`, [receiptDigest, bindingDigest, intentDigest, decisionDigest, policyDigest, constitutionDigest]);
    await assert.rejects(db.query(`INSERT INTO omnia_v9_execution_authorization_bindings(reservation_id,receipt_digest,binding_digest,tenant_id,intent_digest,authorization_decision_digest,approval_id,policy_version,policy_digest,constitution_digest,binding) VALUES ('p7-res1',$1,$2,'tenant1',$3,$4,'approval2','policy-v1',$5,$6,'{}'::jsonb)`, [receiptDigest, otherBindingDigest, intentDigest, decisionDigest, policyDigest, constitutionDigest]));
  } finally { await db.close(); }
});
