# CHAOS FIVE | chess research archive

**Research date:** 23 November 2026. **Truth status:** source discovery and method package, NOT a downloaded complete game corpus, and NOT Stockfish analysis of all games.

Five players: Rashid Nezhmetdinov, Mikhail Tal, Michael J. Basman, Alexei Shirov, Daniil Dubov.

## What is actually inside

- `Chaos_Five_Research_Index.xlsx`: traceable source matrix, curated high-information games, competing stylistic hypotheses and falsification criteria.
- `research_sources.json`: current archive source ledger with counts, scope, access and uncertainty.
- `signature_games.csv`: source-linked starting games, not complete game scores.
- `collect_and_analyze.py`: an executable collector that can fetch three known public source URLs or index PGN/ZIP files supplied to it. It produces a searchable CSV and a combined PGN after actual PGNs are present.

**There are zero scraped/validated PGN game scores in this delivered package.** Attempts to fetch public PGN ZIPs from the current container failed due network resolution; a separate connected runtime tunnel was unavailable. Those are retrieval gaps, not evidence the downloads do not exist.

## To populate the actual game list

From a computer with ordinary Internet access:

```bash
python3 collect_and_analyze.py --fetch --folder pgn_inputs --output output
```

This fetches the **verified direct source URLs only** for Tal, Shirov and Basman. The downloadable PGN Mentor Tal and Shirov collections are archived **through July 2025** and therefore cannot establish all their later games. Basman entries include game fragments, stubs and compositions.

For Nezhmetdinov and Dubov, export or obtain a properly licensed PGN from one of the **actual verified source pages** in `research_sources.json`. Do not guess private download endpoints. Place the resulting `.pgn` or `.zip` in `pgn_inputs` and rerun the command above. A game featuring two of these five will generate one index row per protagonist to make per-player study possible.

Optional:

```bash
pip install python-chess
python3 collect_and_analyze.py --folder pgn_inputs --output output --validate
```

**Outputs after source availability:** `output/games_index.csv`, `output/all_indexed_games.pgn`, `output/summary.json`. They do not exist for the source archives in this delivered package and are not presented as analyzed.

## Interpret the numbers correctly

`text_chaos_proxy` is a *syntactic counter*, not a serious chess evaluation. It weights early flank-pawn moves, early queen moves, captures and checking moves. It can identify curious candidates for review but CANNOT establish that a sacrifice is sound/unsound, a king is vulnerable, a game is brilliant, or a player is reckless. `material_deficit_peak` and `queen_sacrifice_verified` are explicitly `NOT_MEASURED` and `NOT_VERIFIED` until an engine-grounded separate pass is performed.

To compare objectively, stratify by player color, year, time control, opposition strength and opening, then check material investment, forcing-sequence length, Stockfish evaluation/uncertainty before and after, and *practical compensation*. Annotated famous games are intentionally biased toward spectacular victories and cannot establish corpus-wide rates.

## Five different mechanisms

- **Nezhmetdinov:** voluntarily leaves material behind to expose the king, often with sustained initiative; iconic tactical sacrifices. Representative: Polugaevsky–Nezhmetdinov (Sochi 1958), Nezhmetdinov–Chernikov (1962).
- **Tal:** uses combinations and even uncertain complications to force unrepeatable human decisions; speculative pragmatism as well as calculation. Representative: Botvinnik–Tal (1960 WCh game 6).
- **Basman:** rejects opening conventions, creates unfamiliar positions, then can switch into stubborn defense and psychological provocation. The 1975 win against Andersson actually includes extended *waiting*, disproving a blanket 'constant attacking' label.
- **Shirov:** concrete imagination can turn seemingly quiet technical play into tactical solutions, such as 47...Bh3!! against Topalov (Linares 1998).
- **Dubov:** modern preparation and tactical imagination; historical example Dubov–Karjakin (Russian Superfinal 2020) featuring 19.Qxg6!!.

## Research reliability

This index is a research basis. A definitive claim to possess *every historical game* would require full survivor records across many published and unpublished sources. Known archive totals disagree, names collide, rapid/blitz/online time controls mix, and many old scores are missing. Never sum overlapping providers to report a player's total.
