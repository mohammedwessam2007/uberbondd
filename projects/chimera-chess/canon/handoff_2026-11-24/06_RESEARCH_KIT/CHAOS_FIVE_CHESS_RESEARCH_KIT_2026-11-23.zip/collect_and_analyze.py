#!/usr/bin/env python3
"""Five Chess Mavericks: source-aware PGN indexer and candidate-style profiler.

No chess positions or engine scores are invented. PGN sources with unknown access
requirements are never fetched through guessed endpoints.

Usage:
  python collect_and_analyze.py --fetch --folder pgn_inputs --output output
  python collect_and_analyze.py --folder pgn_inputs --output output

When python-chess is installed, each game is also legally replayed to compute
well-defined position-based features; otherwise only text-level proxies are
reported. The proxies are NOT proved sacrifices or objectively best moves.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, re, sys, urllib.request, zipfile
from collections import Counter, defaultdict
from pathlib import Path

SOURCES = [
    ('Mikhail Tal', 'https://www.pgnmentor.com/players/Tal.zip', 'Tal.zip'),
    ('Alexei Shirov', 'https://www.pgnmentor.com/players/Shirov.zip', 'Shirov.zip'),
    ('Michael Basman', 'https://www.britbase.co.uk/britbase/pgn/basmanm.pgn', 'basmanm.pgn'),
]
PLAYER_ALIASES = {
    'Rashid Nezhmetdinov': ['nezhmetdinov', 'nezmetdinov', 'nezmetdinow'],
    'Mikhail Tal': ['tal, m', 'tal m', 'mikhail tal', 'tal, mikhail', 'tal, mikhail n'],
    'Michael Basman': ['basman'],
    'Alexei Shirov': ['shirov', 'shirov, a', 'alexei shirov', 'aleksey shirov'],
    'Daniil Dubov': ['dubov, daniil', 'daniil dubov', 'dubov d', 'dubov, d'],
}
TAGS = re.compile(r'^\[([A-Za-z0-9_]+)\s+"((?:\\.|[^"\\])*)"\]\s*$')
NAG = re.compile(r'\$\d+')
MOVE_PREFIX = re.compile(r'^\d+\.(?:\.\.)?')
SANLIKE = re.compile(r'^(?:O-O(?:-O)?|0-0(?:-0)?|[KQRBN]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?|[a-h]x?[a-h]?[1-8](?:=[QRBN])?)[+#?!]*$')
OUTPUT_HEADERS = [
 'game_id','player','color','opponent','date','year','event','site','round','result','outcome',
 'eco','opening','half_moves','full_moves_approx','source_files','game_record_type','replay_status',
 'early_flank_pawns','early_queen_moves','checks_first_30','captures_first_30','total_checks',
 'total_captures','castle_at_ply','text_chaos_proxy','material_deficit_peak','queen_sacrifice_verified'
]


def identify(name):
    n = re.sub(r'[^a-z, ]+', ' ', (name or '').lower()).strip()
    n = re.sub(r'\s+', ' ', n)
    for player,aliases in PLAYER_ALIASES.items():
        if any((a in n if len(a)>4 else n==a) for a in aliases):
            return player
    return None


def strip_extras(s):
    # Remove comments/variations in one bounded linear scan. Semicolon comments end at newline.
    out=[]; brace=0; paren=0; semicolon=False
    for char in s:
        if semicolon:
            if char=='\n': semicolon=False
            continue
        if brace:
            if char=='{': brace+=1
            elif char=='}': brace-=1
            continue
        if char=='{': brace=1; continue
        if char==';': semicolon=True; continue
        if char=='(': paren+=1; continue
        if char==')': paren=max(0,paren-1); continue
        if not paren: out.append(char)
    return NAG.sub(' ', ''.join(out))


def san_moves(movetext):
    clean=strip_extras(movetext)
    moves=[]
    for t in clean.replace('\r',' ').split():
        while MOVE_PREFIX.match(t): t=MOVE_PREFIX.sub('',t,count=1)
        t=t.strip()
        if t in ('1-0','0-1','1/2-1/2','*','...','--'):continue
        if t and SANLIKE.match(t): moves.append(t)
    return moves


def parse_pgn(content):
    tags={}; lines=[]
    def flush():
        nonlocal tags,lines
        if not tags and not lines:return None
        val=(tags, '\n'.join(lines).strip())
        tags={}; lines=[]
        return val
    for line in content.splitlines():
        m=TAGS.match(line.strip())
        if m:
            if (lines and any(x.strip() for x in lines)) or (m.group(1) in tags and tags):
                r=flush()
                if r: yield r
            tags[m.group(1)] = m.group(2).replace('\\"','"')
        elif tags or line.strip():
            lines.append(line)
    r=flush()
    if r:yield r


def load_sources(folder):
    for p in sorted(folder.rglob('*')):
        if not p.is_file():continue
        if p.suffix.lower()=='.pgn':
            yield str(p), p.read_text(encoding='utf-8-sig',errors='replace')
        elif p.suffix.lower()=='.zip':
            try:
                with zipfile.ZipFile(p) as z:
                    for name in z.namelist():
                        if name.lower().endswith('.pgn') and not name.startswith('__MACOSX'):
                            if z.getinfo(name).file_size>100_000_000:continue
                            yield f'{p}::{name}',z.read(name).decode('utf-8-sig',errors='replace')
            except (zipfile.BadZipFile, OSError) as exc: print(f'SKIP {p}: {exc}', file=sys.stderr)


def fetch(folder):
    folder.mkdir(parents=True,exist_ok=True)
    for player,url,filename in SOURCES:
        target=folder/filename
        if target.is_file() and target.stat().st_size>0:
            print('PRESENT',player,target); continue
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 Chess Research Archive/1.0'})
            with urllib.request.urlopen(req,timeout=25) as resp:
                content=resp.read(40_000_001)
            if len(content)>40_000_000:raise ValueError('Archive exceeds bounded limit')
            if filename.endswith('.zip') and not zipfile.is_zipfile(io.BytesIO(content)):
                raise ValueError('Response was not a ZIP archive')
            if filename.endswith('.pgn') and b'[Event ' not in content[:50000]:
                raise ValueError('Response was not a recognizable PGN')
            target.write_bytes(content)
            print('FETCHED',player,len(content),'bytes')
        except Exception as exc:
            print('FETCH FAILED',player,repr(exc),'Use the verified source page to download manually.',file=sys.stderr)


def text_metrics(moves,color):
    # These are SAN-token proxies, not engine judgements.
    own=[(i+1,m) for i,m in enumerate(moves) if (i%2==0)==(color=='White')]
    early_flank=sum(1 for i,m in own if i<=20 and bool(re.match(r'^[abgh][2-8]$',m)))
    early_queen=sum(1 for i,m in own if i<=20 and bool(re.match(r'^Q[a-h1-8x]',m)))
    c30=sum(1 for i,m in own if i<=60 and ('+' in m or '#' in m))
    x30=sum(1 for i,m in own if i<=60 and 'x' in m)
    tot_c=sum(1 for _,m in own if '+' in m or '#' in m)
    tot_x=sum(1 for _,m in own if 'x' in m)
    castles=next((i for i,m in own if m.startswith(('O-O','0-0'))),None)
    score=2*early_flank+early_queen+2*c30+x30
    return early_flank,early_queen,c30,x30,tot_c,tot_x,castles,score


def legal_replay(movetext):
    try:
        import chess.pgn
    except ImportError:
        return 'NOT_VERIFIED (python-chess unavailable)'
    try:
        game=chess.pgn.read_game(io.StringIO('[Event "Study"]\n\n'+movetext))
        if game is None or game.errors:return 'ILLEGAL_OR_UNPARSEABLE'
        moves=list(game.mainline_moves())
        return 'LEGAL' if len(moves)>0 else 'NO_MOVES'
    except Exception:
        return 'ILLEGAL_OR_UNPARSEABLE'


def process(folder,output,do_validate=False):
    output.mkdir(parents=True,exist_ok=True)
    rows={}; pgn_blocks={}; stats=Counter(); file_counts=Counter(); blocked=[]
    for file,raw in load_sources(folder):
        count=0
        for tags,movetext in parse_pgn(raw):
            white=identify(tags.get('White',''))
            black=identify(tags.get('Black',''))
            who=white or black
            if not who: continue
            if white and black and white != black: blocked.append('Two target players share this game; assigned to both for separate perspectives.')
            moves=san_moves(movetext)
            date=tags.get('Date','????.??.??')
            white_norm=(identify(tags.get('White','')) or tags.get('White','')).strip().lower()
            black_norm=(identify(tags.get('Black','')) or tags.get('Black','')).strip().lower()
            # Exact-score dedup independent of source file and variation/comment differences.
            rawkey=json.dumps([white_norm,black_norm,date[:4],moves],ensure_ascii=False)
            hashkey=hashlib.sha256(rawkey.encode()).hexdigest()[:20]
            for player,color in [(white,'White'),(black,'Black')]:
                if not player:continue
                idkey=f'{player}:{hashkey}'
                if idkey in rows:
                    sources=rows[idkey]['source_files'].split(' | ')
                    if file not in sources:rows[idkey]['source_files']+=' | '+file
                    continue
                opponent=tags.get('Black' if color=='White' else 'White','')
                vals=text_metrics(moves,color)
                kind='COMPLETE_SCORE_CANDIDATE' if len(moves)>=8 else ('PARTIAL_SCORE' if len(moves) else 'STUB_OR_PROBLEM')
                row=dict(zip(OUTPUT_HEADERS,[idkey,player,color,opponent,date,date[:4],tags.get('Event',''),tags.get('Site',''),tags.get('Round',''),tags.get('Result','*'),'',tags.get('ECO',''),tags.get('Opening',''),len(moves),(len(moves)+1)//2,file,kind,legal_replay(movetext) if do_validate else 'NOT_VERIFIED',*vals,'NOT_MEASURED','NOT_VERIFIED']))
                result=tags.get('Result','*')
                row['outcome']='Win' if ((result=='1-0' and color=='White') or (result=='0-1' and color=='Black')) else 'Loss' if result in ['1-0','0-1'] else 'Draw' if result=='1/2-1/2' else 'Unknown'
                rows[idkey]=row
                pgn_blocks[idkey] = (tags,movetext)
                stats[player]+=1
                count+=1
        file_counts[file]+=count
    with (output/'games_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=OUTPUT_HEADERS)
        writer.writeheader();writer.writerows(sorted(rows.values(),key=lambda x:(x['player'],x['date'],x['opponent'],x['game_id'])))
    with (output/'all_indexed_games.pgn').open('w',encoding='utf-8') as f:
        for k,(tags,moves) in pgn_blocks.items():
            for tag,val in tags.items():f.write(f'[{tag} "{val}"]\n')
            f.write('\n'+moves+'\n\n')
    summary={'indexed_rows':len(rows),'per_player':dict(stats),'per_file':dict(file_counts),
             'legal_move_validation': 'requested' if do_validate else 'NOT_RUN',
             'engine_evaluations':'NOT_RUN',
             'coverage':'PARTIAL: only supplied, successfully downloaded PGNs; no complete-career guarantee',
             'limitations':['A game with two target players generates two perspective rows.',
             'Compilations can contain partials, duplicates and erroneous historic transcriptions.',
             'Text chaos proxy is NOT an engine-based recklessness or sacrifice metric.',
             'Full definitive historical game inventories are impossible where scores never survived.']}
    (output/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(summary,indent=2))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--folder',type=Path,default=Path('pgn_inputs'))
    ap.add_argument('--output',type=Path,default=Path('output'))
    ap.add_argument('--fetch',action='store_true',help='Fetch only three verified public PGN endpoints (Tal, Shirov, Basman).')
    ap.add_argument('--validate',action='store_true',help='Try python-chess legal PGN replay; pip install python-chess.')
    args=ap.parse_args()
    if args.fetch:fetch(args.folder)
    process(args.folder,args.output,args.validate)


if __name__=='__main__':main()
