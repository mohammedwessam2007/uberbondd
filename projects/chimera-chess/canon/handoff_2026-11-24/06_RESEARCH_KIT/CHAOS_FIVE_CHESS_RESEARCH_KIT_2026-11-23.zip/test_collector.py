import io, tempfile, csv, json, zipfile
from pathlib import Path
from collect_and_analyze import identify, san_moves, parse_pgn, text_metrics, process

SAMPLE='''[Event "SYNTHETIC TEST"]
[Date "2001.02.03"]
[White "Tal, Mikhail"]
[Black "Dubov, Daniil"]
[Result "1-0"]

1. g4 d5 {removed note} 2. h3 (2. Nf3 Nf6) 2...e6 3. Bg2 Nf6 4. d3 Be7 5. c4 O-O 1-0

[Event "SYNTHETIC TEST TWO"]
[Date "2001.02.04"]
[White "Basman, Michael J"]
[Black "Test Opponent"]
[Result "0-1"]

1. a3 e5 2. h3 d5 0-1
'''
assert identify('Tal, Mikhail') == 'Mikhail Tal'
assert identify('Nezhmetdinov, Rashid') == 'Rashid Nezhmetdinov'
assert identify('Dubov, Daniil') == 'Daniil Dubov'
assert identify('Basman, Michael J') == 'Michael Basman'
assert identify('Shirov, Alexei') == 'Alexei Shirov'
a=list(parse_pgn(SAMPLE))
assert len(a)==2, a
assert san_moves(a[0][1])==['g4','d5','h3','e6','Bg2','Nf6','d3','Be7','c4','O-O']
with tempfile.TemporaryDirectory() as d:
    p=Path(d); inp=p/'input';inp.mkdir();out=p/'output'
    (inp/'sample.pgn').write_text(SAMPLE)
    process(inp,out)
    rows=list(csv.DictReader((out/'games_index.csv').open(encoding='utf-8-sig')))
    assert len(rows)==3,len(rows) # one game between two target players gives 2 perspective rows
    assert {r['player'] for r in rows}=={'Mikhail Tal','Daniil Dubov','Michael Basman'}
    assert rows[0]['queen_sacrifice_verified']=='NOT_VERIFIED'
    assert json.loads((out/'summary.json').read_text())['indexed_rows']==3
print('PASS: parser, variation removal, aliases, perspective indexing, CSV & provenance')
